"use strict";
var GDK;
(function (GDK) {
    var GameInfoBase = /** @class */ (function () {
        function GameInfoBase() {
            this.requireCustomServicePay = false;
            this.requireMiniAppPay = false;
            this.requireIndiaSPSPay = false;
        }
        return GameInfoBase;
    }());
    GDK.GameInfoBase = GameInfoBase;
})(GDK || (GDK = {}));
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var GDK;
(function (GDK) {
    var devlog = new slib.Log({ tags: ["DEVELOP"] });
    var Vibration = /** @class */ (function () {
        function Vibration() {
        }
        Vibration.prototype.vibrateLong = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("vibrateLong");
                    return [2 /*return*/];
                });
            });
        };
        Vibration.prototype.vibrateShort = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("vibrateShort");
                    return [2 /*return*/];
                });
            });
        };
        Vibration.prototype.vibrate = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("vibrate", params);
                    return [2 /*return*/];
                });
            });
        };
        return Vibration;
    }());
    var Performance = /** @class */ (function () {
        function Performance() {
        }
        Performance.prototype.getMicroTime = function () {
            return new Date().getTime() * 1000;
        };
        Performance.prototype.tryGC = function () {
            devlog.info('tryGC');
        };
        Performance.prototype.onMemoryWarning = function (callback) {
            devlog.info('register onMemoryWarning');
        };
        return Performance;
    }());
    var HardwareBase = /** @class */ (function () {
        function HardwareBase() {
            this.vibration = new Vibration();
            this.performance = new Performance();
        }
        return HardwareBase;
    }());
    GDK.HardwareBase = HardwareBase;
})(GDK || (GDK = {}));
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var GDK;
(function (GDK) {
    var devlog = new slib.Log({ tags: ["DEVELOP"] });
    var Clipboard = /** @class */ (function () {
        function Clipboard() {
        }
        Clipboard.prototype.getData = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, __assign({}, this._data)];
                });
            });
        };
        Clipboard.prototype.setData = function (res) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    this._data = __assign({}, res);
                    return [2 /*return*/];
                });
            });
        };
        return Clipboard;
    }());
    var APISystemBase = /** @class */ (function () {
        function APISystemBase() {
            this.clipboard = new Clipboard();
            this._onShowEvent = new slib.SimpleEvent();
            this._onHideEvent = new slib.SimpleEvent();
        }
        APISystemBase.prototype.setFPS = function (fps) {
            throw new Error("Method not implemented.");
        };
        APISystemBase.prototype.setLoadingProgress = function (params) {
            throw new Error("Method not implemented.");
        };
        APISystemBase.prototype.openURL = function (url) {
            throw new Error("Method not implemented.");
        };
        APISystemBase.prototype.startYunkefu = function (accessId, name, id, customField, native) {
            throw new Error("Method not implemented.");
        };
        APISystemBase.prototype.hasNativeAssistantCenter = function () {
            throw new Error("Method not implemented.");
        };
        APISystemBase.prototype.showHackWeb = function (url, duration) {
            throw new Error("Method not implemented.");
        };
        APISystemBase.prototype.setSDKLanguage = function (lang) {
            throw new Error("Method not implemented.");
        };
        Object.defineProperty(APISystemBase.prototype, "sdkFrameworkVersion", {
            get: function () {
                return "-1.0";
            },
            enumerable: true,
            configurable: true
        });
        APISystemBase.prototype.init = function () {
            this._initEvents();
        };
        Object.defineProperty(APISystemBase.prototype, "nativeVersion", {
            get: function () {
                return -1;
            },
            enumerable: true,
            configurable: true
        });
        APISystemBase.prototype.setEnableDebug = function (res) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("unsupoort action: setEnableDebug -> " + res.enableDebug + " ");
                    return [2 /*return*/];
                });
            });
        };
        APISystemBase.prototype.navigateToApp = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("打开小程序成功");
                    return [2 /*return*/, null];
                });
            });
        };
        APISystemBase.prototype.exitProgram = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("正在退出");
                    window.close();
                    return [2 /*return*/];
                });
            });
        };
        APISystemBase.prototype.updateProgramForce = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("没有更新");
                    return [2 /*return*/];
                });
            });
        };
        APISystemBase.prototype._initEvents = function () {
            var _this = this;
            var win = window, hiddenPropName;
            if (typeof document.hidden !== 'undefined') {
                hiddenPropName = 'hidden';
            }
            else if (typeof document['mozHidden'] !== 'undefined') {
                hiddenPropName = 'mozHidden';
            }
            else if (typeof document['msHidden'] !== 'undefined') {
                hiddenPropName = 'msHidden';
            }
            else if (typeof document['webkitHidden'] !== 'undefined') {
                hiddenPropName = 'webkitHidden';
            }
            var hidden = false;
            var onHidden = function () {
                if (!hidden) {
                    hidden = true;
                    // game.emit(game.EVENT_HIDE);
                    _this._onHideEvent.emit(undefined);
                }
            };
            var onShown = function () {
                if (hidden) {
                    hidden = false;
                    // game.emit(game.EVENT_SHOW);
                    _this._onShowEvent.emit({});
                }
            };
            if (hiddenPropName) {
                var changeList = [
                    'visibilitychange',
                    'mozvisibilitychange',
                    'msvisibilitychange',
                    'webkitvisibilitychange',
                    'qbrowserVisibilityChange'
                ];
                for (var i = 0; i < changeList.length; i++) {
                    document.addEventListener(changeList[i], function (event) {
                        var visible = document[hiddenPropName];
                        if (visible == undefined) {
                            visible = event['hidden'];
                        }
                        devlog.info('hidden:', visible);
                        if (visible)
                            onHidden();
                        else
                            onShown();
                    });
                }
            }
            else {
                win.addEventListener('blur', onHidden);
                win.addEventListener('focus', onShown);
            }
            if (navigator.userAgent.indexOf('MicroMessenger') > -1) {
                win.onfocus = onShown;
            }
            if ('onpageshow' in window && 'onpagehide' in window) {
                win.addEventListener('pagehide', onHidden);
                win.addEventListener('pageshow', onShown);
                document.addEventListener('pagehide', onHidden);
                document.addEventListener('pageshow', onShown);
            }
        };
        APISystemBase.prototype.onShow = function (callback) {
            this._onShowEvent.on(callback);
        };
        APISystemBase.prototype.offShow = function (callback) {
            this._onShowEvent.off(callback);
        };
        APISystemBase.prototype.onHide = function (callback) {
            this._onHideEvent.on(callback);
        };
        APISystemBase.prototype.offHide = function (callback) {
            this._onHideEvent.off(callback);
        };
        APISystemBase.prototype.getSafeArea = function (callback) {
            callback({ left: 0, right: 0, top: 0, bottom: 0 });
        };
        APISystemBase.prototype.gotoAppSystemSettings = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, {
                            action: "cancel",
                            crashed: false,
                        }];
                });
            });
        };
        APISystemBase.prototype.checkAppSystemPermissions = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, {
                            lackedPermissions: [],
                            error: {},
                        }];
                });
            });
        };
        return APISystemBase;
    }());
    GDK.APISystemBase = APISystemBase;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    var SystemInfoBase = /** @class */ (function () {
        function SystemInfoBase() {
            this.platform = "devtools";
            this.brand = 'unknown';
            this.model = 'unknown';
            this.pixelRatio = -1;
            this.screenWidth = -1;
            this.screenHeight = -1;
            this.windowWidth = -1;
            this.windowHeight = -1;
            this.statusBarHeight = -1;
            this.language = 'zh_CN';
            this.version = '1.0.0';
            this.system = "devtools";
            this.fontSizeSetting = -1;
            this.SDKVersion = '1.0.0';
            this.benchmarkLevel = -1;
            this.networkClass = -1;
            this.networkType = 'unknown';
            this.devPlatform = "devtools";
        }
        SystemInfoBase.prototype.clone = function () {
            var obj = {};
            for (var k in this) {
                obj[k] = this[k];
            }
            obj["uiLanguage"] = slib.i18n.language;
            obj.api = undefined;
            return obj;
        };
        return SystemInfoBase;
    }());
    GDK.SystemInfoBase = SystemInfoBase;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    var LogBase = /** @class */ (function () {
        function LogBase() {
        }
        LogBase.prototype.commitLog = function (key, params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/];
                });
            });
        };
        LogBase.prototype.commitChannelsLog = function (logType, params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/];
                });
            });
        };
        LogBase.prototype.commitPayLog = function (index) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/];
                });
            });
        };
        return LogBase;
    }());
    GDK.LogBase = LogBase;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    var PayBase = /** @class */ (function () {
        function PayBase() {
        }
        PayBase.prototype.consumePurchase = function (params) {
            return new Promise(function (resolve, reject) {
                reject(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_INVALID));
            });
        };
        PayBase.prototype.queryItemInfo = function (params) {
            return new Promise(function (resolve, reject) {
                reject(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_INVALID));
            });
        };
        return PayBase;
    }());
    GDK.PayBase = PayBase;
})(GDK || (GDK = {}));
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var GDK;
(function (GDK) {
    var SimpleEvent = /** @class */ (function (_super) {
        __extends(SimpleEvent, _super);
        function SimpleEvent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return SimpleEvent;
    }(slib.SimpleEvent));
    var OpenDataContext = /** @class */ (function () {
        function OpenDataContext(event) {
            this._event = null;
            this._event = event;
        }
        OpenDataContext.prototype.postMessage = function (message) {
            this._event.emit(message);
        };
        return OpenDataContext;
    }());
    var SubContextBase = /** @class */ (function () {
        function SubContextBase() {
            this._event = new SimpleEvent();
            this._context = new OpenDataContext(this._event);
        }
        SubContextBase.prototype.onMessage = function (callback) {
            return this._event.on(callback);
        };
        SubContextBase.prototype.getOpenDataContext = function () {
            return this._context;
        };
        return SubContextBase;
    }());
    GDK.SubContextBase = SubContextBase;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    var UserBase = /** @class */ (function () {
        function UserBase() {
        }
        UserBase.prototype.setBindCallback = function (callback) {
            this.bindCallback = callback;
        };
        UserBase.prototype.setRebootCallback = function (callback) {
            this.rebootCallback = callback;
        };
        UserBase.prototype.checkSession = function (params) {
            var ret = new GDK.RPromise();
            ret.success(undefined);
            return ret.promise;
        };
        return UserBase;
    }());
    GDK.UserBase = UserBase;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    GDK.defaultGDKName = '';
})(GDK || (GDK = {}));
window['GDK'] = GDK;
var GDK;
(function (GDK) {
    GDK.devlog = new slib.Log({ tags: ["[gdk]", "[frame]"] });
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    /** 请求错误扩展参数 */
    var GDKErrorExtra = /** @class */ (function () {
        function GDKErrorExtra() {
        }
        return GDKErrorExtra;
    }());
    GDK.GDKErrorExtra = GDKErrorExtra;
    /** 请求错误结果 */
    var GDKError = /** @class */ (function (_super) {
        __extends(GDKError, _super);
        function GDKError() {
            var _this = _super.call(this, "") || this;
            _this.message = '';
            _this.name = "GDKError";
            return _this;
        }
        GDKError.prototype.toString = function () {
            return this.name + ": " + this.errCode + " " + this.message + " " + this.reason;
        };
        return GDKError;
    }(Error));
    GDK.GDKError = GDKError;
    /** 请求结果模板生成器 */
    var ResultTemplatesExtractor = /** @class */ (function () {
        function ResultTemplatesExtractor(temps) {
            this._temps = [];
            this._temps = temps;
        }
        Object.defineProperty(ResultTemplatesExtractor.prototype, "temps", {
            get: function () { return this._temps; },
            enumerable: true,
            configurable: true
        });
        /**
         * 根据错误码和扩展参数构造请求结果
         */
        ResultTemplatesExtractor.prototype.make = function (errCode, extra) {
            var err = new GDKError();
            // 待优化
            var item = this._temps.find(function (item) { return item.errCode == errCode; });
            err.errCode = extra && extra.errCode !== undefined ? extra.errCode : item.errCode;
            err.message = extra && extra.message !== undefined ? extra.message : item.message;
            err.reason = extra && extra.reason !== undefined ? extra.reason : item.reason;
            err.data = extra && extra.data !== undefined ? extra.data : item.data;
            return err;
        };
        return ResultTemplatesExtractor;
    }());
    GDK.ResultTemplatesExtractor = ResultTemplatesExtractor;
})(GDK || (GDK = {}));
/// <reference path="ErrorMap.ts" />
var GDK;
(function (GDK) {
    /** 基本请求错误码 */
    GDK.GDKErrorCode = {
        // /** -----------Normal Error----------- */
        /** 请求成功 */
        SUCCESS: 0,
        /** 未知错误 */
        UNKNOWN: 100,
        /** 请求超时 */
        TIMEOUT: 101,
        /** 网络错误 */
        NETWORK_ERROR: 102,
        /** api不可用 */
        API_INVALID: 203,
        // /** -----------GameHttpClient Error----------- */
        /** 无效的OPENID */
        INVALID_OPENID: 2001,
        // /** -----------API Error----------- */
        /** API 登录 */
        API_LOGIN_SUCCESS: 30001,
        /** API 失败 */
        API_LOGIN_FAILED: 30002,
        // /** API 支付 */
        /** API 支付成功 */
        API_PAY_SUCCESS: 30011,
        /** API 支付失败 */
        API_PAY_FAILED: 30012,
        /** API 取消支付 */
        API_PAY_CANCEL: 30013,
        API_PAY_QUERYITEMINFO_FAILED: 30021,
        // /** API 更新用户数据 */
        /** API 更新用户数据失败 */
        API_UPDATE_USERDATA_FAILED: 30102,
        // /** 排行数据 */
        /** 获取好友排行数据失败 */
        API_GET_FRIEND_CLOUD_STORAGE_FAILED: 30112,
        /** 上传用户数据失败 */
        API_SET_USER_CLOUD_STORAGE_FAILED: 30113,
        /** 打开客服反馈界面失败 */
        API_OPEN_FEEDBACK_FAILED: 30122,
        /** 显示 loading 失败 */
        API_SHOW_LOADING_FAILED: 30131,
        /** 隐藏 loading 失败 */
        API_HIDE_LOADING_FAILED: 30132,
        /** 显示 toast 失败 */
        API_SHOW_TOAST_FAILED: 3013,
        /** 隐藏 toast 失败 */
        API_HIDE_TOAST_FAILED: 30134,
        /** 显示 model 失败 */
        API_SHOW_MODAL_FAILED: 30135,
        /** 隐藏 键盘 失败 */
        API_HIDE_KEYBOARD_FAILED: 30141,
        /** 登录态过期 */
        API_LOGIN_SESSION_OUTDATE: 30151,
        /** 更新登录态失败 */
        API_UPDATE_LOGIN_SESSION_FAILED: 30152,
        /** 跳转小程序失败 */
        API_CALL_UP_MINI_PROGRAM_FAILED: 30161,
        /** 跳转原生app失败 */
        API_CALL_UP_NATIVE_APP_FAILED: 30161,
        /**
         * 分享不被支持
         */
        API_SHARE_UNSUPPORTED: 30201,
        /**
         * 不支持的平台
         */
        API_SHARE_UNSUPPORTED_PLATFORM: 30202,
        /**
         * 请求打开并播放广告超时
         */
        API_SHOW_ADVERT_TIMEOUT: 30304,
    };
    /**
     * 请求结果模板，用于生成错误结果
     **/
    GDK.GDKResultTemplates = new GDK.ResultTemplatesExtractor([
        { errCode: GDK.GDKErrorCode.SUCCESS, message: '请求成功', reason: '请求成功', data: null },
        { errCode: GDK.GDKErrorCode.UNKNOWN, message: '请求失败', reason: '未知错误' },
        { errCode: GDK.GDKErrorCode.TIMEOUT, message: '请求超时', reason: '请求超时' },
        { errCode: GDK.GDKErrorCode.NETWORK_ERROR, message: '网络错误', reason: '网络错误' },
        { errCode: GDK.GDKErrorCode.API_INVALID, message: 'api不可用', reason: 'api不可用' },
        { errCode: GDK.GDKErrorCode.INVALID_OPENID, message: '登录失败', reason: 'openId验证失败' },
        { errCode: GDK.GDKErrorCode.API_LOGIN_SUCCESS, message: 'Api登录成功', reason: 'Api登录成功' },
        { errCode: GDK.GDKErrorCode.API_LOGIN_FAILED, message: 'Api登录失败', reason: 'Api登录失败' },
        { errCode: GDK.GDKErrorCode.API_PAY_SUCCESS, message: 'Api支付失败', reason: 'Api支付失败' },
        { errCode: GDK.GDKErrorCode.API_PAY_FAILED, message: 'Api支付失败', reason: 'Api支付失败' },
        { errCode: GDK.GDKErrorCode.API_PAY_CANCEL, message: 'Api支付取消', reason: 'Api支付取消' },
        { errCode: GDK.GDKErrorCode.API_UPDATE_USERDATA_FAILED, message: 'Api更新用户数据失败', reason: 'Api更新用户数据失败' },
        { errCode: GDK.GDKErrorCode.API_GET_FRIEND_CLOUD_STORAGE_FAILED, message: '获取好友排行数据失败' },
        { errCode: GDK.GDKErrorCode.API_SET_USER_CLOUD_STORAGE_FAILED, message: '上传用户数据失败' },
        { errCode: GDK.GDKErrorCode.API_SHOW_LOADING_FAILED, message: '显示 loading 失败' },
        { errCode: GDK.GDKErrorCode.API_HIDE_LOADING_FAILED, message: '隐藏 loading 失败' },
        { errCode: GDK.GDKErrorCode.API_SHOW_TOAST_FAILED, message: '显示 toast 失败' },
        { errCode: GDK.GDKErrorCode.API_HIDE_TOAST_FAILED, message: '隐藏 toast 失败' },
        { errCode: GDK.GDKErrorCode.API_SHOW_MODAL_FAILED, message: '显示 modal 失败' },
        { errCode: GDK.GDKErrorCode.API_HIDE_KEYBOARD_FAILED, message: '登录态过期' },
        { errCode: GDK.GDKErrorCode.API_LOGIN_SESSION_OUTDATE, message: '登录态过期' },
        { errCode: GDK.GDKErrorCode.API_UPDATE_LOGIN_SESSION_FAILED, message: '更新登录态失败' },
        { errCode: GDK.GDKErrorCode.API_CALL_UP_MINI_PROGRAM_FAILED, message: '跳转小程序失败' },
        { errCode: GDK.GDKErrorCode.API_CALL_UP_NATIVE_APP_FAILED, message: '跳转原生app失败' },
        { errCode: GDK.GDKErrorCode.API_SHARE_UNSUPPORTED, message: '分享不被支持' },
        { errCode: GDK.GDKErrorCode.API_SHARE_UNSUPPORTED_PLATFORM, message: '不支持的平台' },
        { errCode: GDK.GDKErrorCode.API_SHOW_ADVERT_TIMEOUT, message: '打开并播放广告超时' },
    ]);
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    var GDKManager = /** @class */ (function () {
        function GDKManager() {
            this._configMap = {};
            this._pluginMap = {};
        }
        GDKManager.prototype.registPluginConfig = function (name, config) {
            slib.assert(!this._configMap[name], "config name " + name + " exists already!");
            this._configMap[name] = config;
            GDK.defaultGDKName = name;
        };
        GDKManager.prototype.genGdk = function (temp) {
            var map = {};
            var addonList = [];
            for (var k in temp) {
                // let pname = k[0].toLocaleLowerCase() + k.substr(1);
                var headLen = 0;
                for (var _i = 0, k_1 = k; _i < k_1.length; _i++) {
                    var c = k_1[_i];
                    if (c.toLocaleLowerCase() == c) {
                        break;
                    }
                    headLen++;
                }
                var pname = k;
                if (headLen == 1) {
                    pname = k[0].toLocaleLowerCase() + k.substr(1);
                }
                else {
                    pname = k.substring(0, headLen - 1).toLocaleLowerCase() + k.substring(headLen - 1);
                }
                map[pname] = new temp[k]();
                addonList.push(map[pname]);
            }
            var api = new GDK.UserAPI(map);
            for (var _a = 0, addonList_1 = addonList; _a < addonList_1.length; _a++) {
                var addon = addonList_1[_a];
                addon.api = api;
            }
            return api;
        };
        /**
         * 设置默认插件
         */
        GDKManager.prototype.setDefaultGdk = function (name) {
            var api = this._pluginMap[name];
            slib.assert(!!api, "invalid api instance [" + name + "]");
            if (gdk instanceof GDK.UserAPI) {
                slib.assert(!gdk, '-[GDK] default gdk instance shall not be set twice');
            }
            gdk = api;
            window["gdk"] = api;
        };
        GDKManager.prototype.getPlugin = function (name) {
            return slib.assert(this._pluginMap[name], "plugin [" + name + "] not exist");
        };
        /**
         * 传入配置并初始化
         */
        GDKManager.prototype.initWithGDKConfig = function (info) {
            for (var k in this._pluginMap) {
                var plugin = this.getPlugin(k);
                // 初始化插件内各个模块
                plugin['_initWithConfig'](info);
            }
        };
        /**
         * 创建插件对象
         */
        GDKManager.prototype.initializeGDKInstance = function () {
            for (var k in this._configMap) {
                var plugin = this.genGdk(new this._configMap[k].register);
                this._pluginMap[k] = plugin;
            }
        };
        return GDKManager;
    }());
    GDK.GDKManager = GDKManager;
    GDK.gdkManager = new GDKManager();
    /**
     * 初始入口
     */
    var FakeUserApi = /** @class */ (function () {
        function FakeUserApi() {
        }
        Object.defineProperty(FakeUserApi.prototype, "pluginName", {
            get: function () {
                return GDK.defaultGDKName;
            },
            enumerable: true,
            configurable: true
        });
        FakeUserApi.prototype.initConfig = function (config) {
            GDK.gdkManager.initializeGDKInstance();
            GDK.gdkManager.setDefaultGdk(GDK.defaultGDKName);
            GDK.gdkManager.initWithGDKConfig(config);
        };
        return FakeUserApi;
    }());
    window['gdk'] = new FakeUserApi();
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    var ModuleClassMap = /** @class */ (function () {
        function ModuleClassMap() {
            this.APISystem = GDK.APISystemBase;
            this.Hardware = GDK.HardwareBase;
            this.Log = GDK.LogBase;
        }
        return ModuleClassMap;
    }());
    GDK.ModuleClassMap = ModuleClassMap;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    var PackConfig = /** @class */ (function () {
        function PackConfig() {
        }
        return PackConfig;
    }());
    GDK.PackConfig = PackConfig;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    var devlog = new slib.Log({ tags: ["DEVELOP"] });
    // 自动生成，成员使用register函数注册
    var UserAPI = /** @class */ (function () {
        function UserAPI(moduleMap) {
            this._m = null;
            this._m = moduleMap;
        }
        UserAPI.prototype.initConfig = function (config) {
            devlog.warn("redundant init for gdk, ignored");
        };
        /**
         * 初始化插件内各个模块
         * @param info 外部传入的配置
         */
        UserAPI.prototype._initWithConfig = function (info) {
            for (var key in this._m) {
                // 初始化广告等具体模块
                var addon = this._m[key];
                if (addon.init) {
                    addon.init();
                }
                if (addon.initWithConfig) {
                    addon.initWithConfig(info);
                }
            }
        };
        UserAPI.prototype.checkModuleAttr = function (moduleName, attrName, attrType) {
            if (attrType === void 0) { attrType = undefined; }
            slib.assert(this._m, "api not init");
            if (typeof this._m[moduleName] != "object") {
                devlog.warn("module unsupport: [gdk::" + moduleName + "]");
                return false;
            }
            if (attrType) {
                var attr = this._m[moduleName][attrName];
                if (!attr) {
                    devlog.warn("func unsupport: [gdk::" + moduleName + "." + attrName + "]");
                    return false;
                }
                if (typeof attr != attrType) {
                    devlog.warn("invalid type<" + attrType + ">: [gdk::" + moduleName + "." + attrName + "]");
                    return false;
                }
            }
            return true;
        };
        UserAPI.prototype.createNonePromise = function (tip) {
            if (tip === void 0) { tip = ""; }
            return new Promise(function (resolve, reject) {
                setTimeout(function () {
                    reject("something unsupport " + tip + " to call");
                });
            });
        };
        UserAPI.prototype.support = function (moduleName, attrName, attrType) {
            if (attrType === void 0) { attrType = undefined; }
            return this.checkModuleAttr(moduleName, attrName, attrType);
        };
        Object.defineProperty(UserAPI.prototype, "userData", {
            get: function () {
                return this._m.userData;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "gameInfo", {
            get: function () {
                return this._m.gameInfo;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "systemInfo", {
            get: function () {
                return this._m.systemInfo;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "openId", {
            /** 批量导出接口 */
            // $batch_export() begin
            get: function () {
                if (!this.checkModuleAttr("userData", "openId")) {
                    return undefined;
                }
                return this._m.userData.openId;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "openKey", {
            get: function () {
                if (!this.checkModuleAttr("userData", "openKey")) {
                    return undefined;
                }
                return this._m.userData.openKey;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "password", {
            /** 密码 */
            get: function () {
                if (!this.checkModuleAttr("userData", "password")) {
                    return undefined;
                }
                return this._m.userData.password;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "nickName", {
            /** 昵称 */
            get: function () {
                if (!this.checkModuleAttr("userData", "nickName")) {
                    return undefined;
                }
                return this._m.userData.nickName;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "userId", {
            /** 用户ID */
            get: function () {
                if (!this.checkModuleAttr("userData", "userId")) {
                    return undefined;
                }
                return this._m.userData.userId;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "isNewUser", {
            /** 是否新用户 */
            get: function () {
                if (!this.checkModuleAttr("userData", "isNewUser")) {
                    return undefined;
                }
                return this._m.userData.isNewUser;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "avatarUrl", {
            /** 用户头像 */
            get: function () {
                if (!this.checkModuleAttr("userData", "avatarUrl")) {
                    return undefined;
                }
                return this._m.userData.avatarUrl;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "backupTime", {
            /** 上传存档时间(秒) */
            get: function () {
                if (!this.checkModuleAttr("userData", "backupTime")) {
                    return undefined;
                }
                return this._m.userData.backupTime;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "followGzh", {
            /** 是否已关注公众号
             * - 0 未关注
             * - 1 已关注
             **/
            get: function () {
                if (!this.checkModuleAttr("userData", "followGzh")) {
                    return undefined;
                }
                return this._m.userData.followGzh;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "channelId", {
            /** 渠道id */
            get: function () {
                if (!this.checkModuleAttr("userData", "channelId")) {
                    return undefined;
                }
                return this._m.userData.channelId;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "createTime", {
            /** 创建时间 */
            get: function () {
                if (!this.checkModuleAttr("userData", "createTime")) {
                    return undefined;
                }
                return this._m.userData.createTime;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "sex", {
            /**
             * 性别
             * - 0 未知
             * - 1 男
             * - 2 女
             **/
            get: function () {
                if (!this.checkModuleAttr("userData", "sex")) {
                    return undefined;
                }
                return this._m.userData.sex;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "isWhiteUser", {
            /**
             * 是否为该游戏管理账号用户
             * - 1 是
             * - 0 否
             **/
            get: function () {
                if (!this.checkModuleAttr("userData", "isWhiteUser")) {
                    return undefined;
                }
                return this._m.userData.isWhiteUser;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "isMaster", {
            /**
             * 是否房主，1房主，0参加者
             **/
            get: function () {
                if (!this.checkModuleAttr("userData", "isMaster")) {
                    return undefined;
                }
                return this._m.userData.isMaster;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "roomId", {
            /**
             * 房间号
             **/
            get: function () {
                if (!this.checkModuleAttr("userData", "roomId")) {
                    return undefined;
                }
                return this._m.userData.roomId;
            },
            enumerable: true,
            configurable: true
        });
        /** 登录 */
        UserAPI.prototype.login = function (params) {
            if (!this.checkModuleAttr("user", "login", "function")) {
                return this.createNonePromise("[user.login]");
            }
            return this._m.user.login(params);
        };
        /** 绑定回调 */
        UserAPI.prototype.setBindCallback = function (callback) {
            if (!this.checkModuleAttr("user", "setBindCallback", "function")) {
                return undefined;
            }
            return this._m.user.setBindCallback(callback);
        };
        /** 绑定回调 */
        UserAPI.prototype.setRebootCallback = function (callback) {
            if (!this.checkModuleAttr("user", "setRebootCallback", "function")) {
                return undefined;
            }
            return this._m.user.setRebootCallback(callback);
        };
        /**
         * 显示用户中心
         * * APP平台支持
         */
        UserAPI.prototype.showUserCenter = function () {
            if (!this.checkModuleAttr("user", "showUserCenter", "function")) {
                return this.createNonePromise("[user.showUserCenter]");
            }
            return this._m.user.showUserCenter();
        };
        /**
         * 判断是否为本地实名制系统
         */
        UserAPI.prototype.isNativeRealNameSystem = function () {
            if (!this.checkModuleAttr("user", "isNativeRealNameSystem", "function")) {
                return undefined;
            }
            return this._m.user.isNativeRealNameSystem();
        };
        /**
         * 显示未成年人游戏描述信息
         * * APP平台支持
         */
        UserAPI.prototype.showMinorInfo = function (info) {
            if (!this.checkModuleAttr("user", "showMinorInfo", "function")) {
                return this.createNonePromise("[user.showMinorInfo]");
            }
            return this._m.user.showMinorInfo(info);
        };
        /**
         * 显示实名制弹框，进入实名制流程
         * * APP平台支持
         * @param force 是否强制
         */
        UserAPI.prototype.showRealNameDialog = function (userID, force) {
            if (!this.checkModuleAttr("user", "showRealNameDialog", "function")) {
                return this.createNonePromise("[user.showRealNameDialog]");
            }
            return this._m.user.showRealNameDialog(userID, force);
        };
        /**
         * 显示账号绑定
         * * APP平台支持
         */
        UserAPI.prototype.showBindDialog = function () {
            if (!this.checkModuleAttr("user", "showBindDialog", "function")) {
                return this.createNonePromise("[user.showBindDialog]");
            }
            return this._m.user.showBindDialog();
        };
        /** 检查登录态是否过期 */
        UserAPI.prototype.checkSession = function (params) {
            if (!this.checkModuleAttr("user", "checkSession", "function")) {
                return this.createNonePromise("[user.checkSession]");
            }
            return this._m.user.checkSession(params);
        };
        /** 更新用户数据 */
        UserAPI.prototype.updateUser = function () {
            if (!this.checkModuleAttr("user", "update", "function")) {
                return this.createNonePromise("[user.update]");
            }
            return this._m.user.update();
        };
        /**
         * 获取用户云端数据
         * - oppo未处理
         */
        UserAPI.prototype.getFriendCloudStorage = function (obj) {
            if (!this.checkModuleAttr("user", "getFriendCloudStorage", "function")) {
                return this.createNonePromise("[user.getFriendCloudStorage]");
            }
            return this._m.user.getFriendCloudStorage(obj);
        };
        /**
         * 提交用户云端数据
         * - oppo未处理
         */
        UserAPI.prototype.setUserCloudStorage = function (obj) {
            if (!this.checkModuleAttr("user", "setUserCloudStorage", "function")) {
                return this.createNonePromise("[user.setUserCloudStorage]");
            }
            return this._m.user.setUserCloudStorage(obj);
        };
        /**
         * 判断userId对应的用户是否绑定过社交账号
         * @param userId 登录时服务器返回的userId
         */
        UserAPI.prototype.checkIsUserBind = function (userId) {
            if (!this.checkModuleAttr("user", "checkIsUserBind", "function")) {
                return undefined;
            }
            return this._m.user.checkIsUserBind(userId);
        };
        // }
        UserAPI.prototype.setLoginSupport = function (loginSupport) {
            if (!this.checkModuleAttr("user", "setLoginSupport", "function")) {
                return undefined;
            }
            return this._m.user.setLoginSupport(loginSupport);
        };
        UserAPI.prototype.setAccountChangeListener = function (f) {
            if (!this.checkModuleAttr("user", "setAccountChangeListener", "function")) {
                return undefined;
            }
            return this._m.user.setAccountChangeListener(f);
        };
        Object.defineProperty(UserAPI.prototype, "mode", {
            /**
             * 游戏的启动模式，可以是：
             * - 开发
             * - 测试
             * - 发布
             */
            get: function () {
                if (!this.checkModuleAttr("gameInfo", "mode")) {
                    return undefined;
                }
                return this._m.gameInfo.mode;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "appId", {
            /**
             * 程序appid
             */
            get: function () {
                if (!this.checkModuleAttr("gameInfo", "appId")) {
                    return undefined;
                }
                return this._m.gameInfo.appId;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "gameChannelId", {
            /**
             * 游戏启动的渠道id
             */
            get: function () {
                if (!this.checkModuleAttr("gameInfo", "gameChannelId")) {
                    return undefined;
                }
                return this._m.gameInfo.gameChannelId;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "isPayInSandbox", {
            /** 沙盒模式支付 */
            get: function () {
                if (!this.checkModuleAttr("gameInfo", "isPayInSandbox")) {
                    return undefined;
                }
                return this._m.gameInfo.isPayInSandbox;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "payAppEnvVersion", {
            /** 跳转支付app模式 */
            get: function () {
                if (!this.checkModuleAttr("gameInfo", "payAppEnvVersion")) {
                    return undefined;
                }
                return this._m.gameInfo.payAppEnvVersion;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "offerId", {
            /** 支付侧应用id */
            get: function () {
                if (!this.checkModuleAttr("gameInfo", "offerId")) {
                    return undefined;
                }
                return this._m.gameInfo.offerId;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "miniAppOfferId", {
            /**
             * 跳转小程序支付offerid
             * - 填对方小程序appid
             **/
            get: function () {
                if (!this.checkModuleAttr("gameInfo", "miniAppOfferId")) {
                    return undefined;
                }
                return this._m.gameInfo.miniAppOfferId;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "shareProxyUrl", {
            /**
             * 分享结果检测的代理网址
             * * 仅微信使用
             */
            get: function () {
                if (!this.checkModuleAttr("gameInfo", "shareProxyUrl")) {
                    return undefined;
                }
                return this._m.gameInfo.shareProxyUrl;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "launchOptions", {
            /** 小游戏启动时的参数。 */
            get: function () {
                if (!this.checkModuleAttr("gameInfo", "launchOptions")) {
                    return undefined;
                }
                return this._m.gameInfo.launchOptions;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "gameVersion", {
            /**
             * 游戏版本号
             **/
            get: function () {
                if (!this.checkModuleAttr("gameInfo", "gameVersion")) {
                    return undefined;
                }
                return this._m.gameInfo.gameVersion;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "gameId", {
            /**
             * 游戏id
             **/
            get: function () {
                if (!this.checkModuleAttr("gameInfo", "gameId")) {
                    return undefined;
                }
                return this._m.gameInfo.gameId;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "gameType", {
            /**
             * 游戏类型(手Q7.6.5及以上支持) 0: 普通游戏 1：红包游戏
             **/
            get: function () {
                if (!this.checkModuleAttr("gameInfo", "gameType")) {
                    return undefined;
                }
                return this._m.gameInfo.gameType;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "requireCustomServicePay", {
            /**
             * 优先只启用客服跳转支付
             * - 支持ios和安卓
             */
            get: function () {
                if (!this.checkModuleAttr("gameInfo", "requireCustomServicePay")) {
                    return undefined;
                }
                return this._m.gameInfo.requireCustomServicePay;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "requireMiniAppPay", {
            /**
             * 优先只启用小程序跳转支付
             * 只支持安卓
             */
            get: function () {
                if (!this.checkModuleAttr("gameInfo", "requireMiniAppPay")) {
                    return undefined;
                }
                return this._m.gameInfo.requireMiniAppPay;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "requireIndiaSPSPay", {
            get: function () {
                if (!this.checkModuleAttr("gameInfo", "requireIndiaSPSPay")) {
                    return undefined;
                }
                return this._m.gameInfo.requireIndiaSPSPay;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "brand", {
            /**
             * 手机品牌
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "brand")) {
                    return undefined;
                }
                return this._m.systemInfo.brand;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "model", {
            /**
             * - 手机型号
             * - 具体机型(微信、手Q7.6.3及以上支持) 形如 "PRO 6 Plus"
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "model")) {
                    return undefined;
                }
                return this._m.systemInfo.model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "pixelRatio", {
            /**
             * 设备像素比
             * - -1 代表未知
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "pixelRatio")) {
                    return undefined;
                }
                return this._m.systemInfo.pixelRatio;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "screenWidth", {
            /**
             * 屏幕宽度
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "screenWidth")) {
                    return undefined;
                }
                return this._m.systemInfo.screenWidth;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "screenHeight", {
            /**
             * 屏幕高度
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "screenHeight")) {
                    return undefined;
                }
                return this._m.systemInfo.screenHeight;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "windowWidth", {
            /**
             * 可使用窗口宽度
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "windowWidth")) {
                    return undefined;
                }
                return this._m.systemInfo.windowWidth;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "windowHeight", {
            /**
             * 可使用窗口高度
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "windowHeight")) {
                    return undefined;
                }
                return this._m.systemInfo.windowHeight;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "statusBarHeight", {
            /**
             * 状态栏的高度
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "statusBarHeight")) {
                    return undefined;
                }
                return this._m.systemInfo.statusBarHeight;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "language", {
            /**
             * 平台（微信、QQ等）设置的语言
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "language")) {
                    return undefined;
                }
                return this._m.systemInfo.language;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "version", {
            /**
             * 版本号
             * * 微信版本号
             * * 安卓版本号
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "version")) {
                    return undefined;
                }
                return this._m.systemInfo.version;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "system", {
            /**
             * 操作系统版本，形如 "Android 5.0"
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "system")) {
                    return undefined;
                }
                return this._m.systemInfo.system;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "platform", {
            /**
             * 客户端平台
             * - "android" | "ios" | "devtools" | ...
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "platform")) {
                    return undefined;
                }
                return this._m.systemInfo.platform;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "fontSizeSetting", {
            /**
             * 用户字体大小设置。以“我 - 设置 - 通用 - 字体大小”中的设置为准，单位 px。
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "fontSizeSetting")) {
                    return undefined;
                }
                return this._m.systemInfo.fontSizeSetting;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "SDKVersion", {
            /**
             * - wx 客户端基础库版本
             * - app nativeVersion
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "SDKVersion")) {
                    return undefined;
                }
                return this._m.systemInfo.SDKVersion;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "benchmarkLevel", {
            /**
             * (仅Android小游戏) 性能等级
             * - -2 或 0：该设备无法运行小游戏
             * - -1：性能未知
             * - `>=` 1 设备性能值
             * - 该值越高，设备性能越好(目前设备最高不到50)
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "benchmarkLevel")) {
                    return undefined;
                }
                return this._m.systemInfo.benchmarkLevel;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "networkType", {
            /**
             * 网络类型
             * - `wifi`	wifi 网络
             * - `2g`	2g 网络
             * - `3g`	3g 网络
             * - `4g`	4g 网络
             * - `unknown`	Android 下不常见的网络类型
             * - `none`	无网络
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "networkType")) {
                    return undefined;
                }
                return this._m.systemInfo.networkType;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "networkClass", {
            /**
             * 网络类型 1 电信 ，2 联通 ，3 移动
             * - 0: wifi或未知
             * -1 无网络
             * -2 2G/3G/4G/nG 网络
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "networkClass")) {
                    return undefined;
                }
                return this._m.systemInfo.networkClass;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "isFirstInstall", {
            /**
             * 是否首次安装
             * - 1为首次安装
             * - 0非首次安装
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "isFirstInstall")) {
                    return undefined;
                }
                return this._m.systemInfo.isFirstInstall;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "devPlatform", {
            /**
             * 仅在开发环境下可以，手q环境下无该字段
             **/
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "devPlatform")) {
                    return undefined;
                }
                return this._m.systemInfo.devPlatform;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "deviceId", {
            /**
             * 设备ID
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "deviceId")) {
                    return undefined;
                }
                return this._m.systemInfo.deviceId;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "uuid", {
            /**
             * 设备ID
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "uuid")) {
                    return undefined;
                }
                return this._m.systemInfo.uuid;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "gameDeviceId", {
            /**
             * 游戏设备ID，每次重新安装游戏都会改变
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "gameDeviceId")) {
                    return undefined;
                }
                return this._m.systemInfo.gameDeviceId;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "versionCode", {
            /**
             * 版本号
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "versionCode")) {
                    return undefined;
                }
                return this._m.systemInfo.versionCode;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "versionName", {
            /**
             * 版本名称
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "versionName")) {
                    return undefined;
                }
                return this._m.systemInfo.versionName;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "channel", {
            /**
             * 渠道ID
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "channel")) {
                    return undefined;
                }
                return this._m.systemInfo.channel;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "quickChannelId", {
            /**
             * quick渠道ID
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "quickChannelId")) {
                    return undefined;
                }
                return this._m.systemInfo.quickChannelId;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "country", {
            /**
             * 地区国家
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "country")) {
                    return undefined;
                }
                return this._m.systemInfo.country;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "installTime", {
            /**
             * 安装时间
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "installTime")) {
                    return undefined;
                }
                return this._m.systemInfo.installTime;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "imei", {
            /**
             * imei
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "imei")) {
                    return undefined;
                }
                return this._m.systemInfo.imei;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "packageName", {
            /**
             * 包名
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "packageName")) {
                    return undefined;
                }
                return this._m.systemInfo.packageName;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "packageTag", {
            /**
             * 发行渠道
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "packageTag")) {
                    return undefined;
                }
                return this._m.systemInfo.packageTag;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "debugAccountServer", {
            /**
             * 测试用 account server
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "debugAccountServer")) {
                    return undefined;
                }
                return this._m.systemInfo.debugAccountServer;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "isCustomBackendCfg", {
            /**
             * 是否支持按packageTag 定制后端参数
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "isCustomBackendCfg")) {
                    return undefined;
                }
                return this._m.systemInfo.isCustomBackendCfg;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "androidId", {
            /**
             * android id
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "androidId")) {
                    return undefined;
                }
                return this._m.systemInfo.androidId;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "mac", {
            /**
             * mac address
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "mac")) {
                    return undefined;
                }
                return this._m.systemInfo.mac;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "userAgent", {
            /**
             * http user Agent
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "userAgent")) {
                    return undefined;
                }
                return this._m.systemInfo.userAgent;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "tableConf", {
            /**
             * 服务器表格配置信息
             */
            get: function () {
                if (!this.checkModuleAttr("systemInfo", "tableConf")) {
                    return undefined;
                }
                return this._m.systemInfo.tableConf;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 刷新网络状况信息
         */
        UserAPI.prototype.fetchNetworkInfo = function () {
            if (!this.checkModuleAttr("systemInfo", "fetchNetworkInfo", "function")) {
                return this.createNonePromise("[systemInfo.fetchNetworkInfo]");
            }
            return this._m.systemInfo.fetchNetworkInfo();
        };
        UserAPI.prototype.clone = function () {
            if (!this.checkModuleAttr("systemInfo", "clone", "function")) {
                return undefined;
            }
            return this._m.systemInfo.clone();
        };
        /**
         * 跳转游戏
         */
        UserAPI.prototype.navigateToApp = function (params) {
            if (!this.checkModuleAttr("apiSystem", "navigateToApp", "function")) {
                return this.createNonePromise("[apiSystem.navigateToApp]");
            }
            return this._m.apiSystem.navigateToApp(params);
        };
        /**
         * 退出当前游戏
         */
        UserAPI.prototype.exitProgram = function () {
            if (!this.checkModuleAttr("apiSystem", "exitProgram", "function")) {
                return this.createNonePromise("[apiSystem.exitProgram]");
            }
            return this._m.apiSystem.exitProgram();
        };
        /**
         * 用法示例：
         * ```typescript
         * onShow((data)=>{
         * 	...
         * })
         * ```
         */
        UserAPI.prototype.onShow = function (callback) {
            if (!this.checkModuleAttr("apiSystem", "onShow", "function")) {
                return undefined;
            }
            return this._m.apiSystem.onShow(callback);
        };
        UserAPI.prototype.offShow = function (callback) {
            if (!this.checkModuleAttr("apiSystem", "offShow", "function")) {
                return undefined;
            }
            return this._m.apiSystem.offShow(callback);
        };
        /**
         * 用法示例：
         * ```typescript
         * onHide(()=>{
         * 	...
         * })
         * ```
         */
        UserAPI.prototype.onHide = function (callback) {
            if (!this.checkModuleAttr("apiSystem", "onHide", "function")) {
                return undefined;
            }
            return this._m.apiSystem.onHide(callback);
        };
        UserAPI.prototype.offHide = function (callback) {
            if (!this.checkModuleAttr("apiSystem", "offHide", "function")) {
                return undefined;
            }
            return this._m.apiSystem.offHide(callback);
        };
        /**
         * 强制更新
         */
        UserAPI.prototype.updateProgramForce = function () {
            if (!this.checkModuleAttr("apiSystem", "updateProgramForce", "function")) {
                return this.createNonePromise("[apiSystem.updateProgramForce]");
            }
            return this._m.apiSystem.updateProgramForce();
        };
        /**
         * 设置是否打开调试开关。此开关对正式版也能生效。
         */
        UserAPI.prototype.setEnableDebug = function (res) {
            if (!this.checkModuleAttr("apiSystem", "setEnableDebug", "function")) {
                return this.createNonePromise("[apiSystem.setEnableDebug]");
            }
            return this._m.apiSystem.setEnableDebug(res);
        };
        /**
         * - 设置帧率
         * 	- 可能和cocos的会冲突
         */
        UserAPI.prototype.setFPS = function (fps) {
            if (!this.checkModuleAttr("apiSystem", "setFPS", "function")) {
                return undefined;
            }
            return this._m.apiSystem.setFPS(fps);
        };
        Object.defineProperty(UserAPI.prototype, "clipboard", {
            /**
             * 剪切板
             */
            get: function () {
                if (!this.checkModuleAttr("apiSystem", "clipboard")) {
                    return undefined;
                }
                return this._m.apiSystem.clipboard;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 获取屏幕的安全区域，单位像素
         * @param callback
         */
        UserAPI.prototype.getSafeArea = function (callback) {
            if (!this.checkModuleAttr("apiSystem", "getSafeArea", "function")) {
                return undefined;
            }
            return this._m.apiSystem.getSafeArea(callback);
        };
        // 设置加载进度
        UserAPI.prototype.setLoadingProgress = function (params) {
            if (!this.checkModuleAttr("apiSystem", "setLoadingProgress", "function")) {
                return undefined;
            }
            return this._m.apiSystem.setLoadingProgress(params);
        };
        /**
         * 网页跳转
         * @param url
         */
        UserAPI.prototype.openURL = function (url) {
            if (!this.checkModuleAttr("apiSystem", "openURL", "function")) {
                return undefined;
            }
            return this._m.apiSystem.openURL(url);
        };
        /**
         * 开启云客服
         */
        UserAPI.prototype.startYunkefu = function (accessId, name, id, customField, native) {
            if (!this.checkModuleAttr("apiSystem", "startYunkefu", "function")) {
                return undefined;
            }
            return this._m.apiSystem.startYunkefu(accessId, name, id, customField, native);
        };
        /**
         *
         * 是否存在原生客服中心
         */
        UserAPI.prototype.hasNativeAssistantCenter = function () {
            if (!this.checkModuleAttr("apiSystem", "hasNativeAssistantCenter", "function")) {
                return undefined;
            }
            return this._m.apiSystem.hasNativeAssistantCenter();
        };
        /**
         * hack web
         * @param url
         */
        UserAPI.prototype.showHackWeb = function (url, duration) {
            if (!this.checkModuleAttr("apiSystem", "showHackWeb", "function")) {
                return undefined;
            }
            return this._m.apiSystem.showHackWeb(url, duration);
        };
        /**
         * set native sdk language
         * @param lang
         */
        UserAPI.prototype.setSDKLanguage = function (lang) {
            if (!this.checkModuleAttr("apiSystem", "setSDKLanguage", "function")) {
                return undefined;
            }
            return this._m.apiSystem.setSDKLanguage(lang);
        };
        Object.defineProperty(UserAPI.prototype, "nativeVersion", {
            /**
             * 原生版本号，具体看C++
             */
            get: function () {
                if (!this.checkModuleAttr("apiSystem", "nativeVersion")) {
                    return undefined;
                }
                return this._m.apiSystem.nativeVersion;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "sdkFrameworkVersion", {
            /**
             * SDK框架版本
             */
            get: function () {
                if (!this.checkModuleAttr("apiSystem", "sdkFrameworkVersion")) {
                    return undefined;
                }
                return this._m.apiSystem.sdkFrameworkVersion;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 跳转app设置界面
         * - 目前只支持 android
         */
        UserAPI.prototype.gotoAppSystemSettings = function (params) {
            if (!this.checkModuleAttr("apiSystem", "gotoAppSystemSettings", "function")) {
                return this.createNonePromise("[apiSystem.gotoAppSystemSettings]");
            }
            return this._m.apiSystem.gotoAppSystemSettings(params);
        };
        /**
         * 检查是否已授予权限
         * - 目前只支持 android
         */
        UserAPI.prototype.checkAppSystemPermissions = function (params) {
            if (!this.checkModuleAttr("apiSystem", "checkAppSystemPermissions", "function")) {
                return this.createNonePromise("[apiSystem.checkAppSystemPermissions]");
            }
            return this._m.apiSystem.checkAppSystemPermissions(params);
        };
        /**
         * 分享到聊天窗口
         * * 如果目标平台没有明确的聊天窗口，则进行社会化分享。
         * * 如果当前环境无法分享，则分享失败
         */
        UserAPI.prototype.share = function (data) {
            if (!this.checkModuleAttr("share", "share", "function")) {
                return this.createNonePromise("[share.share]");
            }
            return this._m.share.share(data);
        };
        /**
         * 社会化分享
         * * 如果目标平台无法进行社会化分享，则选用聊天窗口分享。
         * * 如果当前环境无法分享，则分享失败
         */
        UserAPI.prototype.socialShare = function (data) {
            if (!this.checkModuleAttr("share", "socialShare", "function")) {
                return this.createNonePromise("[share.socialShare]");
            }
            return this._m.share.socialShare(data);
        };
        /**
         * 分享网址
         * * 如果当前环境无法进行URL分享，则分享失败
         * * 当前仅 QQPlay 环境支持
         */
        UserAPI.prototype.shareUrl = function (data) {
            if (!this.checkModuleAttr("share", "shareUrl", "function")) {
                return this.createNonePromise("[share.shareUrl]");
            }
            return this._m.share.shareUrl(data);
        };
        /**
         * 显示分享菜单
         * * 微信平台必须调用该函数才会显示转发按钮
         * * QQ平台默认就有转发按钮
         */
        UserAPI.prototype.showShareMenu = function () {
            if (!this.checkModuleAttr("share", "showShareMenu", "function")) {
                return this.createNonePromise("[share.showShareMenu]");
            }
            return this._m.share.showShareMenu();
        };
        /**
         * 隐藏分享菜单
         */
        UserAPI.prototype.hideShareMenu = function () {
            if (!this.checkModuleAttr("share", "hideShareMenu", "function")) {
                return this.createNonePromise("[share.hideShareMenu]");
            }
            return this._m.share.hideShareMenu();
        };
        /**
         * 在某些平台可以设置分享按钮所分享的内容
         * * 微信支持
         * * QQplay 无效
         */
        UserAPI.prototype.setShareMenuData = function (data) {
            if (!this.checkModuleAttr("share", "setShareMenuData", "function")) {
                return this.createNonePromise("[share.setShareMenuData]");
            }
            return this._m.share.setShareMenuData(data);
        };
        /**
         * 获取通过点击分享链接时或传递的参数
         */
        UserAPI.prototype.getShareParam = function () {
            if (!this.checkModuleAttr("share", "getShareParam", "function")) {
                return this.createNonePromise("[share.getShareParam]");
            }
            return this._m.share.getShareParam();
        };
        /**
         * 获取通过点击分享链接时或传递的参数
         */
        UserAPI.prototype.getShareTicket = function () {
            if (!this.checkModuleAttr("share", "getShareTicket", "function")) {
                return this.createNonePromise("[share.getShareTicket]");
            }
            return this._m.share.getShareTicket();
        };
        /**
         * 获取分享的信息
         * * 当前仅微信环境有效
         */
        UserAPI.prototype.getShareInfo = function (shareTicket) {
            if (!this.checkModuleAttr("share", "getShareInfo", "function")) {
                return this.createNonePromise("[share.getShareInfo]");
            }
            return this._m.share.getShareInfo(shareTicket);
        };
        /**
         * 调起支付
         */
        UserAPI.prototype.payPurchase = function (item, options) {
            if (!this.checkModuleAttr("pay", "payPurchase", "function")) {
                return this.createNonePromise("[pay.payPurchase]");
            }
            return this._m.pay.payPurchase(item, options);
        };
        /**
         * 消耗商品
         */
        UserAPI.prototype.consumePurchase = function (params) {
            if (!this.checkModuleAttr("pay", "consumePurchase", "function")) {
                return this.createNonePromise("[pay.consumePurchase]");
            }
            return this._m.pay.consumePurchase(params);
        };
        /**
         * 查询未消耗商品信息
         */
        UserAPI.prototype.queryItemInfo = function (params) {
            if (!this.checkModuleAttr("pay", "queryItemInfo", "function")) {
                return this.createNonePromise("[pay.queryItemInfo]");
            }
            return this._m.pay.queryItemInfo(params);
        };
        Object.defineProperty(UserAPI.prototype, "needInitAdServiceFirst", {
            /**
             * 是否需要先初始化广告服务
             */
            get: function () {
                if (!this.checkModuleAttr("advert", "needInitAdServiceFirst")) {
                    return undefined;
                }
                return this._m.advert.needInitAdServiceFirst;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 初始化广告服务
         */
        UserAPI.prototype.initAdService = function (params) {
            if (!this.checkModuleAttr("advert", "initAdService", "function")) {
                return this.createNonePromise("[advert.initAdService]");
            }
            return this._m.advert.initAdService(params);
        };
        /**
         * 是个单例
         * 创建激励视频广告对象
         */
        UserAPI.prototype.createRewardedVideoAd = function (params) {
            if (!this.checkModuleAttr("advert", "createRewardedVideoAd", "function")) {
                return undefined;
            }
            return this._m.advert.createRewardedVideoAd(params);
        };
        /** 创建条幅广告对象 */
        UserAPI.prototype.createBannerAd = function (params) {
            if (!this.checkModuleAttr("advert", "createBannerAd", "function")) {
                return undefined;
            }
            return this._m.advert.createBannerAd(params);
        };
        Object.defineProperty(UserAPI.prototype, "supportInterstitialAd", {
            /**
             * 是否支持插屏广告
             */
            get: function () {
                if (!this.checkModuleAttr("advert", "supportInterstitialAd")) {
                    return undefined;
                }
                return this._m.advert.supportInterstitialAd;
            },
            enumerable: true,
            configurable: true
        });
        UserAPI.prototype.createInterstitialAd = function (params) {
            if (!this.checkModuleAttr("advert", "createInterstitialAd", "function")) {
                return undefined;
            }
            return this._m.advert.createInterstitialAd(params);
        };
        Object.defineProperty(UserAPI.prototype, "supportFullscreenAd", {
            /**
             * @deprecated 是否支持全屏视频广告
             */
            get: function () {
                if (!this.checkModuleAttr("advert", "supportFullscreenAd")) {
                    return undefined;
                }
                return this._m.advert.supportFullscreenAd;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "supportFullscreenVideoAd", {
            /**
             * 是否支持全屏视频广告
             */
            get: function () {
                if (!this.checkModuleAttr("advert", "supportFullscreenVideoAd")) {
                    return undefined;
                }
                return this._m.advert.supportFullscreenVideoAd;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 创建全屏广告
         */
        UserAPI.prototype.createFullscreenVideoAd = function (params) {
            if (!this.checkModuleAttr("advert", "createFullscreenVideoAd", "function")) {
                return undefined;
            }
            return this._m.advert.createFullscreenVideoAd(params);
        };
        Object.defineProperty(UserAPI.prototype, "supportFeedAd", {
            /**
             * 是否支持信息流广告
             */
            get: function () {
                if (!this.checkModuleAttr("advert", "supportFeedAd")) {
                    return undefined;
                }
                return this._m.advert.supportFeedAd;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 创建信息流广告
         */
        UserAPI.prototype.createFeedAd = function (params) {
            if (!this.checkModuleAttr("advert", "createFeedAd", "function")) {
                return undefined;
            }
            return this._m.advert.createFeedAd(params);
        };
        /**
         * 切换广告平台
         */
        UserAPI.prototype.selectAdvertPlatform = function (params) {
            if (!this.checkModuleAttr("advert", "selectAdvertPlatform", "function")) {
                return this.createNonePromise("[advert.selectAdvertPlatform]");
            }
            return this._m.advert.selectAdvertPlatform(params);
        };
        /**
         * 切换广告平台
         */
        UserAPI.prototype.initMultAdSlot = function (params) {
            if (!this.checkModuleAttr("advert", "initMultAdSlot", "function")) {
                return this.createNonePromise("[advert.initMultAdSlot]");
            }
            return this._m.advert.initMultAdSlot(params);
        };
        /**
         * - 进入客服会话。
         * 	- 微信小游戏要求在用户发生过至少一次 touch 事件后才能调用。后台接入方式与小程序一致
         */
        UserAPI.prototype.openCustomerServiceConversation = function (params) {
            if (!this.checkModuleAttr("customer", "openCustomerServiceConversation", "function")) {
                return undefined;
            }
            return this._m.customer.openCustomerServiceConversation(params);
        };
        Object.defineProperty(UserAPI.prototype, "keyboard", {
            /** 系统键盘对象 */
            get: function () {
                if (!this.checkModuleAttr("widgets", "keyboard")) {
                    return undefined;
                }
                return this._m.widgets.keyboard;
            },
            enumerable: true,
            configurable: true
        });
        /** 显示 loading 提示框。需主动调用 wx.hideLoading 才能关闭提示框 */
        UserAPI.prototype.showLoading = function (object) {
            if (!this.checkModuleAttr("widgets", "showLoading", "function")) {
                return this.createNonePromise("[widgets.showLoading]");
            }
            return this._m.widgets.showLoading(object);
        };
        /** 隐藏 loading 提示框 */
        UserAPI.prototype.hideLoading = function () {
            if (!this.checkModuleAttr("widgets", "hideLoading", "function")) {
                return this.createNonePromise("[widgets.hideLoading]");
            }
            return this._m.widgets.hideLoading();
        };
        /** 显示消息提示框 */
        UserAPI.prototype.showToast = function (object) {
            if (!this.checkModuleAttr("widgets", "showToast", "function")) {
                return this.createNonePromise("[widgets.showToast]");
            }
            return this._m.widgets.showToast(object);
        };
        /** 隐藏消息提示框 */
        UserAPI.prototype.hideToast = function () {
            if (!this.checkModuleAttr("widgets", "hideToast", "function")) {
                return this.createNonePromise("[widgets.hideToast]");
            }
            return this._m.widgets.hideToast();
        };
        /**
         * 显示模态对话框
         * - 有`确定`和`取消`两个按钮
         */
        UserAPI.prototype.showConfirm = function (object) {
            if (!this.checkModuleAttr("widgets", "showConfirm", "function")) {
                return this.createNonePromise("[widgets.showConfirm]");
            }
            return this._m.widgets.showConfirm(object);
        };
        /**
         * 显示模态对话框
         * - 有`确定`和`取消`两个按钮
         */
        UserAPI.prototype.showPrompt = function (object) {
            if (!this.checkModuleAttr("widgets", "showPrompt", "function")) {
                return this.createNonePromise("[widgets.showPrompt]");
            }
            return this._m.widgets.showPrompt(object);
        };
        /**
         * 显示模态对话框
         * - 只有`确定`一个按钮
         */
        UserAPI.prototype.showAlert = function (object) {
            if (!this.checkModuleAttr("widgets", "showAlert", "function")) {
                return this.createNonePromise("[widgets.showAlert]");
            }
            return this._m.widgets.showAlert(object);
        };
        /**
         * 隐藏启动画面
         */
        UserAPI.prototype.hideLaunchingView = function () {
            if (!this.checkModuleAttr("widgets", "hideLaunchingView", "function")) {
                return this.createNonePromise("[widgets.hideLaunchingView]");
            }
            return this._m.widgets.hideLaunchingView();
        };
        /**
         * 监听主域发送的消息
         */
        UserAPI.prototype.onMessage = function (callback) {
            if (!this.checkModuleAttr("subContext", "onMessage", "function")) {
                return undefined;
            }
            return this._m.subContext.onMessage(callback);
        };
        /**
         * 获取开放数据域
         */
        UserAPI.prototype.getOpenDataContext = function () {
            if (!this.checkModuleAttr("subContext", "getOpenDataContext", "function")) {
                return undefined;
            }
            return this._m.subContext.getOpenDataContext();
        };
        Object.defineProperty(UserAPI.prototype, "apiPlatform", {
            /**
             * api平台名称
             * * browser 浏览器
             * * native APP原生
             * * wechatgame 微信
             * * qqplay QQ玩一玩
             * * unknown 未知平台
             */
            get: function () {
                if (!this.checkModuleAttr("support", "apiPlatform")) {
                    return undefined;
                }
                return this._m.support.apiPlatform;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "pluginName", {
            /**
             * 插件名
             * * develop 网页开发测试
             * * wechat 微信
             * * qqplay 玩一玩
             * * app 原生APP
             **/
            get: function () {
                if (!this.checkModuleAttr("support", "pluginName")) {
                    return undefined;
                }
                return this._m.support.pluginName;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "supportShare", {
            /** 是否支持分享 */
            get: function () {
                if (!this.checkModuleAttr("support", "supportShare")) {
                    return undefined;
                }
                return this._m.support.supportShare;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "supportShareTickets", {
            /** 是否支持群分享 */
            get: function () {
                if (!this.checkModuleAttr("support", "supportShareTickets")) {
                    return undefined;
                }
                return this._m.support.supportShareTickets;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "requireSubDomainRank", {
            /** 是否需要支持子域 */
            get: function () {
                if (!this.checkModuleAttr("support", "requireSubDomainRank")) {
                    return undefined;
                }
                return this._m.support.requireSubDomainRank;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "requireAuthorize", {
            /** 是否需要鉴权认证 */
            get: function () {
                if (!this.checkModuleAttr("support", "requireAuthorize")) {
                    return undefined;
                }
                return this._m.support.requireAuthorize;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "apiNameLocale", {
            /** api本地化名字 */
            get: function () {
                if (!this.checkModuleAttr("support", "apiNameLocale")) {
                    return undefined;
                }
                return this._m.support.apiNameLocale;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 注册全局的错误回调函数
         */
        UserAPI.prototype.setErrorCallback = function (callback) {
            if (!this.checkModuleAttr("except", "setErrorCallback", "function")) {
                return undefined;
            }
            return this._m.except.setErrorCallback(callback);
        };
        /**
         * 创建用户信息授权按钮
         * * 当前仅微信有效
         */
        UserAPI.prototype.createUserInfoButton = function (obj) {
            if (!this.checkModuleAttr("auth", "createUserInfoButton", "function")) {
                return undefined;
            }
            return this._m.auth.createUserInfoButton(obj);
        };
        /**
         * 判断是否拥有获取用户信息的权限
         */
        UserAPI.prototype.isUserInfoAuthAlready = function () {
            if (!this.checkModuleAttr("auth", "isUserInfoAuthAlready", "function")) {
                return this.createNonePromise("[auth.isUserInfoAuthAlready]");
            }
            return this._m.auth.isUserInfoAuthAlready();
        };
        Object.defineProperty(UserAPI.prototype, "vibration", {
            /**
             * 振动器
             */
            get: function () {
                if (!this.checkModuleAttr("hardware", "vibration")) {
                    return undefined;
                }
                return this._m.hardware.vibration;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "performance", {
            /**
             * 性能
             */
            get: function () {
                if (!this.checkModuleAttr("hardware", "performance")) {
                    return undefined;
                }
                return this._m.hardware.performance;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "screen", {
            /**
             * 屏幕亮度
             */
            get: function () {
                if (!this.checkModuleAttr("hardware", "screen")) {
                    return undefined;
                }
                return this._m.hardware.screen;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "gyroscope", {
            /**
             * 陀螺仪
             */
            get: function () {
                if (!this.checkModuleAttr("hardware", "gyroscope")) {
                    return undefined;
                }
                return this._m.hardware.gyroscope;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "compass", {
            /**
             * 罗盘
             */
            get: function () {
                if (!this.checkModuleAttr("hardware", "compass")) {
                    return undefined;
                }
                return this._m.hardware.compass;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "battery", {
            /**
             * 电池
             */
            get: function () {
                if (!this.checkModuleAttr("hardware", "battery")) {
                    return undefined;
                }
                return this._m.hardware.battery;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "accelerometer", {
            /**
             * 加速计
             */
            get: function () {
                if (!this.checkModuleAttr("hardware", "accelerometer")) {
                    return undefined;
                }
                return this._m.hardware.accelerometer;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "gravity", {
            /**
             * - 设备方向
             * - 转屏相关
             * - 重力感应
             */
            get: function () {
                if (!this.checkModuleAttr("hardware", "gravity")) {
                    return undefined;
                }
                return this._m.hardware.gravity;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserAPI.prototype, "screenTouch", {
            /**
             * 触屏
             */
            get: function () {
                if (!this.checkModuleAttr("hardware", "screenTouch")) {
                    return undefined;
                }
                return this._m.hardware.screenTouch;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 提交日志
         */
        UserAPI.prototype.commitLog = function (key, params) {
            if (!this.checkModuleAttr("log", "commitLog", "function")) {
                return this.createNonePromise("[log.commitLog]");
            }
            return this._m.log.commitLog(key, params);
        };
        UserAPI.prototype.commitChannelsLog = function (logType, params) {
            if (!this.checkModuleAttr("log", "commitChannelsLog", "function")) {
                return this.createNonePromise("[log.commitChannelsLog]");
            }
            return this._m.log.commitChannelsLog(logType, params);
        };
        /**
         * 付费打点
         * @param index 1-6  代表6种不同金额
         */
        UserAPI.prototype.commitPayLog = function (index) {
            if (!this.checkModuleAttr("log", "commitPayLog", "function")) {
                return undefined;
            }
            return this._m.log.commitPayLog(index);
        };
        /**
         * 添加本地推送
         */
        UserAPI.prototype.addLocalNotices = function (notices) {
            if (!this.checkModuleAttr("localPush", "addLocalNotices", "function")) {
                return this.createNonePromise("[localPush.addLocalNotices]");
            }
            return this._m.localPush.addLocalNotices(notices);
        };
        /**
         * 移除对应的推送
         */
        UserAPI.prototype.removeLocalNoticeWithID = function (params) {
            if (!this.checkModuleAttr("localPush", "removeLocalNoticeWithID", "function")) {
                return this.createNonePromise("[localPush.removeLocalNoticeWithID]");
            }
            return this._m.localPush.removeLocalNoticeWithID(params);
        };
        /**
         * 移除所有推送
         */
        UserAPI.prototype.removeAllLocalNotices = function () {
            if (!this.checkModuleAttr("localPush", "removeAllLocalNotices", "function")) {
                return this.createNonePromise("[localPush.removeAllLocalNotices]");
            }
            return this._m.localPush.removeAllLocalNotices();
        };
        /**
         * 检查推送设置，如果没有权限则提示用户跳转开启
         */
        UserAPI.prototype.requireLocalNoticePermission = function () {
            if (!this.checkModuleAttr("localPush", "requireLocalNoticePermission", "function")) {
                return this.createNonePromise("[localPush.requireLocalNoticePermission]");
            }
            return this._m.localPush.requireLocalNoticePermission();
        };
        /**
         * 用户是否开启通知权限
         */
        UserAPI.prototype.isLocalNoticeEnabled = function () {
            if (!this.checkModuleAttr("localPush", "isLocalNoticeEnabled", "function")) {
                return this.createNonePromise("[localPush.isLocalNoticeEnabled]");
            }
            return this._m.localPush.isLocalNoticeEnabled();
        };
        return UserAPI;
    }());
    GDK.UserAPI = UserAPI;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    var APIServer = /** @class */ (function () {
        function APIServer() {
        }
        return APIServer;
    }());
    GDK.APIServer = APIServer;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    // 统一形式：promise、callback、同步、异步等不同形式，统一为同一形式
    // /** 基本请求错误码 */
    // export const ReqErrorCode = {
    // 	/** 请求成功 */
    // 	SUCCESS: 0,
    // 	/** 未知错误 */
    // 	UNKNOWN: 100,
    // 	/** 请求超时 */
    // 	TIMEOUT: 101,
    // }
    // /** 请求错误扩展参数 */
    // export class ExtraReqError {
    // 	errCode?: number
    // 	msg?: string
    // 	reason?: string
    // 	data?: any
    // }
    // /** 请求错误结果 */
    // export class ReqError extends Error {
    // 	errCode: number
    // 	msg: string
    // 	reason: string
    // 	data?: any
    // 	constructor(errCode: number, msg: string, reason: string, data?: any) {
    // 		super(msg)
    // 		this.errCode = errCode
    // 		this.reason = reason;
    // 		this.data = data;
    // 	}
    // }
    // /** 请求结果 */
    // export class ReqResult extends ReqError { }
    // /** 请求结果模板生成器 */
    // export class ResultTemplatesExtractor<T extends ReqError> {
    // 	protected _temps: T[] = []
    // 	get temps() { return this._temps }
    // 	constructor(temps: T[]) {
    // 		this._temps = temps
    // 	}
    // 	/**
    // 	 * 根据错误码和扩展参数构造请求结果
    // 	 */
    // 	make<F extends ExtraReqError>(errCode: number, extra?: F): T {
    // 		return null
    // 	}
    // }
    /**
     * 请求结果模板，用于生成请求结果
     * 用法示例：
     * - ```typescript
    export const LoginResultTemplates = new ResultTemplatesExtractor<ReqError>([
        ...ReqResultTemplates.temps,
        { errCode: LoginErrorCode.INVALID_OPENID, msg: '登录失败', reason: 'openId验证失败' },
    ])
    ```
     **/
    // export const ReqResultTemplates = new ResultTemplatesExtractor<ReqError>([
    // 	{ errCode: ReqErrorCode.SUCCESS, msg: '请求成功', reason: '请求成功', data: null },
    // 	{ errCode: ReqErrorCode.UNKNOWN, msg: '请求失败', reason: '未知错误' },
    // 	{ errCode: ReqErrorCode.TIMEOUT, msg: '请求超时', reason: '请求超时' },
    // ])
    // export class ReqCallbacks {
    // 	success?: (params: ReqResult) => void
    // 	fail?: (params: ReqError) => void
    // }
    /**
     * 增强类型限定的Promise
     * @param T - resolve 参数类型
     * @param F - reject 参数类型
     */
    // export class MyPromise<T, F> extends Promise<T>{
    // 	constructor(executor: (resolve: (value?: T | PromiseLike<T>) => void, reject: (reason?: F) => void) => void) {
    // 		super(executor)
    // 	}
    // }
    /**
     * 反转 MyPromise
     * - 外部调用 success时相当于调用了 resolve
     * - 外部调用 fail 时，相当于调用了 reject
     * @param T - resolve 参数类型
     * @param F - reject 参数类型
     */
    var YmPromise = /** @class */ (function () {
        function YmPromise(params) {
            this.init(params);
        }
        YmPromise.prototype.init = function (params) {
            var _this = this;
            this.promise = new Promise(function (resolve, reject) {
                _this.success = resolve;
                _this.fail = reject;
            });
        };
        return YmPromise;
    }());
    GDK.YmPromise = YmPromise;
    var RPromise = /** @class */ (function (_super) {
        __extends(RPromise, _super);
        function RPromise() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return RPromise;
    }(YmPromise));
    GDK.RPromise = RPromise;
    /** 请求参数 */
    var ReqParams = /** @class */ (function () {
        function ReqParams() {
        }
        return ReqParams;
    }());
    GDK.ReqParams = ReqParams;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    var GDKConfigBase = /** @class */ (function () {
        function GDKConfigBase() {
            /**
             * 游戏的启动模式。
             * 可以是 开发、测试、发布
             */
            this.mode = "develop";
            /**
             * APPID
             */
            this.appId = "";
            /**
             * 优先只启用客服跳转支付
             * - 支持ios和安卓
             */
            this.requireCustomServicePay = false;
            /**
             * 优先只启用小程序跳转支付
             * 只支持安卓
             */
            this.requireMiniAppPay = false;
            this.requireIndiaSPSPay = false;
        }
        return GDKConfigBase;
    }());
    GDK.GDKConfigBase = GDKConfigBase;
    var GDKDevelopConfig = /** @class */ (function (_super) {
        __extends(GDKDevelopConfig, _super);
        function GDKDevelopConfig() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return GDKDevelopConfig;
    }(GDKConfigBase));
    GDK.GDKDevelopConfig = GDKDevelopConfig;
    var GDKWechatConfig = /** @class */ (function (_super) {
        __extends(GDKWechatConfig, _super);
        function GDKWechatConfig() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            /**
             * 支付id
             */
            _this.offerId = "";
            /**
             * 支付时，是否使用安全沙箱
             */
            _this.isPayInSandbox = true;
            /**
             * 安卓分享时，所使用的代理网址
             */
            _this.shareProxyUrl = "";
            _this.userId = 0;
            /**
             * 跳转支付appid
             */
            _this.miniAppOfferId = "";
            return _this;
        }
        return GDKWechatConfig;
    }(GDKConfigBase));
    GDK.GDKWechatConfig = GDKWechatConfig;
    var GDKBytedanceConfig = /** @class */ (function (_super) {
        __extends(GDKBytedanceConfig, _super);
        function GDKBytedanceConfig() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return GDKBytedanceConfig;
    }(GDKWechatConfig));
    GDK.GDKBytedanceConfig = GDKBytedanceConfig;
    var GDKQQMINIAPPConfig = /** @class */ (function (_super) {
        __extends(GDKQQMINIAPPConfig, _super);
        function GDKQQMINIAPPConfig() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            /**
             * 支付id
             */
            _this.offerId = "";
            /**
             * 支付时，是否使用安全沙箱
             */
            _this.isPayInSandbox = true;
            /**
             * 安卓分享时，所使用的代理网址
             */
            _this.shareProxyUrl = "";
            _this.userId = 0;
            /**
             * 跳转支付appid
             */
            _this.miniAppOfferId = "";
            return _this;
        }
        return GDKQQMINIAPPConfig;
    }(GDKConfigBase));
    GDK.GDKQQMINIAPPConfig = GDKQQMINIAPPConfig;
    var GDKQQPlayConfig = /** @class */ (function (_super) {
        __extends(GDKQQPlayConfig, _super);
        function GDKQQPlayConfig() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return GDKQQPlayConfig;
    }(GDKConfigBase));
    GDK.GDKQQPlayConfig = GDKQQPlayConfig;
    var GDKOPPOConfig = /** @class */ (function (_super) {
        __extends(GDKOPPOConfig, _super);
        function GDKOPPOConfig() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return GDKOPPOConfig;
    }(GDKConfigBase));
    GDK.GDKOPPOConfig = GDKOPPOConfig;
    var GDKVIVOConfig = /** @class */ (function (_super) {
        __extends(GDKVIVOConfig, _super);
        function GDKVIVOConfig() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return GDKVIVOConfig;
    }(GDKConfigBase));
    GDK.GDKVIVOConfig = GDKVIVOConfig;
    var GDKAPPConfig = /** @class */ (function (_super) {
        __extends(GDKAPPConfig, _super);
        function GDKAPPConfig() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            /**
             * 广告平台
             * - ironsource
             * - adtiming
             * - gdtadvert 腾讯广点通
             */
            _this.advertPlatform = "ironsource";
            _this.advertPlatforms = [];
            return _this;
        }
        return GDKAPPConfig;
    }(GDKConfigBase));
    GDK.GDKAPPConfig = GDKAPPConfig;
    var GDKGamepindConfig = /** @class */ (function (_super) {
        __extends(GDKGamepindConfig, _super);
        function GDKGamepindConfig() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return GDKGamepindConfig;
    }(GDKConfigBase));
    GDK.GDKGamepindConfig = GDKGamepindConfig;
    var GDKWebConfig = /** @class */ (function (_super) {
        __extends(GDKWebConfig, _super);
        function GDKWebConfig() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return GDKWebConfig;
    }(GDKConfigBase));
    GDK.GDKWebConfig = GDKWebConfig;
    var GDKWEBVIEWConfig = /** @class */ (function (_super) {
        __extends(GDKWEBVIEWConfig, _super);
        function GDKWEBVIEWConfig() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            /**
             * 广告平台
             * - ironsource
             * - adtiming
             * - gdtadvert 腾讯广点通
             */
            _this.advertPlatform = "ironsource";
            _this.advertPlatforms = [];
            return _this;
        }
        return GDKWEBVIEWConfig;
    }(GDKConfigBase));
    GDK.GDKWEBVIEWConfig = GDKWEBVIEWConfig;
    var GDKConfig = /** @class */ (function () {
        function GDKConfig() {
        }
        return GDKConfig;
    }());
    GDK.GDKConfig = GDKConfig;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    var BannerStyle = /** @class */ (function () {
        function BannerStyle() {
        }
        return BannerStyle;
    }());
    GDK.BannerStyle = BannerStyle;
    var BannerStyleAccessor = /** @class */ (function () {
        function BannerStyleAccessor() {
        }
        return BannerStyleAccessor;
    }());
    GDK.BannerStyleAccessor = BannerStyleAccessor;
    var RewardedVideoAdOnErrorParam = /** @class */ (function () {
        function RewardedVideoAdOnErrorParam() {
        }
        return RewardedVideoAdOnErrorParam;
    }());
    GDK.RewardedVideoAdOnErrorParam = RewardedVideoAdOnErrorParam;
    var InterstitialAdOnErrorParam = /** @class */ (function (_super) {
        __extends(InterstitialAdOnErrorParam, _super);
        function InterstitialAdOnErrorParam() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return InterstitialAdOnErrorParam;
    }(RewardedVideoAdOnErrorParam));
    GDK.InterstitialAdOnErrorParam = InterstitialAdOnErrorParam;
    var FullscreenAdOnErrorParam = /** @class */ (function (_super) {
        __extends(FullscreenAdOnErrorParam, _super);
        function FullscreenAdOnErrorParam() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return FullscreenAdOnErrorParam;
    }(RewardedVideoAdOnErrorParam));
    GDK.FullscreenAdOnErrorParam = FullscreenAdOnErrorParam;
    var RewardVideoAdLoadParams = /** @class */ (function () {
        function RewardVideoAdLoadParams() {
        }
        return RewardVideoAdLoadParams;
    }());
    GDK.RewardVideoAdLoadParams = RewardVideoAdLoadParams;
    var VideoAdSlot = /** @class */ (function () {
        function VideoAdSlot() {
        }
        return VideoAdSlot;
    }());
    GDK.VideoAdSlot = VideoAdSlot;
    var FeedAdStyle = /** @class */ (function () {
        function FeedAdStyle() {
        }
        return FeedAdStyle;
    }());
    GDK.FeedAdStyle = FeedAdStyle;
    var FeedAdStyleAccessor = /** @class */ (function () {
        function FeedAdStyleAccessor() {
        }
        return FeedAdStyleAccessor;
    }());
    GDK.FeedAdStyleAccessor = FeedAdStyleAccessor;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    /** 按钮的样式 */
    var UserInfoButtonStyle = /** @class */ (function () {
        function UserInfoButtonStyle() {
        }
        return UserInfoButtonStyle;
    }());
    GDK.UserInfoButtonStyle = UserInfoButtonStyle;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    var OpenParam = /** @class */ (function () {
        function OpenParam() {
            /** 会话来源 */
            this.sessionFrom = '';
            /** 是否显示会话内消息卡片，设置此参数为 true，用户进入客服会话之后会收到一个消息卡片，通过以下三个参数设置卡片的内容 */
            this.showMessageCard = false;
            /** 会话内消息卡片标题 */
            this.sendMessageTitle = '';
            /** 会话内消息卡片路径 */
            this.sendMessagePath = '';
            /** 会话内消息卡片图片路径 */
            this.sendMessageImg = '';
        }
        return OpenParam;
    }());
    GDK.OpenParam = OpenParam;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    var LocalPushAvailableStage;
    (function (LocalPushAvailableStage) {
        /**
         * 允许后台通知
         */
        LocalPushAvailableStage[LocalPushAvailableStage["BACKGROUND"] = 1] = "BACKGROUND";
        /**
         * 允许前台通知
         */
        LocalPushAvailableStage[LocalPushAvailableStage["FOREGROUND"] = 2] = "FOREGROUND";
    })(LocalPushAvailableStage = GDK.LocalPushAvailableStage || (GDK.LocalPushAvailableStage = {}));
    var LocalPushBundle = /** @class */ (function () {
        function LocalPushBundle() {
            /**
             * 推送ID，最好填纯数字
             * - 相同id的通知会被覆盖更新
             */
            this.identifier = null;
            /**
             * 推送标题
             */
            this.title = '标题';
            /**
             * 推送副标题
             * - 某些手机不显示副标题
             */
            this.subtitle = '';
            /**
             * 推送文本内容
             */
            this.content = '内容';
            /**
             * 顶栏标题
             */
            this.ticker = "";
            /**
             * 推送间隔
             */
            this.interval = null;
            /**
             * 重复推送方式（仅ios支持）
             * - 0 不重复
             * - 1 重复推送
             * - 大于1 其他重复方式
             */
            this.repeat = 0;
            /**
             * 图标样式
             */
            this.badge = 1;
            /**
             * 附加信息
             */
            this.userInfo = '{}';
            /**
             * 声音文件名
             */
            this.soundName = null;
            /**
             * 开启声音提示
             */
            this.enableSoundTip = true;
            /**
             * 振动提示
             */
            this.enableVibrateTip = false;
            /**
             * 呼吸灯提示（仅安卓）
             */
            this.enableLightTip = false;
            /**
             * 设置某些情景推送权限
             * - 只支持安卓
             * - 可以叠加，比如：info.availableStage=LocalPushAvailableStage.BACKGROUND | LocalPushAvailableStage.FOREGROUND
             */
            this.availableStage = LocalPushAvailableStage.BACKGROUND;
            /**
             * 支持长文本完整显示
             * - 目前仅安卓生效
             */
            this.isBigText = false;
        }
        return LocalPushBundle;
    }());
    GDK.LocalPushBundle = LocalPushBundle;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    /** 订单状态 */
    var OrderState;
    (function (OrderState) {
        OrderState[OrderState["fail"] = 2] = "fail";
        OrderState[OrderState["ok"] = 1] = "ok";
        OrderState[OrderState["unknown"] = 0] = "unknown";
    })(OrderState = GDK.OrderState || (GDK.OrderState = {}));
    var PayItemInfo = /** @class */ (function () {
        function PayItemInfo() {
            /** 我们的商品ID */
            this.goodsId = 0;
            /** 后台二级货币ID */
            this.coinId = 0;
            /** 支付金额 */
            this.money = 0;
            /** 支付金额 */
            this.price = 0;
            /** 购买商品数量 */
            this.amount = 0;
            /** 商品名称/标题 */
            this.title = '';
            /** 支付货币单位 */
            this.currencyUnit = "CNY";
        }
        return PayItemInfo;
    }());
    GDK.PayItemInfo = PayItemInfo;
    var PayError = /** @class */ (function (_super) {
        __extends(PayError, _super);
        function PayError() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PayError;
    }(GDK.GDKError));
    GDK.PayError = PayError;
    var PayResult = /** @class */ (function () {
        function PayResult() {
        }
        return PayResult;
    }());
    GDK.PayResult = PayResult;
    var ConsumePurchaseResult = /** @class */ (function () {
        function ConsumePurchaseResult() {
        }
        return ConsumePurchaseResult;
    }());
    GDK.ConsumePurchaseResult = ConsumePurchaseResult;
    var PayQueryItemInfoResultData = /** @class */ (function () {
        function PayQueryItemInfoResultData() {
        }
        return PayQueryItemInfoResultData;
    }());
    GDK.PayQueryItemInfoResultData = PayQueryItemInfoResultData;
    var PayQueryItemInfoResult = /** @class */ (function () {
        function PayQueryItemInfoResult() {
        }
        return PayQueryItemInfoResult;
    }());
    GDK.PayQueryItemInfoResult = PayQueryItemInfoResult;
    var WebViewOrientation;
    (function (WebViewOrientation) {
        WebViewOrientation[WebViewOrientation["portrait"] = 1] = "portrait";
        WebViewOrientation[WebViewOrientation["landscapeLeft"] = 2] = "landscapeLeft";
        WebViewOrientation[WebViewOrientation["landscapeRight"] = 3] = "landscapeRight";
    })(WebViewOrientation = GDK.WebViewOrientation || (GDK.WebViewOrientation = {}));
    var PayOptions = /** @class */ (function () {
        function PayOptions() {
        }
        return PayOptions;
    }());
    GDK.PayOptions = PayOptions;
    var ConsumePurchaseParams = /** @class */ (function () {
        function ConsumePurchaseParams() {
        }
        return ConsumePurchaseParams;
    }());
    GDK.ConsumePurchaseParams = ConsumePurchaseParams;
    var PayQueryItemInfoParams = /** @class */ (function () {
        function PayQueryItemInfoParams() {
        }
        return PayQueryItemInfoParams;
    }());
    GDK.PayQueryItemInfoParams = PayQueryItemInfoParams;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    /**
     * 分享时所使用的数据
     */
    var ShareData = /** @class */ (function () {
        function ShareData() {
        }
        return ShareData;
    }());
    GDK.ShareData = ShareData;
    var ShareUrlData = /** @class */ (function () {
        function ShareUrlData() {
        }
        return ShareUrlData;
    }());
    GDK.ShareUrlData = ShareUrlData;
    var ShareResult = /** @class */ (function () {
        function ShareResult() {
            /**
             * 是否是群或讨论组
             */
            this.isGroup = false;
        }
        return ShareResult;
    }());
    GDK.ShareResult = ShareResult;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    // export class LoginError extends ReqError { }
    /** 登录请求结果 */
    var LoginResult = /** @class */ (function () {
        function LoginResult() {
        }
        return LoginResult;
    }());
    GDK.LoginResult = LoginResult;
    /** 登录错误码 */
    // export const LoginErrorCode = {
    // 	...ReqErrorCode,
    // 	INVALID_OPENID: 10001,
    // }
    /** 登录结果模板 */
    // export const LoginResultTemplates = new ResultTemplatesExtractor<ReqError>([
    // 	...ReqResultTemplates.temps,
    // 	{ errCode: LoginErrorCode.INVALID_OPENID, msg: '登录失败', reason: 'openId验证失败' },
    // ])
    /** 登录请求参数 */
    var LoginParams = /** @class */ (function (_super) {
        __extends(LoginParams, _super);
        function LoginParams() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            /**
             * 是否禁止游客登陆
             */
            _this.disableVisitor = false;
            /**
             * 是否允许Google登陆
             */
            _this.google = false;
            /**
             * 是否允许facebook登陆
             */
            _this.facebook = false;
            /**
             * 是否静默登陆
             */
            _this.silent = false;
            /**
             * 是否允许自动登陆
             * * 如果当前未绑定任何第三方账号，则执行游客登陆
             * * 否则，执行第三方账号的自动登陆
             */
            _this.autoLogin = true;
            return _this;
        }
        return LoginParams;
    }(GDK.ReqParams));
    GDK.LoginParams = LoginParams;
    var LoginPromise = /** @class */ (function (_super) {
        __extends(LoginPromise, _super);
        function LoginPromise() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return LoginPromise;
    }(Promise));
    GDK.LoginPromise = LoginPromise;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    /** 登录请求结果 */
    var UserDataUpdateResult = /** @class */ (function () {
        function UserDataUpdateResult() {
        }
        return UserDataUpdateResult;
    }());
    GDK.UserDataUpdateResult = UserDataUpdateResult;
    //https://developers.weixin.qq.com/minigame/dev/document/open-api/data/KVData.html
    var KVData = /** @class */ (function () {
        function KVData() {
        }
        return KVData;
    }());
    GDK.KVData = KVData;
    //https://developers.weixin.qq.com/minigame/dev/document/open-api/data/UserGameData.html
    var UserGameData = /** @class */ (function () {
        function UserGameData() {
        }
        return UserGameData;
    }());
    GDK.UserGameData = UserGameData;
})(GDK || (GDK = {}));
var GDK;
(function (GDK) {
    var ShowConfirmResult = /** @class */ (function () {
        function ShowConfirmResult() {
        }
        return ShowConfirmResult;
    }());
    GDK.ShowConfirmResult = ShowConfirmResult;
    var ShowPromptResult = /** @class */ (function () {
        function ShowPromptResult() {
        }
        return ShowPromptResult;
    }());
    GDK.ShowPromptResult = ShowPromptResult;
    var ShowAlertResult = /** @class */ (function () {
        function ShowAlertResult() {
        }
        return ShowAlertResult;
    }());
    GDK.ShowAlertResult = ShowAlertResult;
    var ShowLoadingParams = /** @class */ (function () {
        function ShowLoadingParams() {
        }
        return ShowLoadingParams;
    }());
    GDK.ShowLoadingParams = ShowLoadingParams;
})(GDK || (GDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var NativeHelper = /** @class */ (function () {
        function NativeHelper() {
        }
        NativeHelper.prototype.checkActionExist = function (key) {
            if (gdkjsb.nativeVersion && gdkjsb.nativeVersion >= 1) {
                return gdkjsb.bridge.checkActionExist(key);
            }
            return false;
        };
        NativeHelper.prototype.safeCallAction = function (key, params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    if (UnityAppGDK.nativeHelper.checkActionExist(key)) {
                        return [2 /*return*/, this.callAction(key, params)];
                    }
                    else {
                        console.log("skip call <" + key + "> function, which not implement for current sdk version " + gdkjsb.nativeVersion);
                    }
                    return [2 /*return*/, undefined];
                });
            });
        };
        NativeHelper.prototype.callAction = function (key, params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, new Promise(function (resolve, reject) {
                            gdkjsb.bridge.callAction(key, JSON.stringify(params), function (data) {
                                resolve(JSON.parse(data || null));
                            });
                        })];
                });
            });
        };
        NativeHelper.prototype.onEvent = function (key, callback) {
            return __awaiter(this, void 0, void 0, function () {
                var id;
                return __generator(this, function (_a) {
                    id = gdkjsb.bridge.on(key, function (data) {
                        console.log('ironsrc:onEvent:', key, data);
                        callback(JSON.parse(data)["params"]);
                    });
                    return [2 /*return*/];
                });
            });
        };
        NativeHelper.prototype.onDoneEvent = function (key, callback) {
            return __awaiter(this, void 0, void 0, function () {
                var id;
                return __generator(this, function (_a) {
                    id = gdkjsb.bridge.on(key, function (data) {
                        console.log('ironsrc:onEvent:', key, data);
                        callback();
                    });
                    return [2 /*return*/];
                });
            });
        };
        return NativeHelper;
    }());
    UnityAppGDK.NativeHelper = NativeHelper;
    UnityAppGDK.nativeHelper = new NativeHelper();
})(UnityAppGDK || (UnityAppGDK = {}));
/// <reference path="./NativeHelper.ts" />
var UnityAppGDK;
(function (UnityAppGDK) {
    var IronSrc;
    (function (IronSrc) {
        var Placement = /** @class */ (function () {
            function Placement() {
            }
            return Placement;
        }());
        IronSrc.Placement = Placement;
        var IronSourceError = /** @class */ (function () {
            function IronSourceError() {
            }
            return IronSourceError;
        }());
        IronSrc.IronSourceError = IronSourceError;
    })(IronSrc = UnityAppGDK.IronSrc || (UnityAppGDK.IronSrc = {}));
    var NativeAdvert = /** @class */ (function () {
        function NativeAdvert() {
        }
        /**
         * @param params.appKey 可选参数，如果安卓项目中已经填写 ironsource_advert_appkey ，那么此处可不传入
         * @param params.modules 指定支持的广告模块，可选 key 为：`REWARDED_VIDEO`,`BANNER`,`INTERSTITIAL`,`OFFERWALL`
         */
        NativeAdvert.prototype.init = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.init", params)];
                });
            });
        };
        /**
         * 验证广告集成
         */
        NativeAdvert.prototype.validateIntegration = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IntegrationHelper.validateIntegration", {})];
                });
            });
        };
        NativeAdvert.prototype.shouldTrackNetworkState = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.shouldTrackNetworkState", params)];
                });
            });
        };
        NativeAdvert.prototype.setAdaptersDebug = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:banner.setAdaptersDebug", params)];
                });
            });
        };
        /**
         * 事件通知流程
         * # 从播放视频到重新加载
         * - onRewardedVideoAvailabilityChanged -> true
         * - onRewardedVideoAdOpened
         * - onRewardedVideoAdRewarded
         * - onRewardedVideoAvailabilityChanged -> false
         * - onRewardedVideoAdClosed
         * - onRewardedVideoAvailabilityChanged -> true
         */
        NativeAdvert.prototype.setRewardedVideoListener = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.setRewardedVideoListener", {})];
                });
            });
        };
        /**
         * 监听广告打开播放
         */
        NativeAdvert.prototype.onRewardedVideoAdOpened = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onRewardedVideoAdOpened", callback)];
                });
            });
        };
        /**
         * 监听广告关闭
         */
        NativeAdvert.prototype.onRewardedVideoAdClosed = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onRewardedVideoAdClosed", callback)];
                });
            });
        };
        /**
         * 通知当前视频是否已加载
         */
        NativeAdvert.prototype.onRewardedVideoAvailabilityChanged = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onEvent("ironsrc:onRewardedVideoAvailabilityChanged", callback)];
                });
            });
        };
        /**
         * 监听广告开始播放
         */
        NativeAdvert.prototype.onRewardedVideoAdStarted = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onRewardedVideoAdStarted", callback)];
                });
            });
        };
        /**
         * 监听广告播放结束
         */
        NativeAdvert.prototype.onRewardedVideoAdEnded = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onRewardedVideoAdEnded", callback)];
                });
            });
        };
        /**
         * 监听广告可发放奖励
         */
        NativeAdvert.prototype.onRewardedVideoAdRewarded = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onEvent("ironsrc:onRewardedVideoAdRewarded", callback)];
                });
            });
        };
        NativeAdvert.prototype.onRewardedVideoAdShowFailed = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onEvent("ironsrc:onRewardedVideoAdShowFailed", callback)];
                });
            });
        };
        NativeAdvert.prototype.onRewardedVideoAdClicked = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onEvent("ironsrc:onRewardedVideoAdClicked", callback)];
                });
            });
        };
        NativeAdvert.prototype.loadRewardVideoAd = function (loadParams) {
            return __awaiter(this, void 0, void 0, function () {
                var key;
                return __generator(this, function (_a) {
                    if (typeof loadParams != "object") {
                        loadParams = {};
                    }
                    key = "ironsrc:IronSource.loadRewardVideoAd";
                    // if (nativeHelper.checkActionExist(key)) {
                    // 	return nativeHelper.callAction<{}>(key, {})
                    // } else {
                    // 	console.log(`skip call <${key}> function, which not implement for current sdk version`)
                    // }
                    return [2 /*return*/, UnityAppGDK.nativeHelper.safeCallAction(key, loadParams) || {}];
                });
            });
        };
        NativeAdvert.prototype.isRewardedVideoAvailable = function (loadParams) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.isRewardedVideoAvailable", loadParams || {})];
                });
            });
        };
        NativeAdvert.prototype.showRewardedVideo = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.showRewardedVideo", params)];
                });
            });
        };
        /**
         * 事件通知流程
         * # 从播放视频到重新加载
         * - onFullScreenVideoAvailabilityChanged -> true
         * - onFullScreenVideoAdStarted
         * - onFullScreenVideoAdSkipped
         * - onFullScreenVideoAdComplete
         * - onFullScreenVideoAdClosed
         * - onFullScreenVideoAvailabilityChanged -> false
         * - load
         * - onFullScreenVideoAvailabilityChanged -> true
         * - onFullScreenVideoAdCached
         */
        NativeAdvert.prototype.setFullScreenVideoListener = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.setFullScreenVideoListener", {})];
                });
            });
        };
        NativeAdvert.prototype.loadFullScreenVideoAd = function () {
            return __awaiter(this, void 0, void 0, function () {
                var key;
                return __generator(this, function (_a) {
                    key = "ironsrc:IronSource.loadFullScreenVideoAd";
                    // if (nativeHelper.checkActionExist(key)) {
                    // 	return nativeHelper.callAction<{}>(key, {})
                    // } else {
                    // 	console.log(`skip call <${key}> function, which not implement for current sdk version`)
                    // }
                    return [2 /*return*/, UnityAppGDK.nativeHelper.safeCallAction(key, {}) || {}];
                });
            });
        };
        NativeAdvert.prototype.isFullScreenVideoAvailable = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.isFullScreenVideoAvailable", {})];
                });
            });
        };
        NativeAdvert.prototype.showFullScreenVideo = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.showFullScreenVideo", params)];
                });
            });
        };
        // /**
        //  * 监听广告打开播放
        //  */
        // async onFullScreenVideoAdOpened(callback: Function) {
        // 	return nativeHelper.onDoneEvent("ironsrc:onFullScreenVideoAdOpened", callback)
        // }
        /**
         * 监听广告关闭
         */
        NativeAdvert.prototype.onFullScreenVideoAdClosed = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onFullScreenVideoAdClosed", callback)];
                });
            });
        };
        /**
         * 通知当前视频是否已加载
         */
        NativeAdvert.prototype.onFullScreenVideoAvailabilityChanged = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onEvent("ironsrc:onFullScreenVideoAvailabilityChanged", callback)];
                });
            });
        };
        /**
         * 监听广告开始播放
         */
        NativeAdvert.prototype.onFullScreenVideoAdStarted = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onFullScreenVideoAdStarted", callback)];
                });
            });
        };
        // /**
        //  * 监听广告播放结束
        //  */
        // async onFullScreenVideoAdEnded(callback: Function) {
        // 	return nativeHelper.onDoneEvent("ironsrc:onFullScreenVideoAdEnded", callback)
        // }
        /**
         * 全屏广告完全播完会回调
         */
        NativeAdvert.prototype.onFullScreenVideoAdComplete = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onEvent("ironsrc:onFullScreenVideoAdComplete", callback)];
                });
            });
        };
        NativeAdvert.prototype.onFullScreenVideoAdShowFailed = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onEvent("ironsrc:onFullScreenVideoAdShowFailed", callback)];
                });
            });
        };
        // async onFullScreenVideoAdClicked(callback: (data: IronSrc.Placement) => void) {
        // 	return nativeHelper.onEvent("ironsrc:onFullScreenVideoAdClicked", callback)
        // }
        // banner advert
        NativeAdvert.prototype.createBanner = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.createBanner", params)];
                });
            });
        };
        NativeAdvert.prototype.setBannerListener = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:banner.setBannerListener", {})];
                });
            });
        };
        NativeAdvert.prototype.setBannerAdvertVisibility = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:banner.setVisibility", params)];
                });
            });
        };
        NativeAdvert.prototype.loadBanner = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.loadBanner", params)];
                });
            });
        };
        NativeAdvert.prototype.setBannerStyle = function (style) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.setBannerStyle", style)];
                });
            });
        };
        NativeAdvert.prototype.destroyBanner = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.destroyBanner", {})];
                });
            });
        };
        // banner advert 事件
        NativeAdvert.prototype.onBannerAdLoaded = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onBannerAdLoaded", callback)];
                });
            });
        };
        NativeAdvert.prototype.onBannerAdLoadFailed = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onEvent("ironsrc:onBannerAdLoadFailed", callback)];
                });
            });
        };
        NativeAdvert.prototype.onBannerAdClicked = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onBannerAdClicked", callback)];
                });
            });
        };
        NativeAdvert.prototype.onBannerAdScreenPresented = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onBannerAdScreenPresented", callback)];
                });
            });
        };
        NativeAdvert.prototype.onBannerAdScreenDismissed = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onBannerAdScreenDismissed", callback)];
                });
            });
        };
        NativeAdvert.prototype.onBannerAdLeftApplication = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onBannerAdLeftApplication", callback)];
                });
            });
        };
        // Interstitial
        /**
         * 验证广告集成
         */
        NativeAdvert.prototype.setInterstitialListener = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.setInterstitialListener", {})];
                });
            });
        };
        NativeAdvert.prototype.loadInterstitial = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.loadInterstitial", {})];
                });
            });
        };
        NativeAdvert.prototype.isInterstitialReady = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.isInterstitialReady", {})];
                });
            });
        };
        NativeAdvert.prototype.showInterstitial = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.showInterstitial", params)];
                });
            });
        };
        // Interstitial advert 事件
        NativeAdvert.prototype.onInterstitialAdRewarded = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onInterstitialAdRewarded", callback)];
                });
            });
        };
        NativeAdvert.prototype.onInterstitialAdClosed = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onInterstitialAdClosed", callback)];
                });
            });
        };
        /**
         * Invoked when there is no Interstitial Ad available after calling load function.
         */
        NativeAdvert.prototype.onInterstitialAdReady = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onInterstitialAdReady", callback)];
                });
            });
        };
        NativeAdvert.prototype.onInterstitialAdLoadFailed = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onEvent("ironsrc:onInterstitialAdLoadFailed", callback)];
                });
            });
        };
        NativeAdvert.prototype.onInterstitialAdClicked = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onInterstitialAdClicked", callback)];
                });
            });
        };
        NativeAdvert.prototype.onInterstitialAdOpened = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onInterstitialAdOpened", callback)];
                });
            });
        };
        NativeAdvert.prototype.onInterstitialAdShowSucceeded = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onInterstitialAdShowSucceeded", callback)];
                });
            });
        };
        NativeAdvert.prototype.onInterstitialAdShowFailed = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onEvent("ironsrc:onInterstitialAdShowFailed", callback)];
                });
            });
        };
        // feed advert
        NativeAdvert.prototype.createFeedAd = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.createFeedAd", params)];
                });
            });
        };
        NativeAdvert.prototype.setFeedAdVisibility = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.setFeedAdVisibility", params)];
                });
            });
        };
        NativeAdvert.prototype.loadFeedAd = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.loadFeedAd", params)];
                });
            });
        };
        NativeAdvert.prototype.setFeedAdStyle = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.setFeedAdStyle", params)];
                });
            });
        };
        NativeAdvert.prototype.setFeedAdClickZoneStyle = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.setFeedAdDefaultClickZoneStyle", params)];
                });
            });
        };
        NativeAdvert.prototype.destroyFeedAd = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.destroyFeedAd", params)];
                });
            });
        };
        NativeAdvert.prototype.getFeedAdDatas = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.getFeedAdDatas", params)];
                });
            });
        };
        NativeAdvert.prototype.performClick = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.performClick", params)];
                });
            });
        };
        NativeAdvert.prototype.performCreativeClick = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("ironsrc:IronSource.performCreativeClick", params)];
                });
            });
        };
        // feed advert 事件
        NativeAdvert.prototype.onFeedAdLoaded = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onEvent("ironsrc:onFeedAdLoaded", callback)];
                });
            });
        };
        NativeAdvert.prototype.onFeedAdLoadFailed = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onEvent("ironsrc:onFeedAdLoadFailed", callback)];
                });
            });
        };
        NativeAdvert.prototype.onFeedAdClicked = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onFeedAdClicked", callback)];
                });
            });
        };
        NativeAdvert.prototype.onFeedAdShown = function (callback) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.onDoneEvent("ironsrc:onFeedAdShown", callback)];
                });
            });
        };
        /**
          * 广告平台选择
          * - gdtadvert 广点通
          * - budadadvert 头条广告
         */
        NativeAdvert.prototype.advertPlatformSelect = function (platform) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    if (gdkjsb.bridge == undefined)
                        return [2 /*return*/];
                    return [2 /*return*/, UnityAppGDK.nativeHelper.safeCallAction("advertPlatformSelect", { message: platform })];
                });
            });
        };
        NativeAdvert.prototype.initMultAdSlot = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    if (gdkjsb.bridge == undefined)
                        return [2 /*return*/];
                    return [2 /*return*/, UnityAppGDK.nativeHelper.safeCallAction("initMultAdSlot", { slotInfo: params })];
                });
            });
        };
        return NativeAdvert;
    }());
    UnityAppGDK.NativeAdvert = NativeAdvert;
})(UnityAppGDK || (UnityAppGDK = {}));
/// <reference path="./NativeHelper.ts" />
var UnityAppGDK;
(function (UnityAppGDK) {
    var PayErrorCode;
    (function (PayErrorCode) {
        PayErrorCode[PayErrorCode["BIND_GOOGLE_SERVICE_FAILED"] = 0] = "BIND_GOOGLE_SERVICE_FAILED";
        PayErrorCode[PayErrorCode["SEND_PAY_REQUEST_FAILED"] = 1] = "SEND_PAY_REQUEST_FAILED";
        PayErrorCode[PayErrorCode["CATCH_EXCEPTIONS"] = 2] = "CATCH_EXCEPTIONS";
        PayErrorCode[PayErrorCode["PURCHASE_CANCELLED"] = 3] = "PURCHASE_CANCELLED";
        PayErrorCode[PayErrorCode["ON_CODE_REQUEST_GPV3"] = 4] = "ON_CODE_REQUEST_GPV3";
        PayErrorCode[PayErrorCode["OWNED_SUCH_ITEM"] = 5] = "OWNED_SUCH_ITEM";
        PayErrorCode[PayErrorCode["INVALID_PARAMS"] = 6] = "INVALID_PARAMS";
        /**
         * 依赖的app未安装
         */
        PayErrorCode[PayErrorCode["DEPENDENCE_APP_NOT_INSTALLED"] = 7] = "DEPENDENCE_APP_NOT_INSTALLED";
    })(PayErrorCode = UnityAppGDK.PayErrorCode || (UnityAppGDK.PayErrorCode = {}));
    var NativePayResult = /** @class */ (function () {
        function NativePayResult() {
        }
        return NativePayResult;
    }());
    UnityAppGDK.NativePayResult = NativePayResult;
    var NativePay = /** @class */ (function () {
        function NativePay() {
        }
        /**
         * @param sku: 商品id
         */
        NativePay.prototype.initPay = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("paywrapper:initPay", params)];
                });
            });
        };
        /**
         * @param sku: 商品id
         */
        NativePay.prototype.requestPay = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    params.coopOrder = "GleeOrderX";
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("paywrapper:requestPay", params)];
                });
            });
        };
        /**
         * 消耗商品
         */
        NativePay.prototype.consumePurchase = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("paywrapper:consumePurchase", params)];
                });
            });
        };
        /**
         * 获取未消耗商品列表
         */
        NativePay.prototype.queryItemInfo = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("paywrapper:queryItemInfo", params)];
                });
            });
        };
        return NativePay;
    }());
    UnityAppGDK.NativePay = NativePay;
})(UnityAppGDK || (UnityAppGDK = {}));
/// <reference path="./NativeHelper.ts" />
/// <reference path="../../../framework/sense/ILocalPush.ts" />
var UnityAppGDK;
(function (UnityAppGDK) {
    var NativeLocalPushStyle = /** @class */ (function (_super) {
        __extends(NativeLocalPushStyle, _super);
        function NativeLocalPushStyle() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return NativeLocalPushStyle;
    }(GDK.LocalPushBundle));
    UnityAppGDK.NativeLocalPushStyle = NativeLocalPushStyle;
    var NativeLocalPush = /** @class */ (function () {
        function NativeLocalPush() {
        }
        /**
         * 初始化
         */
        NativeLocalPush.prototype.init = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("pushwrapper:initLocalNotice", {})];
                });
            });
        };
        /**
         * 添加本地推送
         */
        NativeLocalPush.prototype.addLocalNotices = function (notices) {
            return __awaiter(this, void 0, void 0, function () {
                var params;
                return __generator(this, function (_a) {
                    params = {
                        notices: notices || [],
                    };
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("pushwrapper:addLocalNotices", params)];
                });
            });
        };
        /**
         * 移除对应的推送
         */
        NativeLocalPush.prototype.removeLocalNoticeWithID = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("pushwrapper:removeLocalNoticeWithID", params)];
                });
            });
        };
        /**
         * 移除所有推送
         */
        NativeLocalPush.prototype.removeAllLocalNotices = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("pushwrapper:removeAllLocalNotices", {})];
                });
            });
        };
        /**
         * 检查推送设置，如果没有权限则提示用户跳转开启
         */
        NativeLocalPush.prototype.requireLocalNoticePermission = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("pushwrapper:requireLocalNoticePermission", {})];
                });
            });
        };
        /**
         * 用户是否开启通知权限
         */
        NativeLocalPush.prototype.isLocalNoticeEnabled = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.nativeHelper.callAction("pushwrapper:isLocalNoticeEnabled", {})];
                });
            });
        };
        return NativeLocalPush;
    }());
    UnityAppGDK.NativeLocalPush = NativeLocalPush;
})(UnityAppGDK || (UnityAppGDK = {}));
/// <reference path="./native/NativeAdvert.ts" />
/// <reference path="./native/NativePay.ts" />
/// <reference path="./native/NativeLocalPush.ts" />
var UnityAppGDK;
(function (UnityAppGDK) {
    /**
     * 用户信息本地存储的key
     */
    var USER_INFO_KEY = "$OFNIRESU$";
    var USER_INFO_XXTEA_KEY = "key$OFNIRESU$key";
    var SDKProxy = /** @class */ (function () {
        function SDKProxy() {
        }
        /**
         * 加载用户登陆信息
         */
        SDKProxy.loadUserRecord = function (removeNullUser) {
            if (removeNullUser === void 0) { removeNullUser = false; }
            var ret;
            try {
                var data = localStorage.getItem(USER_INFO_KEY);
                if (data && data != "") {
                    console.log("loadUserRecord:", slib.xxtea.decryptFromBase64(data, USER_INFO_XXTEA_KEY));
                    var d = JSON.parse(slib.xxtea.decryptFromBase64(data, USER_INFO_XXTEA_KEY));
                    var list = d instanceof Array ? d : [d];
                    if (list.length == 0 || list[0].loginType == null) { //简单验证一下
                        return [];
                    }
                    //删除openId等于空的记录，一般由登陆失败产生
                    if (removeNullUser)
                        for (var i = list.length - 1; i >= 0; i--) {
                            if (list[i].openId == null) {
                                list.splice(i, 1);
                            }
                        }
                    return list;
                }
                else {
                    console.log("loadUserRecord: nil");
                }
                return [];
            }
            catch (e) {
                return [];
            }
        };
        /**
         * 保存登陆信息
         * @param data
         */
        SDKProxy.saveUserRecord = function (data) {
            var str = JSON.stringify(data);
            var xxt = slib.xxtea.encryptToBase64(str, USER_INFO_XXTEA_KEY);
            console.log("saveUserRecord:", USER_INFO_KEY, str, xxt);
            localStorage.setItem(USER_INFO_KEY, xxt);
        };
        /**
         * 显示普通菊花
         */
        SDKProxy.showLoading = function () {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("showLoading", "{}", function (data) { });
            // CS.Glee.LoginWrap.getInstance().showLoading("{}")
        };
        /**
         * 隐藏普通菊花
         */
        SDKProxy.hideLoading = function () {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("hideLoading", "{}", function (data) { });
            // CS.Glee.LoginWrap.getInstance().hideLoading("{}")
        };
        /**
         * 隐藏正在登陆提示
         */
        SDKProxy.hideLogining = function () {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("hideLogining", "{}", function (data) { });
            // CS.Glee.LoginWrap.getInstance().hideLogining("{}")
        };
        /**
         * 显示正在登陆提示
         * @param message 提示信息
         */
        SDKProxy.showLogining = function (message, loginType) {
            if (gdkjsb.bridge == undefined)
                return;
            if (message == null || message == "") {
                message = slib.i18n.locSDKString("welcome");
            }
            gdkjsb.bridge.callAction("showLogining", JSON.stringify({ message: message, loginType: loginType }), function (data) { });
            // CS.Glee.LoginWrap.getInstance().showLogining(JSON.stringify({ message: message, loginType: loginType }))
        };
        /**
         * 登陆登陆弹框
         * @param callback 玩家登陆的回掉
         */
        SDKProxy.showLoginDialog = function () {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("showLoginDialog", JSON.stringify({ support: this.support, records: this.loadUserRecord(true) }), function (data) { });
            // CS.Glee.LoginWrap.getInstance().showLoginDialog(JSON.stringify({ support: this.support, records: this.loadUserRecord(true) }))
        };
        /**
         * 隐藏登陆对话框
         */
        SDKProxy.hideLoginDialog = function () {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("hideLoginDialog", "{}", function (data) { });
            // CS.Glee.LoginWrap.getInstance().hideLoginDialog("{}");
        };
        SDKProxy.loginWithBus = function (loginInfo, callbacks) {
            if (gdkjsb.bridge == undefined)
                return;
            var aaa = new ServedLoginInfo();
            aaa.loginNode = "2342";
            console.log("JSON.stringify(loginInfo):" + JSON.stringify({}));
            gdkjsb.bridge.callAction("loginWithBus", "{}", function (sdata) {
                var data = JSON.parse(sdata);
                if (data.succeed) {
                    var ret = new LoginServerResult();
                    ret.serverData = data.data.rawData.r;
                    console.log("loginWithBus ret:" + JSON.stringify(ret));
                    callbacks.onSuccess(ret);
                }
                else {
                    console.log("loginWithBus failed:" + JSON.stringify(data.data));
                    callbacks.onFailed(data.data);
                }
            });
        };
        /**
         * 显示用户中心
         * @param info 玩家的基础信息
         * @param callback 绑定的回掉函数
         */
        SDKProxy.showUserCenter = function (userInfo) {
            if (gdkjsb.bridge == undefined)
                return;
            userInfo = userInfo || this.loadUserRecord()[0];
            gdkjsb.bridge.callAction("showUserCenter", JSON.stringify({ info: userInfo, support: this.support, records: this.loadUserRecord(true) }), function (data) { });
            // CS.Glee.LoginWrap.getInstance().showUserCenter(JSON.stringify({ info: userInfo, support: this.support, records: this.loadUserRecord(true) }));
        };
        /**
         * 隐藏用户中心图标
         */
        SDKProxy.hideUserCenter = function () {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("hideUserCenter", "{}", function (data) { });
            // CS.Glee.LoginWrap.getInstance().hideUserCenter("{}");
        };
        /**
         * 隐藏用户中心图标
         */
        SDKProxy.hideBindDialog = function () {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("hideBindDialog", "{}", function (data) { });
            // CS.Glee.LoginWrap.getInstance().hideBindDialog("{}");
        };
        SDKProxy.showBindDialog = function (userInfo) {
            if (gdkjsb.bridge == undefined)
                return;
            userInfo = userInfo || this.loadUserRecord()[0];
            gdkjsb.bridge.callAction("showBindDialog", JSON.stringify({ info: userInfo, support: this.support, records: this.loadUserRecord(true) }), function (data) { });
            // CS.Glee.LoginWrap.getInstance().showBindDialog(JSON.stringify({ info: userInfo, support: this.support, records: this.loadUserRecord(true) }));
        };
        /**
         * 显示未成年人游戏描述信息
         */
        SDKProxy.showMinorInfo = function (info, callback) {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("showMinorInfo", JSON.stringify({ info: info }), callback);
        };
        /**
         * 显示实名制弹框，进入实名制流程
         * @param force 是否强制
         */
        SDKProxy.showRealNameDialog = function (userId, force, callback) {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("showRealNameDialog", JSON.stringify({ userId: userId, force: force }), function (d) {
                callback(JSON.parse(d));
            });
        };
        /**
         * 侦听取消登陆的回掉接口
         * @param callback
         */
        SDKProxy.onCancelLogining = function (callback) {
            if (gdkjsb.bridge == undefined)
                return;
            if (this.cancelLoginingId !== undefined) {
                gdkjsb.bridge.off(this.cancelLoginingId);
            }
            this.cancelLoginingId = gdkjsb.bridge.on("cancelLogining", callback);
        };
        /**
         * 对玩家执行自动登陆
         * @param user
         */
        SDKProxy.autoLogin = function (user) {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("autoLogin", JSON.stringify(user), function (data) { });
            // CS.Glee.LoginWrap.getInstance().autoLogin(JSON.stringify(user));
        };
        /**
         * 对玩家执行自动登陆
         * @param user
         */
        SDKProxy.loginNative = function () {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("loginNative", JSON.stringify({ support: this.support, records: this.loadUserRecord(true) }), function (data) { });
        };
        SDKProxy.onLogin = function (callback) {
            if (gdkjsb.bridge == undefined)
                return;
            if (this.loginId !== undefined) {
                gdkjsb.bridge.off(this.loginId);
            }
            this.loginId = gdkjsb.bridge.on("login", function (data) {
                console.log("loginroute-JSBOnLoginData:", data);
                var json = JSON.parse(data);
                callback(json.type, json.openId, json.token, json.nickName, json.email, json.head, json.platform, json.exAuthData);
            });
        };
        SDKProxy.onRebootLogin = function (callback) {
            if (gdkjsb.bridge == undefined)
                return;
            if (this.rebootLoginId !== undefined) {
                gdkjsb.bridge.off(this.rebootLoginId);
            }
            this.rebootLoginId = gdkjsb.bridge.on("rebootLogin", function (data) {
                var json = JSON.parse(data);
                callback(json.type, json.openId, json.token, json.nickName, json.email, json.head);
            });
        };
        SDKProxy.onBind = function (callback) {
            if (gdkjsb.bridge == undefined)
                return;
            if (this.bindId !== undefined) {
                gdkjsb.bridge.off(this.bindId);
            }
            this.bindId = gdkjsb.bridge.on("bind", function (data) {
                var json = JSON.parse(data);
                callback(json.type, json.visitorOpenId, json.openId, json.token, json.platform);
            });
        };
        SDKProxy.onLoginFail = function (callback) {
            if (gdkjsb.bridge == undefined)
                return;
            if (this.loginFailId !== undefined) {
                gdkjsb.bridge.off(this.loginFailId);
            }
            this.loginFailId = gdkjsb.bridge.on("loginFail", function (data) {
                var json = JSON.parse(data);
                callback();
            });
        };
        SDKProxy.onRemoveUser = function (callback) {
            if (gdkjsb.bridge == undefined)
                return;
            if (this.removeUserId !== undefined) {
                gdkjsb.bridge.off(this.removeUserId);
            }
            this.removeUserId = gdkjsb.bridge.on("removeUser", function (data) {
                var json = JSON.parse(data);
                callback(json.openId);
            });
        };
        SDKProxy.onLogout = function (callback) {
            if (gdkjsb.bridge == undefined)
                return;
            if (this.logoutId !== undefined) {
                gdkjsb.bridge.off(this.logoutId);
            }
            this.logoutId = gdkjsb.bridge.on("logout", function (data) {
                callback();
            });
        };
        /**
         * 隐藏启动屏
         */
        SDKProxy.hideLaunchingView = function () {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("hideLaunchingView", "{}", function (data) { });
            // CS.Glee.LoginWrap.getInstance().hideLaunchingView("{}");
        };
        SDKProxy.support = { google: true, visitor: true, facebook: true, wechat: true, gamecenter: true };
        SDKProxy.cancelLoginingId = undefined;
        SDKProxy.loginId = undefined;
        SDKProxy.rebootLoginId = undefined;
        SDKProxy.bindId = undefined;
        SDKProxy.loginFailId = undefined;
        SDKProxy.removeUserId = undefined;
        SDKProxy.logoutId = undefined;
        SDKProxy.nativeAdvert = new UnityAppGDK.NativeAdvert();
        SDKProxy.nativePay = new UnityAppGDK.NativePay();
        SDKProxy.nativeLocalPush = new UnityAppGDK.NativeLocalPush();
        return SDKProxy;
    }());
    UnityAppGDK.SDKProxy = SDKProxy;
})(UnityAppGDK || (UnityAppGDK = {}));
/// <reference path="./SDKProxy.ts" />
var UnityAppGDK;
(function (UnityAppGDK) {
    var APISystem = /** @class */ (function (_super) {
        __extends(APISystem, _super);
        function APISystem() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._showList = [];
            _this._hideList = [];
            return _this;
        }
        APISystem.prototype.init = function () {
            var _this = this;
            _super.prototype.init.call(this);
            //侦听show hide
            if (gdkjsb.bridge) {
                gdkjsb.bridge.on("app:show", function (data) {
                    var jsonData = null;
                    try {
                        jsonData = JSON.parse(data);
                    }
                    catch (e) {
                    }
                    for (var _i = 0, _a = _this._showList.concat(); _i < _a.length; _i++) {
                        var f = _a[_i];
                        f(jsonData);
                    }
                });
                gdkjsb.bridge.on("app:hide", function (data) {
                    var jsonData = null;
                    try {
                        jsonData = JSON.parse(data);
                    }
                    catch (e) {
                    }
                    for (var _i = 0, _a = _this._hideList.concat(); _i < _a.length; _i++) {
                        var f = _a[_i];
                        f(jsonData);
                    }
                });
            }
        };
        APISystem.prototype.getSafeArea = function (callback) {
            if (gdkjsb.bridge == undefined) {
                //兼容无gdkjsb的包
                callback({ left: 0, right: 0, top: 0, bottom: 0 });
            }
            else {
                if (gdkjsb.bridge.callAction("DisplayCutout:getSafeArea", "{}", function (data) {
                    callback(JSON.parse(data));
                }) != true) {
                    //兼容 nativeVersion == 0
                    callback({ left: 0, right: 0, top: 0, bottom: 0 });
                }
            }
        };
        Object.defineProperty(APISystem.prototype, "nativeVersion", {
            get: function () {
                return gdkjsb.nativeVersion || 0;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(APISystem.prototype, "sdkFrameworkVersion", {
            get: function () {
                return gdkjsb.bridge.sdkFrameworkVersion || "2.0";
            },
            enumerable: true,
            configurable: true
        });
        APISystem.prototype.openURL = function (url) {
            gdkjsb.openURL(url);
        };
        APISystem.prototype.startYunkefu = function (accessId, name, id, customField, native) {
            if (native) {
                gdkjsb.bridge.callAction("showsAssistantCenter", JSON.stringify({ name: name, id: id, customField: customField }), function (data) { });
                return;
            }
            // if (nativeHelper.checkActionExist("StartYunkefu")) {
            // 	nativeHelper.callAction("StartYunkefu", { accessId: accessId, name: name, id: id, customField: customField })
            // } else {
            var otherParams = {
                nickName: name
            };
            gdk.openURL(encodeURI("https://ykf-webchat.7moor.com/wapchat.html?accessId=" + accessId + "&clientId=" + id + "&otherParams=" + JSON.stringify(otherParams) + "&fromUrl=" + gdk.systemInfo.packageName + "&urlTitle=" + gdk.systemInfo.packageTag + "&customField=" + JSON.stringify(customField)));
            // }
        };
        APISystem.prototype.hasNativeAssistantCenter = function () {
            return gdkjsb.bridge.checkActionExist("showsAssistantCenter");
        };
        APISystem.prototype.showHackWeb = function (url, duration) {
            if (gdkjsb.showHackWeb) {
                gdkjsb.showHackWeb(url, duration);
            }
        };
        APISystem.prototype.setSDKLanguage = function (lang) {
            if (gdkjsb.setSDKLanguage) {
                gdkjsb.setSDKLanguage(lang);
            }
        };
        APISystem.prototype.onShow = function (callback) {
            this._showList.push(callback);
        };
        APISystem.prototype.offShow = function (callback) {
            this._showList.remove(callback);
        };
        APISystem.prototype.onHide = function (callback) {
            this._hideList.push(callback);
        };
        APISystem.prototype.offHide = function (callback) {
            this._hideList.remove(callback);
        };
        APISystem.prototype.gotoAppSystemSettings = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    // return nativeHelper.safeCallAction("utils:gotoAppSystemSettings", params)
                    return [2 /*return*/, new Promise(function (resolve, reject) {
                            gdkjsb.gotoAppSystemSettings(JSON.stringify(params), function (p) {
                                resolve(JSON.parse(p || "null"));
                            });
                        })];
                });
            });
        };
        APISystem.prototype.checkAppSystemPermissions = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    // return nativeHelper.safeCallAction<GDK.ICheckPermissionResult>("utils:checkAppSystemPermissions", params)
                    return [2 /*return*/, new Promise(function (resolve, reject) {
                            gdkjsb.checkAppSystemPermissions(JSON.stringify(params), function (p) {
                                resolve(JSON.parse(p || "null"));
                            });
                        })];
                });
            });
        };
        APISystem.prototype.exitProgram = function () {
            var ret = new GDK.RPromise();
            if (gdkjsb.exitProgram) {
                gdkjsb.exitProgram();
            }
            setTimeout(function () {
                ret.success();
            }, 0);
            return ret.promise;
        };
        return APISystem;
    }(GDK.APISystemBase));
    UnityAppGDK.APISystem = APISystem;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var Common;
    (function (Common) {
        Common.devlog = new slib.Log({ tags: ["[gdk]", "[wechat]"] });
        Common.paylog = new slib.Log({ tags: ["[gdk]", "[wepay]"] });
    })(Common = UnityAppGDK.Common || (UnityAppGDK.Common = {}));
})(UnityAppGDK || (UnityAppGDK = {}));
/// <reference path="Common.ts" />
var UnityAppGDK;
(function (UnityAppGDK) {
    var devlog = UnityAppGDK.Common.devlog;
    var Advert = /** @class */ (function () {
        function Advert() {
        }
        Advert.prototype.initWithConfig = function (_info) {
            return __awaiter(this, void 0, void 0, function () {
                var info, _i, _a, key, debug;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            info = _info //as GDK.GDKAPPConfig
                            ;
                            info.app.advertPlatforms = info.app.advertPlatforms || [];
                            if (info.app.advertPlatforms.length == 0) {
                                info.app.advertPlatform = info.app.advertPlatform || 'ironsource';
                            }
                            if (info.app.advertPlatform) {
                                info.app.advertPlatforms.remove(info.app.advertPlatform);
                                info.app.advertPlatforms.push(info.app.advertPlatform);
                            }
                            _i = 0, _a = info.app.advertPlatforms;
                            _b.label = 1;
                        case 1:
                            if (!(_i < _a.length)) return [3 /*break*/, 8];
                            key = _a[_i];
                            // 选择广告平台
                            return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.advertPlatformSelect(key)];
                        case 2:
                            // 选择广告平台
                            _b.sent();
                            return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.setRewardedVideoListener()];
                        case 3:
                            _b.sent();
                            if (!this.supportInterstitialAd) return [3 /*break*/, 5];
                            return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.setInterstitialListener()];
                        case 4:
                            _b.sent();
                            _b.label = 5;
                        case 5: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.init({
                                appKey: "ironsrcappkey", modules: {
                                    REWARDED_VIDEO: true,
                                    BANNER: true,
                                    INTERSTITIAL: this.supportInterstitialAd,
                                }
                            })];
                        case 6:
                            _b.sent();
                            debug = false;
                            UnityAppGDK.SDKProxy.nativeAdvert.setAdaptersDebug({ debug: debug });
                            UnityAppGDK.SDKProxy.nativeAdvert.shouldTrackNetworkState({ track: debug });
                            _b.label = 7;
                        case 7:
                            _i++;
                            return [3 /*break*/, 1];
                        case 8: return [2 /*return*/];
                    }
                });
            });
        };
        Advert.prototype.createRewardedVideoAd = function (params) {
            if (!Advert._videoAd) {
                // if (this.supportInterstitialAd) {
                // 	Advert._videoAd = new InterstitialAd(params, this.api)
                // } else {
                Advert._videoAd = new UnityAppGDK.VideoAd(params, this.api);
                // }
            }
            return Advert._videoAd;
        };
        Object.defineProperty(Advert.prototype, "supportFullscreenAd", {
            get: function () {
                return this.supportFullscreenVideoAd;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Advert.prototype, "supportFullscreenVideoAd", {
            get: function () {
                return UnityAppGDK.nativeHelper.checkActionExist("ironsrc:IronSource.showFullScreenVideo");
            },
            enumerable: true,
            configurable: true
        });
        Advert.prototype.createFullscreenVideoAd = function (params) {
            if (!Advert._fullscreenAd) {
                if (this.supportFullscreenVideoAd) {
                    Advert._fullscreenAd = new UnityAppGDK.FullscreenVedioAd(params, this.api);
                }
                else {
                    // Advert._fullscreenAd = new VideoAd(params, this.api)
                    devlog.error("当前app版本过低，不支持插屏广告(Interstitial)");
                }
            }
            return Advert._fullscreenAd;
        };
        Object.defineProperty(Advert.prototype, "supportInterstitialAd", {
            get: function () {
                return UnityAppGDK.nativeHelper.checkActionExist("ironsrc:IronSource.showInterstitial");
            },
            enumerable: true,
            configurable: true
        });
        Advert.prototype.createInterstitialAd = function (params) {
            if (!Advert._interstitialAd) {
                if (this.supportInterstitialAd) {
                    Advert._interstitialAd = new UnityAppGDK.InterstitialAd(params, this.api);
                }
                else {
                    // Advert._interstitialAd = new VideoAd(params, this.api)
                    devlog.error("当前app版本过低，不支持插屏广告(Interstitial)");
                }
            }
            return Advert._interstitialAd;
        };
        Advert.prototype.createBannerAd = function (params) {
            if (!Advert._bannerAd) {
                Advert._bannerAd = new UnityAppGDK.BannerAd(params);
            }
            else {
                Advert._bannerAd.reset(params);
            }
            return Advert._bannerAd;
        };
        Object.defineProperty(Advert.prototype, "supportFeedAd", {
            get: function () {
                return gdkjsb.country == "CN" && UnityAppGDK.nativeHelper.checkActionExist("ironsrc:IronSource.createFeedAd");
            },
            enumerable: true,
            configurable: true
        });
        Advert.prototype.createFeedAd = function (params) {
            return new UnityAppGDK.FeedAd(params);
        };
        Advert.prototype.selectAdvertPlatform = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                var ret, videoAd, _a, _b;
                return __generator(this, function (_c) {
                    switch (_c.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.advertPlatformSelect(params.platform || "ironsource")];
                        case 1:
                            ret = _c.sent();
                            videoAd = Advert._videoAd;
                            if (!(videoAd != null && videoAd instanceof UnityAppGDK.VideoAd)) return [3 /*break*/, 3];
                            _b = (_a = videoAd)['onRewardedVideoAvailabilityChanged'];
                            return [4 /*yield*/, videoAd.checkAvailable()];
                        case 2:
                            _b.apply(_a, [_c.sent()]);
                            _c.label = 3;
                        case 3: return [2 /*return*/, ret];
                    }
                });
            });
        };
        Advert.prototype.initMultAdSlot = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                var ret;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.initMultAdSlot(params)];
                        case 1:
                            ret = _a.sent();
                            return [2 /*return*/, ret];
                    }
                });
            });
        };
        Advert.prototype.initAdService = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, new Promise(function (resolve, reject) {
                            resolve();
                        })];
                });
            });
        };
        return Advert;
    }());
    UnityAppGDK.Advert = Advert;
})(UnityAppGDK || (UnityAppGDK = {}));
/// <reference path="Common.ts" />
var AppGDK;
(function (AppGDK) {
    var devlog = Common.devlog;
    var AdvertV2 = /** @class */ (function () {
        function AdvertV2() {
        }
        AdvertV2.prototype.createAdvertUnit = function (createInfo) {
            return __awaiter(this, void 0, void 0, function () {
                var adUnit;
                return __generator(this, function (_a) {
                    adUnit = new AdvertUnit(createInfo);
                    return [2 /*return*/, adUnit];
                });
            });
        };
        AdvertV2.prototype.isAdvertTypeSupported = function (advertType) {
            return AdvertUnitRaw.isAdvertTypeSupported(advertType);
        };
        return AdvertV2;
    }());
    AppGDK.AdvertV2 = AdvertV2;
})(AppGDK || (AppGDK = {}));
/// <reference path="./Common.ts" />
var UnityAppGDK;
(function (UnityAppGDK) {
    var devlog = UnityAppGDK.Common.devlog;
    var Auth = /** @class */ (function () {
        function Auth() {
        }
        Auth.prototype.createUserInfoButton = function (obj) {
            devlog.info("createUserInfoButton");
            return null;
        };
        Auth.prototype.isUserInfoAuthAlready = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, true];
                });
            });
        };
        return Auth;
    }());
    UnityAppGDK.Auth = Auth;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var RReqPromise = /** @class */ (function (_super) {
        __extends(RReqPromise, _super);
        function RReqPromise(params) {
            return _super.call(this, params) || this;
        }
        RReqPromise.prototype.init = function (params) {
            var _this = this;
            this.promise = new Promise(function (resolve, reject) {
                _this.success = function (data) {
                    var data1 = data == undefined ? {} : data;
                    resolve(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.SUCCESS, {
                        msg: params.okmsg || undefined,
                        reason: params.okreason || data1['errMsg'] || undefined,
                        data: data1
                    }));
                };
                _this.fail = function () {
                    reject(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.UNKNOWN, {
                        msg: params.failmsg || undefined,
                        reason: params.failreason || undefined
                    }));
                };
            });
        };
        return RReqPromise;
    }(GDK.RPromise));
    UnityAppGDK.RReqPromise = RReqPromise;
    function wrapReq(fun, object, code) {
        var ret = new GDK.RPromise();
        object.success = ret.success;
        object.fail = function () {
            ret.fail(GDK.GDKResultTemplates.make(code));
        };
        fun(object);
        return ret.promise;
    }
    UnityAppGDK.wrapReq = wrapReq;
    var RLoginPromise = /** @class */ (function (_super) {
        __extends(RLoginPromise, _super);
        function RLoginPromise() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return RLoginPromise;
    }(RReqPromise));
    UnityAppGDK.RLoginPromise = RLoginPromise;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    /** 客服 */
    var Customer = /** @class */ (function () {
        function Customer() {
        }
        Customer.prototype.openCustomerServiceConversation = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    this.api.showAlert({ content: "你成功打开了客服界面", title: "客服界面测试" });
                    return [2 /*return*/, null];
                });
            });
        };
        return Customer;
    }());
    UnityAppGDK.Customer = Customer;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var Except = /** @class */ (function () {
        function Except() {
            this._isListener = false;
        }
        Except.prototype.setErrorCallback = function (callback) {
            this._errorCallback = callback;
            if (!this._isListener) {
                this._isListener = true;
                // window.onerror = (res) => {
                // 	//检查该错误是否提交过
                // 	this._errorCallback({ message: res.toString(), stack: new Error().stack });
                // }
            }
        };
        return Except;
    }());
    UnityAppGDK.Except = Except;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var GameInfo = /** @class */ (function (_super) {
        __extends(GameInfo, _super);
        function GameInfo() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        GameInfo.prototype.initWithConfig = function (info) {
            for (var k in info.app) {
                this[k] = info.app[k];
            }
            UnityAppGDK.Common.getServerTime = info.app.getServerTime;
            UnityAppGDK.Common.httpClient = info.app.httpClient;
        };
        GameInfo.prototype.init = function () {
        };
        return GameInfo;
    }(GDK.GameInfoBase));
    UnityAppGDK.GameInfo = GameInfo;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var devlog = UnityAppGDK.Common.devlog;
    var Vibration = /** @class */ (function () {
        function Vibration() {
        }
        Vibration.prototype.vibrateLong = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("vibrateLong");
                    // 使手机发生较长时间的振动（400 ms）
                    window['jsb'].device.vibrate(0.4);
                    return [2 /*return*/];
                });
            });
        };
        Vibration.prototype.vibrateShort = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("vibrateShort");
                    // 使手机发生较短时间的振动（15 ms）。仅在 iPhone 7 / 7 Plus 以上及 Android 机型生效
                    window['jsb'].device.vibrate(0.015);
                    return [2 /*return*/];
                });
            });
        };
        Vibration.prototype.vibrate = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("vibrate", params);
                    window['jsb'].device.vibrate(params.duration);
                    return [2 /*return*/];
                });
            });
        };
        return Vibration;
    }());
    var Hardware = /** @class */ (function (_super) {
        __extends(Hardware, _super);
        function Hardware() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.vibration = new Vibration();
            return _this;
        }
        return Hardware;
    }(GDK.HardwareBase));
    UnityAppGDK.Hardware = Hardware;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var devlog = UnityAppGDK.Common.devlog;
    var LocalPush = /** @class */ (function () {
        function LocalPush() {
        }
        LocalPush.prototype.init = function () {
            UnityAppGDK.SDKProxy.nativeLocalPush.init();
            // setTimeout(async () => {
            // 	await this.api.requireLocalNoticePermission()
            // 	let { enabled } = await this.api.isLocalNoticeEnabled()
            // 	console.log("isLocalNoticeEnabled:", enabled)
            // 	// await this.api.removeAllLocalNotices()
            // 	let bundles = []
            // 	{
            // 		let bundle = new GDK.LocalPushBundle()
            // 		bundle.identifier = "1"
            // 		bundle.interval = 20000
            // 		bundle.title = "标题1"
            // 		bundle.content = "测试内容"
            // 		bundle.ticker = "哈哈哈1"
            // 		bundles.push(bundle)
            // 	}
            // 	{
            // 		let bundle = new GDK.LocalPushBundle()
            // 		bundle.identifier = "2"
            // 		bundle.interval = 5000
            // 		bundle.title = "标题2"
            // 		bundle.content = "测试内容"
            // 		bundle.ticker = "哈哈哈2"
            // 		bundles.push(bundle)
            // 	}
            // 	{
            // 		let bundle = new GDK.LocalPushBundle()
            // 		bundle.identifier = "3"
            // 		bundle.interval = 3000
            // 		bundle.title = "标题3"
            // 		bundle.content = "测试内容"
            // 		bundle.ticker = "哈哈哈3"
            // 		bundles.push(bundle)
            // 	}
            // 	{
            // 		let bundle = new GDK.LocalPushBundle()
            // 		bundle.identifier = "3"
            // 		bundle.interval = 3000
            // 		bundle.title = "标题4"
            // 		bundle.content = "测试内容"
            // 		bundle.ticker = "哈哈哈4"
            // 		bundles.push(bundle)
            // 	}
            // 	await this.api.addLocalNotices([{
            // 		identifier: "4343",
            // 		interval: 2332,
            // 		enableVibrateTip: true,
            // 		enableLightTip: true,
            // 	}])
            // 	await this.api.addLocalNotices([bundles[0], bundles[1], bundles[2],])
            // 	await this.api.removeLocalNoticeWithID({ identifier: "3" })
            // 	await this.api.addLocalNotices([bundles[3]])
            // }, 2000)
        };
        /**
         * 添加本地推送
         */
        LocalPush.prototype.addLocalNotices = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.SDKProxy.nativeLocalPush.addLocalNotices(params)];
                });
            });
        };
        /**
         * 移除对应的推送
         */
        LocalPush.prototype.removeLocalNoticeWithID = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.SDKProxy.nativeLocalPush.removeLocalNoticeWithID(params)];
                });
            });
        };
        /**
         * 移除所有推送
         */
        LocalPush.prototype.removeAllLocalNotices = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.SDKProxy.nativeLocalPush.removeAllLocalNotices()];
                });
            });
        };
        /**
         * 检查推送设置，如果没有权限则提示用户跳转开启
         */
        LocalPush.prototype.requireLocalNoticePermission = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.SDKProxy.nativeLocalPush.requireLocalNoticePermission()];
                });
            });
        };
        /**
         * 用户是否开启通知权限
         */
        LocalPush.prototype.isLocalNoticeEnabled = function () {
            return UnityAppGDK.SDKProxy.nativeLocalPush.isLocalNoticeEnabled();
        };
        return LocalPush;
    }());
    UnityAppGDK.LocalPush = LocalPush;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var Log = /** @class */ (function () {
        function Log() {
        }
        /**
         * 提交自定义日志到服务器
         * @param key key
         * @param params 参数
         */
        Log.prototype.commitLog = function (key, params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    UnityAppGDK.LogBridge.logCustomEvent(key, params);
                    return [2 /*return*/];
                });
            });
        };
        Log.prototype.commitChannelsLog = function (logType, params) {
            return __awaiter(this, void 0, void 0, function () {
                var p, p;
                return __generator(this, function (_a) {
                    if (logType == 'PayLog') {
                        p = params;
                        UnityAppGDK.LogBridge.logRequestPay(p.id, p.price, p.count, p.currency);
                    }
                    else if (logType == 'Paid') {
                        p = params;
                        UnityAppGDK.LogBridge.logPurchased(p.id, p.price, p.price, p.count, p.currency, p.succ);
                    }
                    else {
                        console.error("unsupport log type");
                    }
                    return [2 /*return*/];
                });
            });
        };
        Log.prototype.commitPayLog = function (index) {
            return __awaiter(this, void 0, void 0, function () {
                var key;
                return __generator(this, function (_a) {
                    key = "";
                    switch (index) {
                        case 1:
                            key = "fb_mobile_add_to_cart";
                            break;
                        case 2:
                            key = "fb_mobile_spent_credits";
                            break;
                        case 3:
                            key = "fb_mobile_content_view";
                            break;
                        case 4:
                            key = "Subscribe";
                            break;
                        case 5:
                            key = "fb_mobile_search";
                            break;
                        case 6:
                            key = "fb_mobile_tutorial_completion";
                            break;
                    }
                    if (key.length > 0) {
                        this.commitLog(key, {});
                    }
                    else {
                        console.error("unsupport PayLog index");
                    }
                    return [2 /*return*/];
                });
            });
        };
        return Log;
    }());
    UnityAppGDK.Log = Log;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var LogBridge = /** @class */ (function () {
        function LogBridge() {
        }
        /**
         * 自定义日志
         */
        LogBridge.logCustomEvent = function (key, params) {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("AppsFlyerSDK:logCustomEvent", JSON.stringify({ key: key, params: params, data: params }), function (data) { });
        };
        /**
         * 自定义日志
         */
        LogBridge.logLogin = function (type, userId) {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("AppsFlyerSDK:logLogin", JSON.stringify({ type: type, userId: userId }), function (data) { });
        };
        /**
         * 自定义日志
         */
        LogBridge.logRegister = function (type) {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("AppsFlyerSDK:logRegister", JSON.stringify({ type: type }), function (data) { });
        };
        /**
         * 自定义日志
         */
        LogBridge.logRequestPay = function (id, price, count, currency) {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("AppsFlyerSDK:logRequestPay", JSON.stringify({ id: id, price: price, count: count, currency: currency }), function (data) { });
        };
        /**
         * 自定义日志
         */
        LogBridge.logPurchased = function (id, revenue, price, count, currency, succ) {
            if (gdkjsb.bridge == undefined)
                return;
            gdkjsb.bridge.callAction("AppsFlyerSDK:logPurchased", JSON.stringify({ id: id, revenue: revenue, price: price, count: count, currency: currency, succ: succ }), function (data) { });
        };
        return LogBridge;
    }());
    UnityAppGDK.LogBridge = LogBridge;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var MServer = /** @class */ (function (_super) {
        __extends(MServer, _super);
        function MServer() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(MServer.prototype, "gameClient", {
            get: function () {
                return UnityAppGDK.Common.httpClient;
            },
            enumerable: true,
            configurable: true
        });
        /**
             * 用户登录接口(用户首次进入游戏调用)
             */
        MServer.prototype.loginTest = function (data, callback, errorCallback) {
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginTest", data, function (data) {
                callback(data);
            }, { modal: false, errorCallback: errorCallback });
        };
        MServer.prototype.userLogin = function (data, callback, errorCallback) {
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/login", data, function (data) {
                callback(data);
            }, { errorCallback: errorCallback });
        };
        /**
         * 游客登陆
         * * openId 传入空则产生新的账号
         * * 传入历史openId则表示游客再次登陆
         */
        MServer.prototype.loginOpenId = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginOpenId", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * FB登陆
         * * userId
         * * token
         */
        MServer.prototype.loginFB = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginFB", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * quick登陆
         * * userId
         * * token
         * * channleId
         */
        MServer.prototype.loginQuick = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginQuick", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * huawei登陆
         * * userId
         * * token
         * * channleId
         */
        MServer.prototype.loginHuawei = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginHwApp", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * 虫虫登陆
         */
        MServer.prototype.loginChongchong = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginCcApp", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * 路非凡登陆
         */
        MServer.prototype.loginLufeifan = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginLffApp", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * 京游登陆
         */
        MServer.prototype.loginJingyou = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginJinYouApp", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * xiao7登陆
         * * token
         */
        MServer.prototype.loginXiao7 = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginX7App", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * WX app登陆
         * * userId
         * * token
         */
        MServer.prototype.loginAppWX = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginAppWx", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * WX app android 登陆
         * * userId
         * * token
         */
        MServer.prototype.loginAppWXAndroid = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginAppWxAndroid", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * WX app android 登陆
         * * userId
         * * token
         */
        MServer.prototype.loginVivo = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginVivoApp", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * WX app android 登陆
         * * userId
         * * token
         */
        MServer.prototype.loginOppoApp = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginOppoApp", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * WX app android 登陆
         * * userId
         * * token
         */
        MServer.prototype.loginYYBApp = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginYybApp", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        MServer.prototype.loginMeituApp = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginMtApp", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * WX app android 登陆
         * * userId
         * * token
         */
        MServer.prototype.loginBaidu = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginOpenId", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * 阿里九游 登陆
         * * userId
         * * token
         */
        MServer.prototype.loginAligame = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginJyApp", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * FB登陆
         * * userId
         * * token
         */
        MServer.prototype.loginGC = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginGC", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        /**
         * FB登陆
         * * userId
         * * token
         */
        MServer.prototype.loginGoogle = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginGoogle", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        MServer.prototype.loginAccount = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/loginAccount", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        MServer.prototype.bindingAccount = function (data, callback, modal, errorCallback) {
            if (modal === void 0) { modal = false; }
            if (errorCallback === void 0) { errorCallback = null; }
            this.gameClient.request("user/bindingAccount", data, function (data) {
                callback(data);
            }, { modal: modal, errorCallback: errorCallback });
        };
        MServer.inst = new MServer();
        return MServer;
    }(GDK.APIServer));
    UnityAppGDK.MServer = MServer;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var paylog = UnityAppGDK.Common.paylog;
    var Pay = /** @class */ (function (_super) {
        __extends(Pay, _super);
        function Pay() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Pay.prototype.payPurchase = function (config, options) {
            var ret = new GDK.RPromise();
            var sku = config.productId;
            if (!sku) {
                var msg = 'payPurchase: productId 为空， 原生app需要传入productId';
                paylog.error(msg);
                ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_PAY_FAILED, {
                    message: msg
                }));
                return ret.promise;
            }
            UnityAppGDK.SDKProxy.nativePay.requestPay({
                productId: sku,
                sku: sku,
                price: config.money,
                count: config.amount,
                currency: "dollar",
                channelAppId: config.channelAppId,
                packageValue: "Sign=WXPay",
                nonceStr: config.nonceStr,
                partnerId: config.partnerId,
                paySign: config.paySign,
                prepayId: config.prepayId,
                timestamp: config.timestamp,
                payWay: options.payWay,
                extraStr: config.extraStr,
                title: config.title,
                orderNo: config.orderNo,
                payUrl: options.payUrl,
                gleeOrderNo: config.gleeOrderNo,
                accountId: config.accountId,
                notifyUrl: config.notifyUrl,
                aliamount: config.aliamount,
                gameSign: config.gameSign
            }).then(function (payret) {
                if (payret.code == 0) {
                    paylog.info("原生充值成功", config);
                    ret.success({
                        result: {
                            errCode: 0,
                        },
                        extra: payret,
                    });
                }
                else {
                    if (payret.code == UnityAppGDK.PayErrorCode.PURCHASE_CANCELLED) {
                        paylog.info("原生充值取消", payret, config);
                        ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_PAY_CANCEL));
                    }
                    else {
                        paylog.warn("原生充值失败", payret, config);
                        ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_PAY_FAILED, {
                            data: {
                                extra: payret
                            }
                        }));
                    }
                }
            }, function (payret) {
                ret.fail(payret);
            });
            /*
            // 1. do wechat pay
            if (options.payWay == "WechatPay") {
                SDKProxy.nativePay.requestPay({
                    sku: sku,
                    price: config.money,
                    count: 1,
                    currency: "dollar",

                    channelAppId: config.channelAppId,
                    packageValue: "Sign=WXPay",
                    nonceStr: config.nonceStr,
                    partnerId: config.partnerId,
                    paySign: config.paySign,
                    prepayId: config.prepayId,
                    timestamp: config.timestamp,
                }).then((payret) => {
                    if (payret.code == 0) {
                        paylog.info("原生充值成功", config)
                        ret.success({
                            result: {
                                errCode: 0,
                            },
                            extra: payret,
                        })
                    } else {
                        if (payret.code == UnityAppGDK.PayErrorCode.PURCHASE_CANCELLED) {
                            paylog.info("原生充值取消", payret, config)
                            ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_PAY_CANCEL))
                        } else {
                            paylog.warn("原生充值失败", payret, config)
                            ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_PAY_FAILED, {
                                data: {
                                    extra: payret
                                }
                            }))
                        }
                    }
                }, (payret) => {
                    ret.fail(payret)
                })
            }

            // 2. aliPay
            else if (options.payWay == "AliPay") {
                paylog.info("alipay_requestPay")
                SDKProxy.nativePay.alipay_requestPay({
                    sku: sku,
                    price: config.price,
                    count: 1,
                    currency: "dollar",
                    channelAppId: config.channelAppId,
                    packageValue: "AliPay",
                    nonceStr: config.nonceStr,
                    partnerId: config.partnerId,
                    paySign: config.paySign,
                    prepayId: config.prepayId,
                    timestamp: config.timestamp,
                    aliOrderInfo: config.aliOrderInfo
                }).then((payret) => {
                    if (payret.code == 0) {
                        paylog.info("原生充值成功", config)
                        ret.success({
                            result: {
                                errCode: 0,
                            },
                            extra: payret,
                        })
                    } else {
                        if (payret.code == UnityAppGDK.PayErrorCode.PURCHASE_CANCELLED) {
                            paylog.info("原生充值取消", payret, config)
                            ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_PAY_CANCEL))
                        } else {
                            paylog.warn("原生充值失败", payret, config)
                            ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_PAY_FAILED, {
                                data: {
                                    extra: payret
                                }
                            }))
                        }
                    }
                }, (payret) => {
                    ret.fail(payret)
                })
            }
            */
            return ret.promise;
        };
        /**
         * 消耗商品
         */
        Pay.prototype.consumePurchase = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, UnityAppGDK.SDKProxy.nativePay.consumePurchase(params)];
                });
            });
        };
        /**
         * 获取未消耗商品列表
         */
        Pay.prototype.queryItemInfo = function (params) {
            return __awaiter(this, void 0, void 0, function () {
                var sku, msg, ret;
                return __generator(this, function (_a) {
                    sku = params.productId;
                    if (!sku) {
                        msg = 'queryItemInfo: productId 为空， 原生app需要传入productId';
                        paylog.error(msg);
                        ret = new GDK.RPromise();
                        ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_PAY_QUERYITEMINFO_FAILED, {
                            message: msg
                        }));
                        return [2 /*return*/, ret.promise];
                    }
                    return [2 /*return*/, UnityAppGDK.SDKProxy.nativePay.queryItemInfo({ sku: params.productId, productId: params.productId })];
                });
            });
        };
        return Pay;
    }(GDK.PayBase));
    UnityAppGDK.Pay = Pay;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var RegisterList = /** @class */ (function (_super) {
        __extends(RegisterList, _super);
        function RegisterList() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.Advert = UnityAppGDK.Advert;
            _this.GameInfo = UnityAppGDK.GameInfo;
            _this.User = UnityAppGDK.User;
            _this.Pay = UnityAppGDK.Pay;
            _this.Share = UnityAppGDK.Share;
            _this.SystemInfo = UnityAppGDK.SystemInfo;
            _this.UserData = UnityAppGDK.UserData;
            _this.Customer = UnityAppGDK.Customer;
            _this.Widgets = UnityAppGDK.Widgets;
            _this.SubContext = UnityAppGDK.SubContext;
            _this.Support = UnityAppGDK.Support;
            _this.Except = UnityAppGDK.Except;
            _this.Auth = UnityAppGDK.Auth;
            _this.APISystem = UnityAppGDK.APISystem;
            _this.Log = UnityAppGDK.Log;
            _this.LocalPush = UnityAppGDK.LocalPush;
            _this.Hardware = UnityAppGDK.Hardware;
            _this.AdvertV2 = AdvertV2;
            return _this;
        }
        return RegisterList;
    }(GDK.ModuleClassMap));
    UnityAppGDK.RegisterList = RegisterList;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var devlog = UnityAppGDK.Common.devlog;
    var Share = /** @class */ (function () {
        function Share() {
        }
        Share.prototype.share = function (data) {
            return __awaiter(this, void 0, void 0, function () {
                var d, result, r;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            d = "";
                            if (data.data) {
                                d = JSON.stringify(data.data);
                            }
                            return [4 /*yield*/, this.api.showConfirm({ content: "请点击一下按钮决定是否分享成功。" + d, title: "分享测试" })];
                        case 1:
                            result = _a.sent();
                            r = new GDK.ShareResult;
                            r.isGroup = false;
                            r.result = result ? 0 : 2;
                            return [2 /*return*/, r];
                    }
                });
            });
        };
        Share.prototype.socialShare = function (data) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, this.share(data)];
                });
            });
        };
        Share.prototype.shareUrl = function (data) {
            return __awaiter(this, void 0, void 0, function () {
                var d;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.api.showAlert({ content: "分享了一个url：" + data.url, title: "分享测试" })];
                        case 1:
                            _a.sent();
                            d = new GDK.ShareResult;
                            d.result = 0;
                            return [2 /*return*/, d];
                    }
                });
            });
        };
        Share.prototype.showShareMenu = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("showShareMenu");
                    return [2 /*return*/];
                });
            });
        };
        Share.prototype.hideShareMenu = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("showShareMenu");
                    return [2 /*return*/];
                });
            });
        };
        Share.prototype.setShareMenuData = function (data) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("showShareMenu", data);
                    return [2 /*return*/];
                });
            });
        };
        Share.prototype.getShareParam = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("getShareParam");
                    return [2 /*return*/, null];
                });
            });
        };
        Share.prototype.getShareInfo = function (shareTicket) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, null];
                });
            });
        };
        Share.prototype.getShareTicket = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, ""];
                });
            });
        };
        return Share;
    }());
    UnityAppGDK.Share = Share;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var SubContext = /** @class */ (function (_super) {
        __extends(SubContext, _super);
        function SubContext() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return SubContext;
    }(GDK.SubContextBase));
    UnityAppGDK.SubContext = SubContext;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var Support = /** @class */ (function () {
        function Support() {
            this.pluginName = "app";
            this.supportShare = true;
            this.supportShareTickets = false;
            this.requireSubDomainRank = false;
            this.apiPlatform = "native";
            this.requireAuthorize = false;
            this.apiNameLocale = "原生APP";
        }
        return Support;
    }());
    UnityAppGDK.Support = Support;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var SystemInfo = /** @class */ (function (_super) {
        __extends(SystemInfo, _super);
        function SystemInfo() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.platform = "unknown";
            _this.brand = 'unknown';
            _this.model = 'unknown';
            _this.pixelRatio = -1;
            _this.screenWidth = -1;
            _this.screenHeight = -1;
            _this.windowWidth = -1;
            _this.windowHeight = -1;
            _this.statusBarHeight = -1;
            _this.language = 'zh_CN';
            _this.version = '1.0.0';
            _this.system = "browser";
            _this.fontSizeSetting = -1;
            _this.SDKVersion = '1.0.0';
            _this.benchmarkLevel = -1;
            _this.networkClass = -1;
            _this.networkType = 'unknown';
            _this.devPlatform = "browser";
            return _this;
        }
        SystemInfo.prototype.fetchNetworkInfo = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/];
                });
            });
        };
        SystemInfo.prototype.init = function () {
            if (window["gdkjsb"] == null || CS.UnityEngine.SystemInfo.deviceType == CS.UnityEngine.DeviceType.Desktop) {
                return;
            }
            this.deviceId = gdkjsb.deviceId;
            this.uuid = gdkjsb.uuid;
            this.gameDeviceId = gdkjsb.gameDeviceId;
            this.system = gdkjsb.platform + gdkjsb.systemVersion;
            this.platform = gdkjsb.platform;
            this.brand = gdkjsb.brand;
            this.model = gdkjsb.model;
            this.version = gdkjsb.systemVersion;
            this.SDKVersion = this.api.nativeVersion.toString();
            this.language = gdkjsb.language;
            this.versionCode = gdkjsb.versionCode;
            this.versionName = gdkjsb.versionName;
            this.channel = gdkjsb.channel;
            this.quickChannelId = gdkjsb.quickChannelId;
            this.country = gdkjsb.country;
            this.installTime = gdkjsb.installTime;
            this.imei = gdkjsb.imei;
            this.packageName = gdkjsb.packageName;
            this.packageTag = gdkjsb.packageTag;
            this.debugAccountServer = gdkjsb.debugAccountServer;
            this.isCustomBackendCfg = gdkjsb.isCustomBackendCfg;
            this.screenWidth = 768; //window.screen.width
            this.screenHeight = 1334; //window.screen.height
            this.androidId = gdkjsb.androidId;
            this.mac = gdkjsb.mac;
            this.userAgent = gdkjsb.userAgent;
        };
        return SystemInfo;
    }(GDK.SystemInfoBase));
    UnityAppGDK.SystemInfo = SystemInfo;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var unitNum = [null, 'K', 'M', 'B', 'T', 'aa', 'bb', 'cc', 'dd', 'ee', 'ff', 'gg', 'hh', 'ii', 'jj', 'kk', 'll', 'mm', 'nn', 'oo', 'pp', 'qq', 'rr', 'ss', 'tt', 'uu', 'vv', 'ww', 'xx', 'yy', 'zz', 'Aa', 'Bb', 'Cc', 'Dd', 'Ee', 'Ff', 'Gg', 'Hh', 'Ii', 'Jj', 'Kk', 'Ll', 'Mm', 'Nn', 'Oo', 'Pp', 'Qq', 'Rr', 'Ss', 'Tt', 'Uu', 'Vv', 'Ww', 'Xx', 'Yy', 'Zz', 'AA', 'BB', 'CC', 'DD', 'EE', 'FF', 'GG', 'HH', 'II', 'JJ', 'KK', 'LL', 'MM', 'NN', 'OO', 'PP', 'QQ', 'RR', 'SS', 'TT', 'UU', 'VV', 'WW', 'XX', 'YY', 'ZZ'];
    // const typeIndex = [null, 'goldRank', 'seedRank', 'unlockRank', 'sceneRank',]
    // const expNum = 7
    var devlog = UnityAppGDK.Common.devlog;
    var isCancelLogin = false;
    var isLoginEnd = false;
    var self;
    var isDelayLogin = false;
    var loginStartTime = 0;
    var loginRecord = null;
    var fOnAccountChange = null;
    var User = /** @class */ (function (_super) {
        __extends(User, _super);
        function User() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.loginNode = null;
            return _this;
        }
        Object.defineProperty(User.prototype, "server", {
            get: function () {
                return UnityAppGDK.MServer.inst;
            },
            enumerable: true,
            configurable: true
        });
        User.prototype.init = function (data) {
        };
        User.prototype.login = function (params) {
            if (gdkjsb.bridge.checkActionExist("loginWithBus")) {
                return this.loginWithBus(params);
            }
            else {
                return this.loginTest(params);
            }
        };
        // 登录服务器
        User.prototype.loginTest = function (params) {
            var _this = this;
            var ret = new GDK.RPromise();
            var userId = localStorage.getItem('sdk_glee_userId');
            console.log("sdk_glee_userId:" + userId);
            var nUserId = parseInt(userId);
            console.log("sdk_glee_userId3:", nUserId);
            if (isNaN(nUserId)) {
                nUserId = undefined;
            }
            console.log("sdk_glee_userId4:", nUserId);
            this.server.loginTest({ loginCode: nUserId, node: params.node }, function (resp) {
                //玩家数据
                if (resp.succeed) {
                    var data = resp.data;
                    var userdata = _this.api.userData;
                    userdata.channelId = data.channelId;
                    userdata.createTime = data.createTime;
                    userdata.userId = data.userId;
                    localStorage.setItem('sdk_glee_userId', "" + data.userId);
                    console.log("sdk_glee_userId2:" + localStorage.getItem('sdk_glee_userId'));
                    userdata.followGzh = data.followGzh;
                    userdata.nickName = data.nickname;
                    userdata.isNewUser = data.userNew;
                    _this.api.systemInfo.tableConf = resp.data.tableConf; //记录登录时传入的表格信息
                    ret.success({
                        extra: data,
                    });
                }
                else {
                    ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.UNKNOWN, {
                        data: {
                            extra: resp,
                        }
                    }));
                }
            }, function () {
                ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.NETWORK_ERROR));
            });
            return ret.promise;
        };
        User.prototype.loginWithBus = function (params) {
            params = params || {};
            var ret = new GDK.RPromise();
            var loginInfo = new ServedLoginInfo();
            loginInfo.loginNode = params.node;
            var callbacks = new TaskCallback({
                onSuccess: function (data) {
                    var loginResult = new GDK.LoginResult();
                    loginResult.extra = data.serverData;
                    console.log("loginResult: " + JSON.stringify(loginResult));
                    ret.success(loginResult);
                },
                onFailed: function (err) {
                    ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.UNKNOWN, {
                        data: {
                            extra: err,
                        }
                    }));
                },
            });
            UnityAppGDK.SDKProxy.loginWithBus(loginInfo, callbacks);
            return ret.promise;
        };
        User.prototype.showUserCenter = function () {
            return __awaiter(this, void 0, void 0, function () {
                var user;
                return __generator(this, function (_a) {
                    user = UnityAppGDK.SDKProxy.loadUserRecord()[0];
                    UnityAppGDK.SDKProxy.showUserCenter(user);
                    return [2 /*return*/];
                });
            });
        };
        User.prototype.showBindDialog = function () {
            return __awaiter(this, void 0, void 0, function () {
                var user;
                return __generator(this, function (_a) {
                    user = UnityAppGDK.SDKProxy.loadUserRecord()[0];
                    UnityAppGDK.SDKProxy.showBindDialog(user);
                    return [2 /*return*/];
                });
            });
        };
        User.prototype.update = function () {
            var ret = new GDK.RPromise();
            ret.success({});
            return ret.promise;
        };
        User.prototype._getFriendCloudStorage = function (_a) {
            var keyList = _a.keyList, success = _a.success, complete = _a.complete, fail = _a.fail;
            // let typeIndex = [null, 'goldRank', 'seedRank', 'unlockRank', 'sceneRank',]
            var info = {
                avatarUrl: "http://thirdqq.qlogo.cn/g?b=sdk&k=hX0olvhiaztn1FNkd2IibY4g&s=100&t=1483308056",
                KVDataList: [
                    {
                        key: "goldRank",
                        value: "100AA",
                    },
                    {
                        key: "seedRank",
                        value: "1000",
                    },
                    {
                        key: "unlockRank",
                        value: "199",
                    },
                    {
                        key: "sceneRank",
                        value: "324",
                    },
                ],
                nickname: "hello",
                openid: "lkjlkwjlk",
            };
            var res = {
                data: []
            };
            for (var i = 0; i < 10; i++) {
                var newinfo = __assign({}, info);
                newinfo.openid += i;
                res.data.push(newinfo);
            }
            var ___unused = success && success(res);
            ___unused = complete && complete();
        };
        User.prototype._setUserCloudStorage = function (obj) {
            devlog.info('-[UserCloudStorage] 提交用户成绩', obj.KVDataList);
            var typeIndex = obj.typeIndex;
            var commitTime = 0; //this.getTime()
            var data = {
                userData: [
                    {
                        openId: '',
                        startMs: '' + 0,
                        endMs: '' + commitTime,
                        scoreInfo: {
                            score: 0,
                        },
                    },
                ],
                attr: {
                    score: {
                        type: 'rank',
                        order: 1,
                    }
                },
            };
            var selfScoreInfo = data.userData[0].scoreInfo;
            var attr = data.attr;
            for (var _i = 0, _a = obj.KVDataList; _i < _a.length; _i++) {
                var item = _a[_i];
                var ss = item.value;
                var unitA = ss.match(/[a-zA-Z]+/);
                if (unitA)
                    unitA = unitA[0];
                var numA = parseFloat(ss);
                var expA = unitNum.indexOf(unitA);
                var intA = Math.floor(numA * 1000);
                var intS = Math.pow(10, 9) * expA + intA;
                var keyIndex = typeIndex.indexOf(item.key);
                if (keyIndex <= 0) {
                    devlog.info("-[UserCloudStorage] \u4E0D\u6B63\u786E\u7684keyIndex: " + keyIndex + " " + item.key);
                }
                else {
                    var orderKey = 'a' + keyIndex;
                    selfScoreInfo[orderKey] = intS;
                    attr[orderKey] = {
                        type: item.key,
                        order: 1,
                    };
                }
            }
            devlog.info('-[UserCloudStorage] 提交用户成绩数据: ' + JSON.stringify(data));
        };
        User.prototype.getFriendCloudStorage = function (obj) {
            var ret = new GDK.RPromise();
            this._getFriendCloudStorage({
                keyList: obj.keyList,
                typeIndex: obj.typeIndex,
                success: function (res) {
                    ret.success(res);
                },
                fail: function () {
                    ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_GET_FRIEND_CLOUD_STORAGE_FAILED));
                }
            });
            return ret.promise;
        };
        User.prototype.setUserCloudStorage = function (obj) {
            var ret = new GDK.RPromise();
            this._setUserCloudStorage({
                KVDataList: obj.KVDataList, success: function () {
                    ret.success(undefined);
                },
                typeIndex: obj.typeIndex,
                fail: function () {
                    ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_SET_USER_CLOUD_STORAGE_FAILED));
                }
            });
            return ret.promise;
        };
        /**
         * 判断userId对应的用户是否绑定过社交账号
         * @param userId 登录时服务器返回的userId
         */
        User.prototype.checkIsUserBind = function (userId) {
            var users = UnityAppGDK.SDKProxy.loadUserRecord().where(function (u) { return u.userId == userId; });
            return users.length > 0 && !!users.find(function (user) { return user.loginType != "silent" && user.loginType != "visitor"; });
        };
        User.prototype.setAccountChangeListener = function (f) {
            fOnAccountChange = f;
        };
        return User;
    }(GDK.UserBase));
    UnityAppGDK.User = User;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var UserData = /** @class */ (function () {
        function UserData() {
        }
        Object.defineProperty(UserData.prototype, "openId", {
            get: function () {
                return '0999999';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(UserData.prototype, "gameId", {
            get: function () {
                return -1;
            },
            enumerable: true,
            configurable: true
        });
        return UserData;
    }());
    UnityAppGDK.UserData = UserData;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var devlog = UnityAppGDK.Common.devlog;
    var KeyBoard = /** @class */ (function () {
        function KeyBoard() {
        }
        KeyBoard.prototype.hideKeyboard = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("hideKeyboard");
                    return [2 /*return*/];
                });
            });
        };
        return KeyBoard;
    }());
    var Widgets = /** @class */ (function () {
        function Widgets() {
            this.keyboard = new KeyBoard();
        }
        Widgets.prototype.init = function (data) {
            var _this = this;
            setTimeout(function () {
                _this.api.hideLaunchingView();
            });
        };
        Widgets.prototype.showLoading = function (object) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("showLoading");
                    return [2 /*return*/];
                });
            });
        };
        Widgets.prototype.hideLoading = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("hideLoading");
                    return [2 /*return*/];
                });
            });
        };
        Widgets.prototype.showToast = function (object) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("showToast");
                    return [2 /*return*/];
                });
            });
        };
        Widgets.prototype.hideToast = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    devlog.info("hideToast");
                    return [2 /*return*/];
                });
            });
        };
        Widgets.prototype.showConfirm = function (object) {
            return new Promise(function (resolve, reject) {
                gdkjsb.showConfirm(object.content, object.title || slib.i18n.locSDKString("remind_tip"), object.okLabel || slib.i18n.locSDKString("ok"), object.cancelLabel || slib.i18n.locSDKString("cancel"), function (isOk) {
                    var r = new GDK.ShowConfirmResult();
                    r.confirm = isOk == true;
                    r.cancel = isOk == false;
                    resolve(r);
                });
            });
        };
        Widgets.prototype.showAlert = function (object) {
            return new Promise(function (resolve, reject) {
                gdkjsb.showAlert(object.content, object.title || slib.i18n.locSDKString("remind_tip"), object.okLabel || slib.i18n.locSDKString("ok"), function () {
                    var r = new GDK.ShowAlertResult();
                    resolve(r);
                });
            });
        };
        Widgets.prototype.showPrompt = function (object) {
            return new Promise(function (resolve, reject) {
                if (gdkjsb.showPrompt == null) {
                    var r = new GDK.ShowPromptResult();
                    r.cancel = true;
                    r.confirm = false;
                    r.result = null;
                    resolve(r);
                    return;
                }
                gdkjsb.showPrompt(object.content, object.title || slib.i18n.locSDKString("remind_tip"), object.okLabel || slib.i18n.locSDKString("ok"), object.cancelLabel || slib.i18n.locSDKString("cancel"), function (isOk, result) {
                    var r = new GDK.ShowPromptResult();
                    r.confirm = isOk == true;
                    r.cancel = isOk == false;
                    r.result = result;
                    resolve(r);
                }, object.defaultValue || "");
            });
        };
        Widgets.prototype.hideLaunchingView = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    UnityAppGDK.SDKProxy.hideLaunchingView();
                    return [2 /*return*/];
                });
            });
        };
        return Widgets;
    }());
    UnityAppGDK.Widgets = Widgets;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    // default config
    GDK.gdkManager.registPluginConfig('app', {
        platform: 'app',
        version: '1.0.0',
        register: UnityAppGDK.RegisterList,
    });
})(UnityAppGDK || (UnityAppGDK = {}));
/// <reference path="../Common.ts" />
var UnityAppGDK;
(function (UnityAppGDK) {
    var devlog = UnityAppGDK.Common.devlog;
    var BannerAd = /** @class */ (function () {
        function BannerAd(params) {
            var _this = this;
            this._style = new GDK.BannerStyleAccessor();
            this._loadFuncList = [];
            this._errorFuncList = [];
            this._resizeFuncList = [];
            UnityAppGDK.SDKProxy.nativeAdvert.createBanner(params);
            UnityAppGDK.SDKProxy.nativeAdvert.setBannerListener();
            UnityAppGDK.SDKProxy.nativeAdvert.loadBanner(params);
            this.style.x = params.style.x;
            this.style.y = params.style.y;
            this.style.left = params.style.left;
            this.style.top = params.style.top;
            UnityAppGDK.SDKProxy.nativeAdvert.onBannerAdLoaded(function () {
                _this.onBannerAdLoaded();
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onBannerAdLoadFailed(function (error) {
                _this.onBannerAdLoadFailed(error);
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onBannerAdLoadFailed(function (error) {
                _this.onBannerAdLoadFailed(error);
            });
        }
        Object.defineProperty(BannerAd.prototype, "style", {
            get: function () {
                return this._style;
            },
            set: function (value) {
                this._style = value;
                UnityAppGDK.SDKProxy.nativeAdvert.setBannerStyle(value);
            },
            enumerable: true,
            configurable: true
        });
        BannerAd.prototype.reset = function (params) {
            this.destroy();
            UnityAppGDK.SDKProxy.nativeAdvert.createBanner(params);
            UnityAppGDK.SDKProxy.nativeAdvert.loadBanner(params);
            this.style.x = params.style.x;
            this.style.y = params.style.y;
            this.style.left = params.style.left;
            this.style.top = params.style.top;
        };
        BannerAd.prototype.onBannerAdLoaded = function () {
            for (var _i = 0, _a = this._loadFuncList.concat(); _i < _a.length; _i++) {
                var f = _a[_i];
                try {
                    f();
                }
                catch (e) {
                    devlog.error('条幅广告加载成功回调异常', e);
                }
            }
        };
        BannerAd.prototype.onBannerAdLoadFailed = function (error) {
            var err = new GDK.RewardedVideoAdOnErrorParam();
            err.errCode = error.errorCode;
            err.errMsg = error.errorMsg;
            for (var _i = 0, _a = this._errorFuncList.concat(); _i < _a.length; _i++) {
                var f = _a[_i];
                f(err);
            }
        };
        BannerAd.prototype.show = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.setBannerAdvertVisibility({ visible: true })];
                        case 1:
                            _a.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        BannerAd.prototype.hide = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.setBannerAdvertVisibility({ visible: false })];
                        case 1:
                            _a.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        BannerAd.prototype.destroy = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.destroyBanner()];
                        case 1:
                            _a.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        BannerAd.prototype.onResize = function (callback) {
            this._resizeFuncList.push(callback);
        };
        BannerAd.prototype.offResize = function (callback) {
            this._resizeFuncList.splice(this._resizeFuncList.indexOf(callback), 1);
        };
        BannerAd.prototype.onLoad = function (callback) {
            this._loadFuncList.push(callback);
        };
        BannerAd.prototype.offLoad = function (callback) {
            this._loadFuncList.splice(this._loadFuncList.indexOf(callback), 1);
        };
        BannerAd.prototype.onError = function (callback) {
            this._errorFuncList.push(callback);
        };
        BannerAd.prototype.offError = function (callback) {
            this._errorFuncList.splice(this._errorFuncList.indexOf(callback), 1);
        };
        return BannerAd;
    }());
    UnityAppGDK.BannerAd = BannerAd;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var devlog = UnityAppGDK.Common.devlog;
    var FeedAd = /** @class */ (function () {
        function FeedAd(params) {
            this._style = new GDK.FeedAdStyleAccessor();
            this.adObjectId = -1;
            this.isDebugMode = false;
            this.isDebugMode = params.isDebugMode;
            var style = params.style;
            if (style != null) {
                this.style.x = style.x;
                this.style.y = style.y;
                this.style.left = style.left;
                this.style.top = style.top;
            }
            FeedAd._initListeners();
        }
        FeedAd._initListeners = function () {
            var _this = this;
            if (this._inited) {
                return;
            }
            this._inited = true;
            UnityAppGDK.SDKProxy.nativeAdvert.onFeedAdLoaded(function (params) {
                _this._onFeedAdLoadedCallbacks.concat().forEach(function (f) {
                    try {
                        f(params);
                    }
                    catch (e) {
                        console.error(e);
                    }
                });
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onFeedAdLoadFailed(function (params) {
                _this._onFeedAdLoadFailedCallbacks.concat().forEach(function (f) {
                    try {
                        f(params);
                    }
                    catch (e) {
                        console.error(e);
                    }
                });
            });
        };
        FeedAd.prototype.onFeedAdLoaded = function (f) {
            var callbacks = FeedAd._onFeedAdLoadedCallbacks;
            var index = callbacks.indexOf(f);
            if (f && index <= 0) {
                callbacks.push(f);
            }
        };
        FeedAd.prototype.offFeedAdLoaded = function (f) {
            var callbacks = FeedAd._onFeedAdLoadedCallbacks;
            var index = callbacks.indexOf(f);
            if (index >= 0) {
                callbacks.splice(index, 1);
            }
        };
        FeedAd.prototype.onFeedAdLoadFailed = function (f) {
            var callbacks = FeedAd._onFeedAdLoadFailedCallbacks;
            var index = callbacks.indexOf(f);
            if (f && index <= 0) {
                callbacks.push(f);
            }
        };
        FeedAd.prototype.offFeedAdLoadFailed = function (f) {
            var callbacks = FeedAd._onFeedAdLoadFailedCallbacks;
            var index = callbacks.indexOf(f);
            if (index >= 0) {
                callbacks.splice(index, 1);
            }
        };
        Object.defineProperty(FeedAd.prototype, "style", {
            get: function () {
                return this._style;
            },
            set: function (value) {
                this._style = value;
                UnityAppGDK.SDKProxy.nativeAdvert.setFeedAdStyle({ adObjectId: this.adObjectId, style: this._style });
            },
            enumerable: true,
            configurable: true
        });
        FeedAd.prototype.setStyle = function (style) {
            return __awaiter(this, void 0, void 0, function () {
                var key, value, datas;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            for (key in style) {
                                value = style[key];
                                if (value != null) {
                                    this._style[key] = value;
                                }
                            }
                            return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.setFeedAdStyle({ adObjectId: this.adObjectId, style: this._style })];
                        case 1:
                            _a.sent();
                            return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.getFeedAdDatas({ adObjectId: this.adObjectId })];
                        case 2:
                            datas = _a.sent();
                            this._style.realHeight = datas.style.realHeight;
                            this._style.realWidth = datas.style.realWidth;
                            return [2 /*return*/];
                    }
                });
            });
        };
        FeedAd.prototype.setDefaultClickZoneStyle = function (style) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.setFeedAdClickZoneStyle({ adObjectId: this.adObjectId, style: style })];
                        case 1:
                            _a.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        FeedAd.prototype.load = function () {
            return __awaiter(this, void 0, void 0, function () {
                var adObjectId, onLoadPromise, datas;
                var _this = this;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.createFeedAd({ style: this.style, isDebugMode: this.isDebugMode })];
                        case 1:
                            adObjectId = (_a.sent()).adObjectId;
                            this.adObjectId = adObjectId;
                            onLoadPromise = new Promise(function (resolve, reject) {
                                var _onFeedAdLoadedCallback = function (params) {
                                    _this.offFeedAdLoaded(_onFeedAdLoadedCallback);
                                    if (_this.adObjectId == params.adObjectId) {
                                        resolve();
                                    }
                                };
                                var _onFeedAdLoadFailedCallback = function (params) {
                                    _this.offFeedAdLoadFailed(_onFeedAdLoadFailedCallback);
                                    if (_this.adObjectId == params.adObjectId) {
                                        reject(new Error(params.error.errorMsg));
                                    }
                                };
                                _this.onFeedAdLoaded(_onFeedAdLoadedCallback);
                                _this.onFeedAdLoadFailed(_onFeedAdLoadFailedCallback);
                            });
                            return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.loadFeedAd({ adObjectId: adObjectId })];
                        case 2:
                            _a.sent();
                            return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.setFeedAdStyle({ adObjectId: adObjectId, style: this._style })];
                        case 3:
                            _a.sent();
                            return [4 /*yield*/, onLoadPromise];
                        case 4:
                            _a.sent();
                            return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.getFeedAdDatas({ adObjectId: this.adObjectId })];
                        case 5:
                            datas = _a.sent();
                            this._style.realHeight = datas.style.realHeight;
                            this._style.realWidth = datas.style.realWidth;
                            return [2 /*return*/];
                    }
                });
            });
        };
        FeedAd.prototype.show = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.setFeedAdVisibility({ adObjectId: this.adObjectId, visible: true })];
                        case 1:
                            _a.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        FeedAd.prototype.hide = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.setFeedAdVisibility({ adObjectId: this.adObjectId, visible: false })];
                        case 1:
                            _a.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        FeedAd.prototype.destroy = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.destroyFeedAd({ adObjectId: this.adObjectId })];
                        case 1: return [2 /*return*/, _a.sent()];
                    }
                });
            });
        };
        FeedAd.prototype.getDatas = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.getFeedAdDatas({ adObjectId: this.adObjectId })];
                        case 1: return [2 /*return*/, _a.sent()];
                    }
                });
            });
        };
        /**
         * 模拟点击广告
         */
        FeedAd.prototype.performClick = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.performClick({ adObjectId: this.adObjectId })];
                        case 1: return [2 /*return*/, _a.sent()];
                    }
                });
            });
        };
        /**
         * 模拟点击广告
         */
        FeedAd.prototype.performCreativeClick = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.performCreativeClick({ adObjectId: this.adObjectId })];
                        case 1: return [2 /*return*/, _a.sent()];
                    }
                });
            });
        };
        FeedAd._onFeedAdLoadedCallbacks = [];
        FeedAd._onFeedAdLoadFailedCallbacks = [];
        FeedAd._inited = false;
        return FeedAd;
    }());
    UnityAppGDK.FeedAd = FeedAd;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var devlog = UnityAppGDK.Common.devlog;
    var FullscreenVedioAd = /** @class */ (function () {
        function FullscreenVedioAd(params, api) {
            var _this = this;
            this._loadFuncList = [];
            this._errorFuncList = [];
            this._closeFuncList = [];
            this._isLoad = false;
            this._isShowing = false;
            this._isEnded = false;
            this._onLoadedCallbacks = [];
            this._available = false;
            this.adUnitId = params.adUnitId;
            this.api = api;
            UnityAppGDK.SDKProxy.nativeAdvert.onFullScreenVideoAvailabilityChanged(function (data) {
                _this.onFullScreenVideoAvailabilityChanged(data.available);
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onFullScreenVideoAdComplete(function (data) {
                _this.onFullScreenVideoAdComplete();
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onFullScreenVideoAdClosed(function (data) {
                // 避免可能的黑屏
                setTimeout(function () {
                    _this.onFullScreenVideoAdClosed(data);
                }, 0);
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onFullScreenVideoAdShowFailed(function (error) {
                _this.onFullScreenVideoAdShowFailed(error);
            });
        }
        FullscreenVedioAd.prototype.onFullScreenVideoAdShowFailed = function (error) {
            this._isShowing = false;
            var err = new GDK.FullscreenAdOnErrorParam();
            err.errCode = error.errorCode || error["code"];
            err.errMsg = error.errorMsg || error["message"]; //有的平台没有按正确的格式上传信息
            for (var _i = 0, _a = this._errorFuncList.concat(); _i < _a.length; _i++) {
                var f = _a[_i];
                f(err);
            }
        };
        FullscreenVedioAd.prototype.onFullScreenVideoAdComplete = function () {
            this._isEnded = true;
        };
        FullscreenVedioAd.prototype.onFullScreenVideoAdClosed = function (data) {
            var _this = this;
            data = data || {};
            this._isShowing = false;
            var isEnded = this._isEnded;
            this._isEnded = false;
            // 如果有直接的参数，优先使用参数
            if (data.couldReward != null) {
                isEnded = !!data.couldReward;
            }
            for (var _i = 0, _a = this._closeFuncList.concat(); _i < _a.length; _i++) {
                var f = _a[_i];
                try {
                    f({ isEnded: isEnded });
                }
                catch (e) {
                    devlog.error('视频广告发放奖励回调异常：', e);
                }
            }
            setTimeout(function () { return __awaiter(_this, void 0, void 0, function () {
                var available;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.isFullScreenVideoAvailable()];
                        case 1:
                            available = (_a.sent()).available;
                            this.onFullScreenVideoAvailabilityChanged(available);
                            return [2 /*return*/];
                    }
                });
            }); }, 0);
        };
        Object.defineProperty(FullscreenVedioAd.prototype, "isAvailable", {
            get: function () {
                return this._available;
            },
            enumerable: true,
            configurable: true
        });
        FullscreenVedioAd.prototype.checkAvailable = function () {
            return __awaiter(this, void 0, void 0, function () {
                var available;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.isFullScreenVideoAvailable()];
                        case 1:
                            available = (_a.sent()).available;
                            this._available = available;
                            return [2 /*return*/, available];
                    }
                });
            });
        };
        FullscreenVedioAd.prototype.onFullScreenVideoAvailabilityChanged = function (available) {
            this._available = available;
            if (available) {
                // load() promise 回调
                var onLoadedCallbacks = this._onLoadedCallbacks;
                // 清空避免重复 promise
                this._onLoadedCallbacks = [];
                for (var _i = 0, _a = onLoadedCallbacks.concat(); _i < _a.length; _i++) {
                    var f = _a[_i];
                    try {
                        f();
                    }
                    catch (e) {
                        devlog.error('广告已加载 promise 回调异常：', e);
                    }
                }
                try {
                    // onLoaded 回调
                    for (var _b = 0, _c = this._loadFuncList.concat(); _b < _c.length; _b++) {
                        var f = _c[_b];
                        f();
                    }
                }
                catch (e) {
                    devlog.error('广告 onLoad 回调中发生异常:', e);
                }
            }
        };
        FullscreenVedioAd.prototype.load = function () {
            return __awaiter(this, void 0, void 0, function () {
                var ret, available;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            ret = new GDK.RPromise();
                            return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.isFullScreenVideoAvailable()];
                        case 1:
                            available = (_a.sent()).available;
                            this._available = available;
                            if (!this._available) return [3 /*break*/, 2];
                            ret.success(undefined);
                            // 和微信一致，每次 load 都调用 onLoad
                            this.onFullScreenVideoAvailabilityChanged(this._available);
                            return [3 /*break*/, 4];
                        case 2:
                            this._onLoadedCallbacks.push(function () {
                                ret.success(undefined);
                            });
                            return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.loadFullScreenVideoAd()];
                        case 3:
                            _a.sent();
                            _a.label = 4;
                        case 4: return [2 /*return*/, ret.promise];
                    }
                });
            });
        };
        FullscreenVedioAd.prototype.show = function () {
            return __awaiter(this, void 0, void 0, function () {
                var waitting, ret;
                return __generator(this, function (_a) {
                    devlog.info('ironsrc:show video advert');
                    this._isShowing = true;
                    waitting = true;
                    ret = new GDK.RPromise();
                    // 5秒没有播出来，那么就报超时错误
                    setTimeout(function () {
                        if (!waitting) {
                            return;
                        }
                        waitting = false;
                        ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_SHOW_ADVERT_TIMEOUT));
                    }, 5000);
                    UnityAppGDK.SDKProxy.nativeAdvert.showFullScreenVideo({ placementName: "DefaultFullScreenVideo" }).then(function () {
                        if (!waitting) {
                            return;
                        }
                        waitting = false;
                        ret.success();
                    }).catch(function (e) {
                        if (!waitting) {
                            return;
                        }
                        waitting = false;
                        ret.fail(e);
                    });
                    return [2 /*return*/, ret.promise];
                });
            });
        };
        FullscreenVedioAd.prototype.onLoad = function (callback) {
            this._loadFuncList.push(callback);
        };
        FullscreenVedioAd.prototype.offLoad = function (callback) {
            this._loadFuncList.splice(this._loadFuncList.indexOf(callback), 1);
        };
        FullscreenVedioAd.prototype.onError = function (callback) {
            this._errorFuncList.push(callback);
        };
        FullscreenVedioAd.prototype.offError = function (callback) {
            this._errorFuncList.splice(this._errorFuncList.indexOf(callback), 1);
        };
        FullscreenVedioAd.prototype.onClose = function (callback) {
            this._closeFuncList.push(callback);
        };
        FullscreenVedioAd.prototype.offClose = function (callback) {
            this._closeFuncList.splice(this._closeFuncList.indexOf(callback), 1);
        };
        return FullscreenVedioAd;
    }());
    UnityAppGDK.FullscreenVedioAd = FullscreenVedioAd;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var devlog = UnityAppGDK.Common.devlog;
    var InterstitialAd = /** @class */ (function () {
        function InterstitialAd(params, api) {
            var _this = this;
            this._loadFuncList = [];
            this._errorFuncList = [];
            this._closeFuncList = [];
            this._isLoad = false;
            this._isShowing = false;
            this._isEnded = false;
            this._onLoadedCallbacks = [];
            this._available = false;
            this._onShownCallbacks = [];
            this.adUnitId = params.adUnitId;
            this.api = api;
            UnityAppGDK.SDKProxy.nativeAdvert.onInterstitialAdReady(function () {
                _this.onInterstitialAvailabilityChanged(true);
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onInterstitialAdLoadFailed(function (error) {
                _this.onInterstitialAdLoadFailed(error);
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onInterstitialAdRewarded(function (data) {
                _this.onInterstitialAdRewarded();
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onInterstitialAdClosed(function () {
                // 避免可能的黑屏
                setTimeout(function () {
                    _this.onInterstitialAdClosed();
                }, 0);
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onInterstitialAdOpened(function () {
                _this.onInterstitialAdOpened();
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onInterstitialAdShowFailed(function (error) {
                _this.onInterstitialAdShowFailed(error);
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onInterstitialAdShowSucceeded(function () {
                _this.onInterstitialAdShowSucceeded();
            });
        }
        InterstitialAd.prototype.onReceivedError = function (error) {
            var err = new GDK.InterstitialAdOnErrorParam();
            err.errCode = error.errorCode;
            err.errMsg = error.errorMsg;
            for (var _i = 0, _a = this._errorFuncList.concat(); _i < _a.length; _i++) {
                var f = _a[_i];
                try {
                    f(err);
                }
                catch (e) {
                    devlog.error('广告错误处理回调异常：', e);
                }
            }
        };
        InterstitialAd.prototype.onInterstitialAdRewarded = function () {
            this._isEnded = true;
        };
        InterstitialAd.prototype.onInterstitialAdClosed = function () {
            var _this = this;
            this._isShowing = false;
            var isEnded = this._isEnded;
            this._isEnded = false;
            for (var _i = 0, _a = this._closeFuncList.concat(); _i < _a.length; _i++) {
                var f = _a[_i];
                try {
                    f({ isEnded: isEnded });
                }
                catch (e) {
                    devlog.error('视频广告发放奖励回调异常：', e);
                }
            }
            setTimeout(function () { return __awaiter(_this, void 0, void 0, function () {
                var available;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.isInterstitialReady()];
                        case 1:
                            available = (_a.sent()).available;
                            this.onInterstitialAvailabilityChanged(available);
                            return [2 /*return*/];
                    }
                });
            }); }, 0);
        };
        InterstitialAd.prototype.onInterstitialAvailabilityChanged = function (available) {
            this._available = available;
            if (available) {
                // load() promise 回调
                var onLoadedCallbacks = this._onLoadedCallbacks;
                this._onLoadedCallbacks = [];
                for (var _i = 0, _a = onLoadedCallbacks.concat(); _i < _a.length; _i++) {
                    var f = _a[_i];
                    try {
                        f();
                    }
                    catch (e) {
                        devlog.error('广告已加载回调异常：', e);
                    }
                }
                // onLoaded 回调
                for (var _b = 0, _c = this._loadFuncList.concat(); _b < _c.length; _b++) {
                    var f = _c[_b];
                    f();
                }
            }
        };
        InterstitialAd.prototype.onInterstitialAdLoadFailed = function (error) {
            this.onInterstitialAvailabilityChanged(false);
            this.onReceivedError(error);
        };
        InterstitialAd.prototype.load = function () {
            return __awaiter(this, void 0, void 0, function () {
                var ret, available;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            devlog.info('ironsrc:load Interstitial video advert');
                            ret = new GDK.RPromise();
                            return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.isInterstitialReady()];
                        case 1:
                            available = (_a.sent()).available;
                            this._available = available;
                            if (!this._available) return [3 /*break*/, 2];
                            ret.success(undefined);
                            return [3 /*break*/, 4];
                        case 2: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.loadInterstitial()];
                        case 3:
                            _a.sent();
                            this._onLoadedCallbacks.push(function () {
                                ret.success(undefined);
                            });
                            _a.label = 4;
                        case 4: return [2 /*return*/, ret.promise];
                    }
                });
            });
        };
        InterstitialAd.prototype.onInterstitialAdOpened = function () {
        };
        InterstitialAd.prototype.onInterstitialAdShowSucceeded = function () {
            var onShownCallbacks = this._onShownCallbacks;
            this._onShownCallbacks = [];
            for (var _i = 0, _a = onShownCallbacks.concat(); _i < _a.length; _i++) {
                var ret = _a[_i];
                try {
                    ret.success();
                }
                catch (e) {
                    devlog.error('广告播放成功回调异常：', e);
                }
            }
        };
        InterstitialAd.prototype.onInterstitialAdShowFailed = function (error) {
            this._isShowing = false;
            var onShownCallbacks = this._onShownCallbacks;
            this._onShownCallbacks = [];
            for (var _i = 0, _a = onShownCallbacks.concat(); _i < _a.length; _i++) {
                var ret = _a[_i];
                try {
                    ret.fail(error);
                }
                catch (e) {
                    devlog.error('广告播放失败回调异常：', e);
                }
            }
            this.onReceivedError(error);
        };
        InterstitialAd.prototype.show = function () {
            return __awaiter(this, void 0, void 0, function () {
                var ret;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            devlog.info('ironsrc:show Interstitial video advert');
                            this._isShowing = true;
                            ret = new GDK.RPromise();
                            return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.showInterstitial({ placementName: "DefaultInterstitial" })];
                        case 1:
                            _a.sent();
                            this._onShownCallbacks.push(ret);
                            return [2 /*return*/, ret.promise];
                    }
                });
            });
        };
        InterstitialAd.prototype.onLoad = function (callback) {
            this._loadFuncList.push(callback);
        };
        InterstitialAd.prototype.offLoad = function (callback) {
            this._loadFuncList.splice(this._loadFuncList.indexOf(callback), 1);
        };
        InterstitialAd.prototype.onError = function (callback) {
            this._errorFuncList.push(callback);
        };
        InterstitialAd.prototype.offError = function (callback) {
            this._errorFuncList.splice(this._errorFuncList.indexOf(callback), 1);
        };
        InterstitialAd.prototype.onClose = function (callback) {
            this._closeFuncList.push(callback);
        };
        InterstitialAd.prototype.offClose = function (callback) {
            this._closeFuncList.splice(this._closeFuncList.indexOf(callback), 1);
        };
        return InterstitialAd;
    }());
    UnityAppGDK.InterstitialAd = InterstitialAd;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var devlog = UnityAppGDK.Common.devlog;
    var VideoAd = /** @class */ (function () {
        function VideoAd(params, api) {
            var _this = this;
            this._loadFuncList = [];
            this._errorFuncList = [];
            this._closeFuncList = [];
            this._isLoad = false;
            this._isShowing = false;
            this._isEnded = false;
            this._onLoadedCallbacks = [];
            this._available = false;
            /**
             * 原生平台广告位
             */
            this.placementId = null;
            this.adUnitId = params.adUnitId;
            this.api = api;
            UnityAppGDK.SDKProxy.nativeAdvert.onRewardedVideoAvailabilityChanged(function (data) {
                _this.onRewardedVideoAvailabilityChanged(data.available);
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onRewardedVideoAdRewarded(function (data) {
                _this.onRewardedVideoAdRewarded();
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onRewardedVideoAdClosed(function (data) {
                // 避免可能的黑屏
                setTimeout(function () {
                    _this.onRewardedVideoAdClosed(data);
                }, 0);
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onRewardedVideoAdOpened(function () {
                _this.onRewardedVideoAdOpened();
            });
            UnityAppGDK.SDKProxy.nativeAdvert.onRewardedVideoAdShowFailed(function (error) {
                _this.onRewardedVideoAdShowFailed(error);
            });
        }
        VideoAd.prototype.onRewardedVideoAdOpened = function () {
        };
        VideoAd.prototype.onRewardedVideoAdShowFailed = function (error) {
            this._isShowing = false;
            var err = new GDK.RewardedVideoAdOnErrorParam();
            err.errCode = error.errorCode;
            err.errMsg = error.errorMsg;
            for (var _i = 0, _a = this._errorFuncList.concat(); _i < _a.length; _i++) {
                var f = _a[_i];
                f(err);
            }
            this.onApplyLoadedCallbacks(false);
        };
        VideoAd.prototype.onApplyLoadedCallbacks = function (isOk) {
            // load() promise 回调
            var onLoadedCallbacks = this._onLoadedCallbacks;
            // 清空避免重复 promise
            this._onLoadedCallbacks = [];
            for (var _i = 0, _a = onLoadedCallbacks.concat(); _i < _a.length; _i++) {
                var f = _a[_i];
                try {
                    f(isOk);
                }
                catch (e) {
                    if (isOk) {
                        devlog.error('广告已加载 promise 回调异常：', e);
                    }
                    else {
                        devlog.error('广告加载失败 promise 回调异常：', e);
                    }
                }
            }
        };
        VideoAd.prototype.onRewardedVideoAdRewarded = function () {
            this._isEnded = true;
        };
        VideoAd.prototype.onRewardedVideoAdClosed = function (data) {
            var _this = this;
            data = data || {};
            this._isShowing = false;
            var isEnded = this._isEnded;
            this._isEnded = false;
            // 如果有直接的参数，优先使用参数
            if (data.couldReward != null) {
                isEnded = !!data.couldReward;
            }
            for (var _i = 0, _a = this._closeFuncList.concat(); _i < _a.length; _i++) {
                var f = _a[_i];
                try {
                    f({ isEnded: isEnded });
                }
                catch (e) {
                    devlog.error('视频广告发放奖励回调异常：', e);
                }
            }
            setTimeout(function () { return __awaiter(_this, void 0, void 0, function () {
                var available;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.isRewardedVideoAvailable()];
                        case 1:
                            available = (_a.sent()).available;
                            this.onRewardedVideoAvailabilityChanged(available);
                            return [2 /*return*/];
                    }
                });
            }); }, 0);
        };
        Object.defineProperty(VideoAd.prototype, "isAvailable", {
            /**
             * 获知视频广告是否加载成功
             */
            get: function () {
                return this._available;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * 调用异步原生接口获取`原生`视频广告是否加载成功
         */
        VideoAd.prototype.checkAvailable = function (loadParams) {
            return __awaiter(this, void 0, void 0, function () {
                var available;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.isRewardedVideoAvailable(loadParams)];
                        case 1:
                            available = (_a.sent()).available;
                            this._available = available;
                            return [2 /*return*/, available];
                    }
                });
            });
        };
        VideoAd.prototype.onRewardedVideoAvailabilityChanged = function (available) {
            this._available = available;
            if (available) {
                // // load() promise 回调
                // let onLoadedCallbacks = this._onLoadedCallbacks
                // // 清空避免重复 promise
                // this._onLoadedCallbacks = []
                // for (let f of onLoadedCallbacks.concat()) {
                // 	try {
                // 		f(true)
                // 	} catch (e) {
                // 		devlog.error('广告已加载 promise 回调异常：', e)
                // 	}
                // }
                this.onApplyLoadedCallbacks(true);
                try {
                    // onLoaded 回调
                    for (var _i = 0, _a = this._loadFuncList.concat(); _i < _a.length; _i++) {
                        var f = _a[_i];
                        f();
                    }
                }
                catch (e) {
                    devlog.error('广告 onLoad 回调中发生异常:', e);
                }
            }
        };
        VideoAd.prototype.load = function (loadParams) {
            return __awaiter(this, void 0, void 0, function () {
                var ret, isLoading, available;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            loadParams = loadParams || {};
                            loadParams.placementId = loadParams.placementId || this.adUnitId;
                            ret = new GDK.RPromise();
                            isLoading = false;
                            if (!(this.placementId != loadParams.placementId)) return [3 /*break*/, 2];
                            this.placementId = loadParams.placementId;
                            isLoading = true;
                            return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.loadRewardVideoAd(loadParams)];
                        case 1:
                            _a.sent();
                            _a.label = 2;
                        case 2: return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.isRewardedVideoAvailable()];
                        case 3:
                            available = (_a.sent()).available;
                            this._available = available;
                            if (!this._available) return [3 /*break*/, 4];
                            ret.success(undefined);
                            // 和微信一致，每次 load 都调用 onLoad
                            this.onRewardedVideoAvailabilityChanged(this._available);
                            return [3 /*break*/, 6];
                        case 4:
                            this._onLoadedCallbacks.push(function (isOk) {
                                if (isOk) {
                                    ret.success(undefined);
                                }
                                else {
                                    ret.fail(undefined);
                                }
                            });
                            if (!!isLoading) return [3 /*break*/, 6];
                            return [4 /*yield*/, UnityAppGDK.SDKProxy.nativeAdvert.loadRewardVideoAd(loadParams)];
                        case 5:
                            _a.sent();
                            _a.label = 6;
                        case 6: return [2 /*return*/, ret.promise];
                    }
                });
            });
        };
        VideoAd.prototype.show = function (loadParams) {
            return __awaiter(this, void 0, void 0, function () {
                var waitting, ret;
                return __generator(this, function (_a) {
                    devlog.info('ironsrc:show video advert');
                    this._isShowing = true;
                    waitting = true;
                    ret = new GDK.RPromise();
                    // 5秒没有播出来，那么就报超时错误
                    setTimeout(function () {
                        if (!waitting) {
                            return;
                        }
                        waitting = false;
                        ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_SHOW_ADVERT_TIMEOUT));
                    }, 5000);
                    UnityAppGDK.SDKProxy.nativeAdvert.showRewardedVideo({ placementName: loadParams ? loadParams.placementId : "DefaultRewardedVideo" }).then(function () {
                        if (!waitting) {
                            return;
                        }
                        waitting = false;
                        ret.success();
                    }).catch(function (e) {
                        if (!waitting) {
                            return;
                        }
                        waitting = false;
                        ret.fail(e);
                    });
                    return [2 /*return*/, ret.promise];
                });
            });
        };
        VideoAd.prototype.onLoad = function (callback) {
            if (this._loadFuncList.indexOf(callback) >= 0) {
                return;
            }
            this._loadFuncList.push(callback);
        };
        VideoAd.prototype.offLoad = function (callback) {
            var index = this._loadFuncList.indexOf(callback);
            if (index < 0) {
                return;
            }
            this._loadFuncList.splice(index, 1);
        };
        VideoAd.prototype.onError = function (callback) {
            if (this._errorFuncList.indexOf(callback) >= 0) {
                return;
            }
            this._errorFuncList.push(callback);
        };
        VideoAd.prototype.offError = function (callback) {
            var index = this._errorFuncList.indexOf(callback);
            if (index < 0) {
                return;
            }
            this._errorFuncList.splice(index, 1);
        };
        VideoAd.prototype.onClose = function (callback) {
            if (this._closeFuncList.indexOf(callback) >= 0) {
                return;
            }
            this._closeFuncList.push(callback);
        };
        VideoAd.prototype.offClose = function (callback) {
            var index = this._closeFuncList.indexOf(callback);
            if (index < 0) {
                return;
            }
            this._closeFuncList.splice(index, 1);
        };
        return VideoAd;
    }());
    UnityAppGDK.VideoAd = VideoAd;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var devlog = UnityAppGDK.Common.devlog;
    var AdvertUnit = /** @class */ (function () {
        function AdvertUnit(params) {
            var createInfo = new AdCreateInfo();
            createInfo.advertType = params.advertType;
            createInfo.appId = params.appId;
            createInfo.placementId = params.placementId;
            createInfo.isDebug = params.isDebug;
            this.adUnitRaw = new UnityAppGDK.AdvertUnitRaw(createInfo);
        }
        AdvertUnit.prototype.load = function () {
            var ret = new GDK.RPromise();
            this.adUnitRaw.load(new TaskCallback({
                onSuccess: function (p) {
                    ret.success(undefined);
                },
                onFailed: function (e) {
                    ret.fail(new ErrorInfo(e));
                },
            }));
            return ret.promise;
        };
        AdvertUnit.prototype.show = function () {
            var ret = new GDK.RPromise();
            this.adUnitRaw.show(new TaskCallback({
                onSuccess: function (p) {
                    ret.success(p);
                },
                onFailed: function (e) {
                    ret.fail(new ErrorInfo(e));
                },
            }));
            return ret.promise;
        };
        Object.defineProperty(AdvertUnit.prototype, "isReady", {
            get: function () {
                return this.adUnitRaw.isReady;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(AdvertUnit.prototype, "isAlive", {
            get: function () {
                return this.adUnitRaw.isAlive;
            },
            enumerable: true,
            configurable: true
        });
        AdvertUnit.prototype.destroy = function () {
            this.adUnitRaw.destroy();
        };
        return AdvertUnit;
    }());
    UnityAppGDK.AdvertUnit = AdvertUnit;
})(UnityAppGDK || (UnityAppGDK = {}));
var UnityAppGDK;
(function (UnityAppGDK) {
    var devlog = UnityAppGDK.Common.devlog;
    var AdvertUnitRaw = /** @class */ (function () {
        function AdvertUnitRaw(params) {
            var _this = this;
            this.nativeUnitInfo = new AdUnitQueryInfo();
            this.getAddon().CreateAdUnit(params, new TaskCallback({
                onSuccess: function (p) {
                    _this.nativeUnitInfo = p.info;
                },
                onFailed: function (e) {
                    console.error("创建广告单元失败:", JSON.stringify(e));
                }
            }));
        }
        AdvertUnitRaw.prototype.getAddon = function () {
            if (this._nativeAdvert != null) {
                return this._nativeAdvert;
            }
            this._nativeAdvert = CS.ujlib.PluginManager.GetInstance().GetPlugin("bus").advert;
            return this._nativeAdvert;
        };
        AdvertUnitRaw.isAdvertTypeSupported = function (advertType) {
            return CS.ujlib.PluginManager.GetInstance().GetPlugin("bus").advert.IsAdvertTypeSupported(advertType);
        };
        AdvertUnitRaw.prototype.load = function (callbacks) {
            this.getAddon().LoadAdUnit(new AdUnitOpInfo(this.nativeUnitInfo, new ShowAdUnitOpInfo()), callbacks);
        };
        AdvertUnitRaw.prototype.show = function (callbacks) {
            this.getAddon().ShowAdUnit(new AdUnitOpInfo(this.nativeUnitInfo, new ShowAdUnitOpInfo()), callbacks);
        };
        Object.defineProperty(AdvertUnitRaw.prototype, "isReady", {
            get: function () {
                return this.getAddon().IsAdUnitReady(new AdUnitOpInfo(this.nativeUnitInfo, new ShowAdUnitOpInfo()));
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(AdvertUnitRaw.prototype, "isAlive", {
            get: function () {
                return this.getAddon().IsAdUnitAlive(new AdUnitOpInfo(this.nativeUnitInfo, new ShowAdUnitOpInfo()));
            },
            enumerable: true,
            configurable: true
        });
        AdvertUnitRaw.prototype.destroy = function () {
            this.getAddon().DestroyAdUnit(new AdUnitOpInfo(this.nativeUnitInfo, new ShowAdUnitOpInfo()), new TaskCallback({
                onSuccess: function (p) {
                },
                onFailed: function (e) {
                    console.error("destory advert unit failed: " + e);
                }
            }));
        };
        return AdvertUnitRaw;
    }());
    UnityAppGDK.AdvertUnitRaw = AdvertUnitRaw;
})(UnityAppGDK || (UnityAppGDK = {}));
var AppGDK;
(function (AppGDK) {
    var AnyParams = /** @class */ (function () {
        function AnyParams() {
        }
        AnyParams.defaultValue = new AnyParams();
        return AnyParams;
    }());
    AppGDK.AnyParams = AnyParams;
    var AnyResult = /** @class */ (function () {
        function AnyResult() {
        }
        AnyResult.defaultValue = new AnyResult();
        return AnyResult;
    }());
    AppGDK.AnyResult = AnyResult;
    var ErrorInfo = /** @class */ (function () {
        function ErrorInfo(err) {
            this.message = "";
            this.reason = "ERROR_UNKNOWN";
            this.code = -1;
            this.message = err.message;
            this.reason = err.reason;
            this.code = err.code;
        }
        return ErrorInfo;
    }());
    AppGDK.ErrorInfo = ErrorInfo;
    var TaskCallback = /** @class */ (function () {
        function TaskCallback(cs) {
            this.onSuccess = cs.onSuccess;
            this.onFailed = cs.onFailed;
            this.onCancel = cs.onCancel;
        }
        return TaskCallback;
    }());
    AppGDK.TaskCallback = TaskCallback;
    var FTaskCallback = /** @class */ (function () {
        function FTaskCallback(cs) {
            this.onSuccess = cs.onSuccess;
            this.onFailed = cs.onFailed;
            this.onCancel = cs.onCancel;
        }
        return FTaskCallback;
    }());
    AppGDK.FTaskCallback = FTaskCallback;
    var EmptyTaskCallback = /** @class */ (function (_super) {
        __extends(EmptyTaskCallback, _super);
        function EmptyTaskCallback() {
            return _super.call(this, new TaskCallback({
                onSuccess: function () { },
                onFailed: function () { },
            })) || this;
        }
        return EmptyTaskCallback;
    }(TaskCallback));
    AppGDK.EmptyTaskCallback = EmptyTaskCallback;
})(AppGDK || (AppGDK = {}));
var AppGDK;
(function (AppGDK) {
    var ServedLoginInfo = /** @class */ (function () {
        function ServedLoginInfo() {
        }
        return ServedLoginInfo;
    }());
    AppGDK.ServedLoginInfo = ServedLoginInfo;
    var LoginServerResult = /** @class */ (function () {
        function LoginServerResult() {
        }
        return LoginServerResult;
    }());
    AppGDK.LoginServerResult = LoginServerResult;
    var ServerData = /** @class */ (function () {
        function ServerData() {
        }
        return ServerData;
    }());
    AppGDK.ServerData = ServerData;
    var GameCurrency = /** @class */ (function () {
        function GameCurrency() {
        }
        return GameCurrency;
    }());
    AppGDK.GameCurrency = GameCurrency;
    var TableConf = /** @class */ (function () {
        function TableConf() {
        }
        return TableConf;
    }());
    AppGDK.TableConf = TableConf;
    var VerifiedInfo = /** @class */ (function () {
        function VerifiedInfo() {
        }
        return VerifiedInfo;
    }());
    AppGDK.VerifiedInfo = VerifiedInfo;
    var RecordData = /** @class */ (function () {
        function RecordData() {
        }
        return RecordData;
    }());
    AppGDK.RecordData = RecordData;
    var ServedBindInfo = /** @class */ (function () {
        function ServedBindInfo() {
        }
        return ServedBindInfo;
    }());
    AppGDK.ServedBindInfo = ServedBindInfo;
    var AdvertPreloadInfo = /** @class */ (function () {
        function AdvertPreloadInfo() {
        }
        return AdvertPreloadInfo;
    }());
    AppGDK.AdvertPreloadInfo = AdvertPreloadInfo;
    var AdvertType = /** @class */ (function () {
        function AdvertType() {
        }
        return AdvertType;
    }());
    AppGDK.AdvertType = AdvertType;
    var AdPlatformConfigs = /** @class */ (function () {
        function AdPlatformConfigs() {
        }
        return AdPlatformConfigs;
    }());
    AppGDK.AdPlatformConfigs = AdPlatformConfigs;
    var AdCreateInfo = /** @class */ (function () {
        function AdCreateInfo() {
        }
        return AdCreateInfo;
    }());
    AppGDK.AdCreateInfo = AdCreateInfo;
    var CreateAdUnitResult = /** @class */ (function () {
        function CreateAdUnitResult() {
        }
        return CreateAdUnitResult;
    }());
    AppGDK.CreateAdUnitResult = CreateAdUnitResult;
    var AdUnitQueryInfo = /** @class */ (function () {
        function AdUnitQueryInfo() {
        }
        return AdUnitQueryInfo;
    }());
    AppGDK.AdUnitQueryInfo = AdUnitQueryInfo;
    var AdUnitOpInfo = /** @class */ (function () {
        function AdUnitOpInfo(queryInfo, opInfo) {
            this.queryInfo = queryInfo;
            this.opInfo = opInfo;
        }
        return AdUnitOpInfo;
    }());
    AppGDK.AdUnitOpInfo = AdUnitOpInfo;
    var ShowAdUnitOpInfo = /** @class */ (function () {
        function ShowAdUnitOpInfo() {
        }
        return ShowAdUnitOpInfo;
    }());
    AppGDK.ShowAdUnitOpInfo = ShowAdUnitOpInfo;
    var ShowAdUnityResult = /** @class */ (function () {
        function ShowAdUnityResult() {
        }
        return ShowAdUnityResult;
    }());
    AppGDK.ShowAdUnityResult = ShowAdUnityResult;
    var SetAdUnitStyleInfo = /** @class */ (function () {
        function SetAdUnitStyleInfo() {
        }
        return SetAdUnitStyleInfo;
    }());
    AppGDK.SetAdUnitStyleInfo = SetAdUnitStyleInfo;
    var AdUnitStyle = /** @class */ (function () {
        function AdUnitStyle() {
        }
        return AdUnitStyle;
    }());
    AppGDK.AdUnitStyle = AdUnitStyle;
    var AdUnitStatus = /** @class */ (function () {
        function AdUnitStatus() {
        }
        return AdUnitStatus;
    }());
    AppGDK.AdUnitStatus = AdUnitStatus;
    var AdUnitInfo = /** @class */ (function () {
        function AdUnitInfo() {
        }
        return AdUnitInfo;
    }());
    AppGDK.AdUnitInfo = AdUnitInfo;
    var AdvertEvent = /** @class */ (function () {
        function AdvertEvent() {
        }
        return AdvertEvent;
    }());
    AppGDK.AdvertEvent = AdvertEvent;
})(AppGDK || (AppGDK = {}));
//# sourceMappingURL=unityapp.lua.map
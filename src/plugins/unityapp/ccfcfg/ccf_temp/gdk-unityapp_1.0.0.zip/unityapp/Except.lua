local Except
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ = (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    Except = (function(super)
        local Except = declareClass("Except", super)

        function Except.prototype:setErrorCallback(callback)
            self._errorCallback = callback

            if not self._isListener then
                self._isListener = true

            -- window.onerror = (res) => {
            -- 	--检查该错误是否提交过
            -- 	this._errorCallback({ message: res.toString(), stack: new Error().stack });
            -- }
            end
        end
        function Except.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self._errorCallback = nil
            self._isListener = false

            --constructor logic
        end

        return Except
    end)(GDK.IExcept)
    UnityAppGDK.Except = Except

    UnityAppGDK.Except = Except
end)(UnityAppGDK)

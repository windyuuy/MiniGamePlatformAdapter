local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    -- default config
    GDK.gdkManager:registPluginConfig(
        "app",
        {
            platform = "app",
            version = "1.0.0",
            register = RegisterList
        }
    )
end)(UnityAppGDK)

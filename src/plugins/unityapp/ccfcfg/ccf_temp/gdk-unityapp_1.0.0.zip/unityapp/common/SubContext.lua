local SimpleEvent
local OpenDataContext
local SubContextBase

local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    SimpleEvent = (function(super)
        local SimpleEvent = declareClass("SimpleEvent", super)
        function SimpleEvent.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return SimpleEvent
    end)(slib.SimpleEvent)

    OpenDataContext = (function(super)
        local OpenDataContext = declareClass("OpenDataContext", super)

        function OpenDataContext.prototype:constructor(event)
            --member properties
            self._event = nil

            --constructor parameters

            --constructor logic

            self._event = event
        end

        function OpenDataContext.prototype:postMessage(message)
            self._event:emit(message)
        end

        return OpenDataContext
    end)(IOpenDataContext)

    SubContextBase = (function(super)
        local SubContextBase = declareClass("SubContextBase", super)

        function SubContextBase.prototype:onMessage(callback)
            return self._event:on(callback)
        end

        function SubContextBase.prototype:getOpenDataContext()
            return self._context
        end
        function SubContextBase.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self._event = SimpleEvent()
            self._context = OpenDataContext(self._event)

            --constructor logic
        end

        return SubContextBase
    end)(ISubContext)
    GDK.SubContextBase = SubContextBase

    GDK.SubContextBase = SubContextBase
end)(GDK)

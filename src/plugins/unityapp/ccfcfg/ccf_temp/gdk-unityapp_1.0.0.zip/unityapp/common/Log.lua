local LogBase
local GDK = GDK or {}
_G.GDK = GDK
local _ =
    (function(GDK)
    extendsNSList({GDK, _G})

    LogBase =
        (function(super)
        local LogBase = declareClass("LogBase", super)

        LogBase.prototype.commitLog =
            __JS_Async(
            function(self, key, params)
            end
        )

        LogBase.prototype.commitChannelsLog =
            __JS_Async(
            function(self, logType, params)
            end
        )

        LogBase.prototype.commitPayLog =
            __JS_Async(
            function(self, index)
            end
        )
        function LogBase.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return LogBase
    end)(ILog)
    GDK.LogBase = LogBase

    GDK.LogBase = LogBase
end)(GDK)

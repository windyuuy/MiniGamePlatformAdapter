local  Clipboard
local  APISystemBase

local GDK=GDK or {};_G.GDK=GDK;local _=(function (GDK)
extendsNSList({GDK,_G})
 
	 local devlog =  slib.Log({ tags = Array({'DEVELOP'})})

	 Clipboard = (function(super)
        local Clipboard = declareClass('Clipboard', super);
    
		 Clipboard.prototype.getData = __JS_Async(function(self) 
			return {<INVALID>}
     end)
    
		 Clipboard.prototype.setData = __JS_Async(function(self, res) 
			self._data = {<INVALID>}
     end)
    function Clipboard.prototype:constructor()
        if super and super.prototype then super.prototype.constructor(self) end

    --member properties
    self._data = nil


    --constructor logic
    
end

        return Clipboard
    end)( IClipboard)

	 APISystemBase = (function(super)
        local APISystemBase = declareClass('APISystemBase', super);
    

		function APISystemBase.prototype:init() 
			self:_initEvents()
     end
         function APISystemBase.prototype:__getter__nativeVersion() 
			return -1
     end
    

		 APISystemBase.prototype.setEnableDebug = __JS_Async(function(self, res) 
			devlog:info([==[unsupoort action: setEnableDebug -> ]==]..tostring(res.enableDebug)..[==[ ]==])
     end)
    

		 APISystemBase.prototype.navigateToApp = __JS_Async(function(self, params) 
			devlog:info('打开小程序成功')
			return nil
     end)
    
		 APISystemBase.prototype.exitProgram = __JS_Async(function(self) 
			devlog:info('正在退出')
			window:close()
     end)
    
		 APISystemBase.prototype.updateProgramForce = __JS_Async(function(self) 
			devlog:info('没有更新')
     end)
    

		function APISystemBase.prototype:_initEvents() 
			 local win = window
       local hiddenPropName
			if __JS_TypeOf(document.hidden) ~= 'undefined' then 
				hiddenPropName = 'hidden'
			elseif __JS_TypeOf(document['mozHidden']) ~= 'undefined' then 
				hiddenPropName = 'mozHidden'
			elseif __JS_TypeOf(document['msHidden']) ~= 'undefined' then 
				hiddenPropName = 'msHidden'
			elseif __JS_TypeOf(document['webkitHidden']) ~= 'undefined' then 
				hiddenPropName = 'webkitHidden'
			end
			 local hidden = false
			 local onHidden = function() 
				if not hidden then 
					hidden = true
					-- game.emit(game.EVENT_HIDE);
					self._onHideEvent:emit(nil)
				end
			end
			 local onShown = function() 
				if hidden then 
					hidden = false
					-- game.emit(game.EVENT_SHOW);
					self._onShowEvent:emit({})
				end
			end
			if hiddenPropName then 
				 local changeList = Array({
					'visibilitychange',
					'mozvisibilitychange',
					'msvisibilitychange',
					'webkitvisibilitychange',
					'qbrowserVisibilityChange'})
				 local i = 0
       while  i < changeList.length do  
					document:addEventListener(changeList[i],  function(event) 
						 local visible = document[hiddenPropName]
						if visible == nil then 
							visible = event['hidden']
						end
						devlog:info('hidden:',  visible)
						if visible then
							onHidden()else 
							onShown() end
					end)
           i=i+1;
       end
			else  
				win:addEventListener('blur',  onHidden)
				win:addEventListener('focus',  onShown)
			end
			if navigator.userAgent:indexOf('MicroMessenger') > -1 then 
				win.onfocus = onShown
			end
			if 'onpageshow'<INVALID> window and  'onpagehide'<INVALID> window then 
				win:addEventListener('pagehide',  onHidden)
				win:addEventListener('pageshow',  onShown)
				document:addEventListener('pagehide',  onHidden)
				document:addEventListener('pageshow',  onShown)
			end
     end
    
		function APISystemBase.prototype:onShow(callback) 
			self._onShowEvent:on(callback)
     end
    
		function APISystemBase.prototype:offShow(callback) 
			self._onShowEvent:off(callback)
     end
    
		function APISystemBase.prototype:onHide(callback) 
			self._onHideEvent:on(callback)
     end
    
		function APISystemBase.prototype:offHide(callback) 
			self._onHideEvent:off(callback)
     end
    

		function APISystemBase.prototype:getSafeArea(callback) 
			callback({ left = 0, right = 0, top = 0, bottom = 0})
     end
    

		 APISystemBase.prototype.gotoAppSystemSettings = __JS_Async(function(self, params) 
			return {
				action = 'cancel',
				crashed = false}
     end)
    
		 APISystemBase.prototype.checkAppSystemPermissions = __JS_Async(function(self, params) 
			return {
				lackedPermissions = Array({}),
				error = {}}
     end)
    function APISystemBase.prototype:constructor()
        if super and super.prototype then super.prototype.constructor(self) end

    --member properties
    self.clipboard =   Clipboard()
    self._onShowEvent =   slib.SimpleEvent()
    self._onHideEvent =   slib.SimpleEvent()


    --constructor logic
    
end

        return APISystemBase
    end)( IAPISystem)
    GDK.APISystemBase = APISystemBase

    GDK.APISystemBase=APISystemBase
end)(GDK)
local SystemInfoBase

local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    SystemInfoBase = (function(super)
        local SystemInfoBase = declareClass("SystemInfoBase", super)

        function SystemInfoBase.prototype:fetchNetworkInfo()
        end

        function SystemInfoBase.prototype:clone()
            local obj = {}
            for k, _ in pairs(self) do
                obj[k] = self[k]
            end
            obj["uiLanguage"] = slib.i18n.language
            obj.api = nil
            return obj
        end
        function SystemInfoBase.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.platform = "devtools"
            self.brand = "unknown"
            self.model = "unknown"
            self.pixelRatio = -1
            self.screenWidth = -1
            self.screenHeight = -1
            self.windowWidth = -1
            self.windowHeight = -1
            self.statusBarHeight = -1
            self.language = "zh_CN"
            self.version = "1.0.0"
            self.system = "devtools"
            self.fontSizeSetting = -1
            self.SDKVersion = "1.0.0"
            self.benchmarkLevel = -1
            self.networkClass = -1
            self.networkType = "unknown"
            self.isFirstInstall = nil
            self.devPlatform = "devtools"
            self.deviceId = nil
            self.uuid = nil
            self.gameDeviceId = nil
            self.versionCode = nil
            self.versionName = nil
            self.channel = nil
            self.quickChannelId = nil
            self.country = nil
            self.installTime = nil
            self.imei = nil
            self.packageName = nil
            self.packageTag = nil
            self.debugAccountServer = nil
            self.isCustomBackendCfg = nil

            --constructor logic
        end

        return SystemInfoBase
    end)(ISystemInfo)
    GDK.SystemInfoBase = SystemInfoBase

    GDK.SystemInfoBase = SystemInfoBase
end)(GDK)

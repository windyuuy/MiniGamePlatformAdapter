local PayBase

local GDK = GDK or {}
_G.GDK = GDK
local _ =
    (function(GDK)
    extendsNSList({GDK, _G})

    PayBase =
        (function(super)
        local PayBase = declareClass("PayBase", super)

        function PayBase.prototype:payPurchase(item, options)
        end

        function PayBase.prototype:consumePurchase(params)
            return Promise(
                function(resolve, reject)
                    reject(GDK.GDKResultTemplates:make(GDK.GDKErrorCode.API_INVALID))
                end
            )
        end

        function PayBase.prototype:queryItemInfo(params)
            return Promise(
                function(resolve, reject)
                    reject(GDK.GDKResultTemplates:make(GDK.GDKErrorCode.API_INVALID))
                end
            )
        end
        function PayBase.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return PayBase
    end)(IPay)
    GDK.PayBase = PayBase

    GDK.PayBase = PayBase
end)(GDK)

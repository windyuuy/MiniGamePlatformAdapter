local Vibration
local Performance
local HardwareBase

local GDK = GDK or {}
_G.GDK = GDK
local _ =
    (function(GDK)
    extendsNSList({GDK, _G})

    local devlog = slib.Log({tags = Array({"DEVELOP"})})
    Vibration =
        (function(super)
        local Vibration = declareClass("Vibration", super)

        Vibration.prototype.vibrateLong =
            __JS_Async(
            function(self)
                devlog:info("vibrateLong")
            end
        )

        Vibration.prototype.vibrateShort =
            __JS_Async(
            function(self)
                devlog:info("vibrateShort")
            end
        )

        Vibration.prototype.vibrate =
            __JS_Async(
            function(self, params)
                devlog:info("vibrate", params)
            end
        )
        function Vibration.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return Vibration
    end)(IVibration)
    Performance = (function(super)
        local Performance = declareClass("Performance", super)

        function Performance.prototype:getMicroTime()
            return Date():getTime() * 1000
        end

        function Performance.prototype:tryGC()
            devlog:info("tryGC")
        end

        function Performance.prototype:onMemoryWarning(callback)
            devlog:info("register onMemoryWarning")
        end
        function Performance.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return Performance
    end)(IPerformance)

    HardwareBase = (function(super)
        local HardwareBase = declareClass("HardwareBase", super)
        function HardwareBase.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.vibration = Vibration()
            self.performance = Performance()

            --constructor logic
        end

        return HardwareBase
    end)(IHardware)
    GDK.HardwareBase = HardwareBase

    GDK.HardwareBase = HardwareBase
end)(GDK)

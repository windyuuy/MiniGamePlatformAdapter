local UserBase

local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    UserBase = (function(super)
        local UserBase = declareClass("UserBase", super)

        function UserBase.prototype:login(params)
        end

        function UserBase.prototype:setBindCallback(callback)
            self.bindCallback = callback
        end

        function UserBase.prototype:setRebootCallback(callback)
            self.rebootCallback = callback
        end

        function UserBase.prototype:showUserCenter()
        end

        function UserBase.prototype:showBindDialog()
        end

        function UserBase.prototype:checkSession(params)
            local ret = RPromise()
            ret:success(nil)
            return ret.promise
        end

        function UserBase.prototype:update()
        end

        function UserBase.prototype:getFriendCloudStorage(obj)
        end

        function UserBase.prototype:setUserCloudStorage(obj)
        end

        function UserBase.prototype:checkIsUserBind(userId)
        end
        function UserBase.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.bindCallback = nil
            self.rebootCallback = nil

            --constructor logic
        end

        return UserBase
    end)(IUser)
    GDK.UserBase = UserBase

    GDK.UserBase = UserBase
end)(GDK)

local GameInfoBase

local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    GameInfoBase = (function(super)
        local GameInfoBase = declareClass("GameInfoBase", super)

        function GameInfoBase.prototype:init()
        end

        function GameInfoBase.prototype:initWithConfig(info)
        end
        function GameInfoBase.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.mode = nil
            self.appId = nil
            self.gameChannelId = nil
            self.isPayInSandbox = nil
            self.offerId = nil
            self.shareProxyUrl = nil
            self.launchOptions = nil
            self.gameVersion = nil
            self.gameId = nil
            self.gameType = nil
            self.requireCustomServicePay = false
            self.requireMiniAppPay = false
            self.requireIndiaSPSPay = false

            --constructor logic
        end

        return GameInfoBase
    end)(IGameInfo)
    GDK.GameInfoBase = GameInfoBase

    GDK.GameInfoBase = GameInfoBase
end)(GDK)

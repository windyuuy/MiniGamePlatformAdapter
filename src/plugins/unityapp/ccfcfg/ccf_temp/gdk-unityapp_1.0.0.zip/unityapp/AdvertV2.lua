local AdvertV2
--/ <reference path="Common.ts" />
local AppGDK = AppGDK or {}
_G.AppGDK = AppGDK
local _ =
    (function(AppGDK)
    extendsNSList({AppGDK, _G})

    local devlog = Common.devlog

    AdvertV2 =
        (function(super)
        local AdvertV2 = declareClass("AdvertV2", super)

        AdvertV2.prototype.createAdvertUnit =
            __JS_Async(
            function(self, createInfo)
                local adUnit = AdvertUnit(createInfo)
                return adUnit
            end
        )

        function AdvertV2.prototype:isAdvertTypeSupported(advertType)
            return AdvertUnitRaw:isAdvertTypeSupported(advertType)
        end
        function AdvertV2.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.api = nil

            --constructor logic
        end

        return AdvertV2
    end)(GDK.IAdvertV2)
    AppGDK.AdvertV2 = AdvertV2

    AppGDK.AdvertV2 = AdvertV2
end)(AppGDK)

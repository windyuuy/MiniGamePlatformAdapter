local Advert
--/ <reference path="Common.ts" />
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local devlog = Common.devlog

    Advert =
        (function(super)
        local Advert = declareClass("Advert", super)

        Advert.prototype.initWithConfig =
            __JS_Async(
            function(self, _info)
                local info = _info --as GDK.GDKAPPConfig

                info.app.advertPlatforms = info.app.advertPlatforms or Array({})
                if info.app.advertPlatforms.length == 0 then
                    info.app.advertPlatform = info.app.advertPlatform or "ironsource"
                end
                if info.app.advertPlatform then
                    info.app.advertPlatforms:remove(info.app.advertPlatform)
                    info.app.advertPlatforms:push(info.app.advertPlatform)
                end
                do
                    local ___temp = info.app.advertPlatforms
                    for ___i = 0, ___temp.length - 1 do
                        local key = ___temp[___i]

                        -- 选择广告平台
                        __JS_Await(SDKProxy.nativeAdvert:advertPlatformSelect(key))

                        __JS_Await(SDKProxy.nativeAdvert:setRewardedVideoListener())
                        if self.supportInterstitialAd then
                            __JS_Await(SDKProxy.nativeAdvert:setInterstitialListener())
                        end
                        __JS_Await(
                            SDKProxy.nativeAdvert:init(
                                {
                                    appKey = "ironsrcappkey",
                                    modules = {
                                        REWARDED_VIDEO = true,
                                        BANNER = true,
                                        INTERSTITIAL = self.supportInterstitialAd
                                    }
                                }
                            )
                        )
                        local debug = false
                        SDKProxy.nativeAdvert:setAdaptersDebug({debug = debug})
                        SDKProxy.nativeAdvert:shouldTrackNetworkState({track = debug})
                    end
                end
            end
        )

        function Advert.prototype:createRewardedVideoAd(params)
            if not Advert._videoAd then
                -- if (this.supportInterstitialAd) {
                -- 	Advert._videoAd = new InterstitialAd(params, this.api)
                -- } else {
                Advert._videoAd = VideoAd(params, self.api)
            -- }
            end
            return Advert._videoAd
        end
        function Advert.prototype:__getter__supportFullscreenAd()
            return self.supportFullscreenVideoAd
        end
        function Advert.prototype:__getter__supportFullscreenVideoAd()
            return nativeHelper:checkActionExist("ironsrc:IronSource.showFullScreenVideo")
        end

        function Advert.prototype:createFullscreenVideoAd(params)
            if not Advert._fullscreenAd then
                if self.supportFullscreenVideoAd then
                    Advert._fullscreenAd = FullscreenVedioAd(params, self.api)
                else
                    -- Advert._fullscreenAd = new VideoAd(params, this.api)
                    devlog:error("当前app版本过低，不支持插屏广告(Interstitial)")
                end
            end
            return Advert._fullscreenAd
        end
        function Advert.prototype:__getter__supportInterstitialAd()
            return nativeHelper:checkActionExist("ironsrc:IronSource.showInterstitial")
        end

        function Advert.prototype:createInterstitialAd(params)
            if not Advert._interstitialAd then
                if self.supportInterstitialAd then
                    Advert._interstitialAd = InterstitialAd(params, self.api)
                else
                    -- Advert._interstitialAd = new VideoAd(params, this.api)
                    devlog:error("当前app版本过低，不支持插屏广告(Interstitial)")
                end
            end
            return Advert._interstitialAd
        end

        function Advert.prototype:createBannerAd(params)
            if not Advert._bannerAd then
                Advert._bannerAd = BannerAd(params)
            else
                Advert._bannerAd:reset(params)
            end
            return Advert._bannerAd
        end
        function Advert.prototype:__getter__supportFeedAd()
            return gdkjsb.country == "CN" and nativeHelper:checkActionExist("ironsrc:IronSource.createFeedAd")
        end

        function Advert.prototype:createFeedAd(params)
            return FeedAd(params)
        end

        Advert.prototype.selectAdvertPlatform =
            __JS_Async(
            function(self, params)
                local ret = __JS_Await(SDKProxy.nativeAdvert:advertPlatformSelect(params.platform or "ironsource"))
                local videoAd = Advert._videoAd
                if videoAd ~= nil and __JS_InstanceOf(videoAd, VideoAd) then
                    (function(___temp)
                        return ___temp["onRewardedVideoAvailabilityChanged"](
                            ___temp,
                            __JS_Await(videoAd:checkAvailable())
                        )
                    end)(videoAd)
                end
                return ret
            end
        )

        Advert.prototype.initMultAdSlot =
            __JS_Async(
            function(self, params)
                local ret = __JS_Await(SDKProxy.nativeAdvert:initMultAdSlot(params))
                return ret
            end
        )

        Advert.prototype.initAdService =
            __JS_Async(
            function(self, params)
                return Promise(
                    function(resolve, reject)
                        resolve()
                    end
                )
            end
        )
        function Advert.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.api = nil

            --constructor logic
        end

        return Advert
    end)(GDK.IAdvert)

    Advert._videoAd = nil

    Advert._interstitialAd = nil

    Advert._fullscreenAd = nil

    Advert._bannerAd = nil

    UnityAppGDK.Advert = Advert

    UnityAppGDK.Advert = Advert
end)(UnityAppGDK)

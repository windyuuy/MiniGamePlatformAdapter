local AdvertUnitRaw
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local devlog = Common.devlog

    AdvertUnitRaw =
        (function(super)
        local AdvertUnitRaw = declareClass("AdvertUnitRaw", super)

        function AdvertUnitRaw.prototype:getAddon()
            if self._nativeAdvert ~= nil then
                return self._nativeAdvert
            end
            self._nativeAdvert = CS.ujlib.PluginManager:GetInstance():GetPlugin("bus").advert
            return self._nativeAdvert
        end

        function AdvertUnitRaw.prototype:constructor(params)
            --member properties
            self._nativeAdvert = nil
            self.nativeUnitInfo = AdUnitQueryInfo()

            --constructor parameters

            --constructor logic

            self:getAddon():CreateAdUnit(
                params,
                TaskCallback(
                    {
                        onSuccess = function(p)
                            self.nativeUnitInfo = p.info
                        end,
                        onFailed = function(e)
                            console:error("创建广告单元失败:", JSON:stringify(e))
                        end
                    }
                )
            )
        end

        function AdvertUnitRaw:isAdvertTypeSupported(advertType)
            return CS.ujlib.PluginManager:GetInstance():GetPlugin("bus").advert:IsAdvertTypeSupported(advertType)
        end

        function AdvertUnitRaw.prototype:load(callbacks)
            self:getAddon():LoadAdUnit(AdUnitOpInfo(self.nativeUnitInfo, ShowAdUnitOpInfo()), callbacks)
        end

        function AdvertUnitRaw.prototype:show(callbacks)
            self:getAddon():ShowAdUnit(AdUnitOpInfo(self.nativeUnitInfo, ShowAdUnitOpInfo()), callbacks)
        end
        function AdvertUnitRaw.prototype:__getter__isReady()
            return self:getAddon():IsAdUnitReady(AdUnitOpInfo(self.nativeUnitInfo, ShowAdUnitOpInfo()))
        end
        function AdvertUnitRaw.prototype:__getter__isAlive()
            return self:getAddon():IsAdUnitAlive(AdUnitOpInfo(self.nativeUnitInfo, ShowAdUnitOpInfo()))
        end

        function AdvertUnitRaw.prototype:destroy()
            self:getAddon():DestroyAdUnit(
                AdUnitOpInfo(self.nativeUnitInfo, ShowAdUnitOpInfo()),
                TaskCallback(
                    {
                        onSuccess = function(p)
                        end,
                        onFailed = function(e)
                            console:error("destory advert unit failed: " .. e)
                        end
                    }
                )
            )
        end

        return AdvertUnitRaw
    end)()
    UnityAppGDK.AdvertUnitRaw = AdvertUnitRaw

    UnityAppGDK.AdvertUnitRaw = AdvertUnitRaw
end)(UnityAppGDK)

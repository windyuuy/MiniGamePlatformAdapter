local AdvertUnit
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local devlog = Common.devlog

    AdvertUnit =
        (function(super)
        local AdvertUnit = declareClass("AdvertUnit", super)

        function AdvertUnit.prototype:constructor(params)
            --member properties
            self.adUnitRaw = nil

            --constructor parameters

            --constructor logic

            local createInfo = AdCreateInfo()
            createInfo.advertType = params.advertType
            createInfo.appId = params.appId
            createInfo.placementId = params.placementId
            createInfo.isDebug = params.isDebug
            self.adUnitRaw = AdvertUnitRaw(createInfo)
        end

        function AdvertUnit.prototype:load()
            local ret = GDK.RPromise()

            self.adUnitRaw:load(
                TaskCallback(
                    {
                        onSuccess = function(p)
                            ret:success(nil)
                        end,
                        onFailed = function(e)
                            ret:fail(ErrorInfo(e))
                        end
                    }
                )
            )

            return ret.promise
        end

        function AdvertUnit.prototype:show()
            local ret = GDK.RPromise()

            self.adUnitRaw:show(
                TaskCallback(
                    {
                        onSuccess = function(p)
                            ret:success(p)
                        end,
                        onFailed = function(e)
                            ret:fail(ErrorInfo(e))
                        end
                    }
                )
            )

            return ret.promise
        end
        function AdvertUnit.prototype:__getter__isReady()
            return self.adUnitRaw.isReady
        end
        function AdvertUnit.prototype:__getter__isAlive()
            return self.adUnitRaw.isAlive
        end

        function AdvertUnit.prototype:destroy()
            self.adUnitRaw:destroy()
        end

        return AdvertUnit
    end)(GDK.IAdvertUnit)
    UnityAppGDK.AdvertUnit = AdvertUnit

    UnityAppGDK.AdvertUnit = AdvertUnit
end)(UnityAppGDK)

local LocalPush

local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local devlog = Common.devlog

    LocalPush =
        (function(super)
        local LocalPush = declareClass("LocalPush", super)

        function LocalPush.prototype:init()
            SDKProxy.nativeLocalPush:init()
        end

        --[[
		 * 添加本地推送
		--]]
        LocalPush.prototype.addLocalNotices =
            __JS_Async(
            function(self, params)
                return SDKProxy.nativeLocalPush:addLocalNotices(params)
            end
        )

        --[[
		 * 移除对应的推送
		--]]
        LocalPush.prototype.removeLocalNoticeWithID =
            __JS_Async(
            function(self, params)
                return SDKProxy.nativeLocalPush:removeLocalNoticeWithID(params)
            end
        )

        --[[
		 * 移除所有推送
		--]]
        LocalPush.prototype.removeAllLocalNotices =
            __JS_Async(
            function(self)
                return SDKProxy.nativeLocalPush:removeAllLocalNotices()
            end
        )

        --[[
		 * 检查推送设置，如果没有权限则提示用户跳转开启
		--]]
        LocalPush.prototype.requireLocalNoticePermission =
            __JS_Async(
            function(self)
                return SDKProxy.nativeLocalPush:requireLocalNoticePermission()
            end
        )

        --[[
		 * 用户是否开启通知权限
		--]]
        function LocalPush.prototype:isLocalNoticeEnabled()
            return SDKProxy.nativeLocalPush:isLocalNoticeEnabled()
        end
        function LocalPush.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.api = nil

            --constructor logic
        end

        return LocalPush
    end)(GDK.ILocalPush)
    UnityAppGDK.LocalPush = LocalPush

    UnityAppGDK.LocalPush = LocalPush
end)(UnityAppGDK)

local RegisterList
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ = (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    RegisterList = (function(super)
        local RegisterList = declareClass("RegisterList", super)
        function RegisterList.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.Advert = Advert
            self.GameInfo = GameInfo
            self.User = User
            self.Pay = Pay
            self.Share = Share
            self.SystemInfo = SystemInfo
            self.UserData = UserData
            self.Customer = Customer
            self.Widgets = Widgets
            self.SubContext = SubContext
            self.Support = Support
            self.Except = Except
            self.Auth = Auth
            self.APISystem = APISystem
            self.Log = Log
            self.LocalPush = LocalPush
            self.Hardware = Hardware
            self.AdvertV2 = AdvertV2

            --constructor logic
        end

        return RegisterList
    end)(GDK.ModuleClassMap)
    UnityAppGDK.RegisterList = RegisterList

    UnityAppGDK.RegisterList = RegisterList
end)(UnityAppGDK)

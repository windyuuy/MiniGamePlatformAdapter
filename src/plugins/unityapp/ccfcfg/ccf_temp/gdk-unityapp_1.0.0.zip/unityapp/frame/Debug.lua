local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    local devlog = slib.Log({tags = Array({"[gdk]", "[frame]"})})
    GDK.devlog = devlog
    GDK.devlog = devlog
end)(GDK)

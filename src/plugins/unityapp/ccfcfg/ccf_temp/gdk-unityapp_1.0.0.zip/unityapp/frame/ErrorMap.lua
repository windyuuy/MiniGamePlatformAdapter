local GDKErrorExtra
local GDKError
local ResultTemplatesExtractor
local GDK = GDK or {}
_G.GDK = GDK
local _ =
    (function(GDK)
    extendsNSList({GDK, _G})

    --[[ 请求错误扩展参数--]]
    GDKErrorExtra = (function(super)
        local GDKErrorExtra = declareClass("GDKErrorExtra", super)
        function GDKErrorExtra.prototype:constructor()
            --member properties
            self.errCode = nil
            self.message = nil
            self.reason = nil
            self.data = nil
        end

        return GDKErrorExtra
    end)()
    GDK.GDKErrorExtra = GDKErrorExtra

    GDK.GDKErrorExtra = GDKErrorExtra

    --[[ 请求错误结果--]]
    GDKError =
        (function(super)
        local GDKError = declareClass("GDKError", super)

        function GDKError.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self, "")
            end

            --member properties
            self.errCode = nil
            self.reason = nil
            self.data = nil
            self.message = ""

            --constructor logic

            self.name = "GDKError"
        end

        function GDKError.prototype:toString()
            return [==[]==] ..
                tostring(self.name) ..
                    [==[: ]==] ..
                        tostring(self.errCode) ..
                            [==[ ]==] .. tostring(self.message) .. [==[ ]==] .. tostring(self.reason) .. [==[]==]
        end

        return GDKError
    end)(Error)
    GDK.GDKError = GDKError

    GDK.GDKError = GDKError

    --[[ 请求结果模板生成器--]]
    ResultTemplatesExtractor =
        (function(super)
        local ResultTemplatesExtractor = declareClass("ResultTemplatesExtractor", super)
        function ResultTemplatesExtractor.prototype:__getter__temps()
            return self._temps
        end

        function ResultTemplatesExtractor.prototype:constructor(temps)
            --member properties
            self._temps = Array({})

            --constructor parameters

            --constructor logic

            self._temps = temps
        end

        --[[
		 * 根据错误码和扩展参数构造请求结果
		--]]
        function ResultTemplatesExtractor.prototype:make(errCode, extra)
            local err = GDKError()
            -- 待优化
            local item =
                self._temps:find(
                function(item)
                    return item.errCode == errCode
                end
            )
            err.errCode = (extra and extra.errCode ~= nil) and (extra.errCode) or (item.errCode)
            err.message = (extra and extra.message ~= nil) and (extra.message) or (item.message)
            err.reason = (extra and extra.reason ~= nil) and (extra.reason) or (item.reason)
            err.data = (extra and extra.data ~= nil) and (extra.data) or (item.data)
            return err
        end

        return ResultTemplatesExtractor
    end)()
    GDK.ResultTemplatesExtractor = ResultTemplatesExtractor

    GDK.ResultTemplatesExtractor = ResultTemplatesExtractor
end)(GDK)

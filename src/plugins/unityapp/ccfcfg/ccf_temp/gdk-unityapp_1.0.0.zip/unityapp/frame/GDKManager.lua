local GDKManager
local FakeUserApi
local gdk
local GDK = GDK or {}
_G.GDK = GDK
local _ =
    (function(GDK)
    extendsNSList({GDK, _G})

    GDKManager =
        (function(super)
        local GDKManager = declareClass("GDKManager", super)

        function GDKManager.prototype:registPluginConfig(name, config)
            slib:assert(not self._configMap[name], [==[config name ]==] .. tostring(name) .. [==[ exists already!]==])
            self._configMap[name] = config
            defaultGDKName = name
        end

        function GDKManager.prototype:genGdk(temp)
            local map = {}
            local addonList = Array({})
            for k, _ in pairs(temp) do
                -- let pname = k[0].toLocaleLowerCase() + k.substr(1);
                local headLen = 0
                do
                    local ___temp = k
                    for ___i = 0, ___temp.length - 1 do
                        local c = ___temp[___i]

                        if c:toLocaleLowerCase() == c then
                            break
                        end
                        headLen = headLen + 1
                    end
                end

                local pname = k
                if headLen == 1 then
                    pname = k[0]:toLocaleLowerCase() .. k:substr(1)
                else
                    pname = k:substring(0, headLen - 1):toLocaleLowerCase() .. k:substring(headLen - 1)
                end
                map[pname] = temp[k]()
                addonList:push(map[pname])
            end
            local api = UserAPI(map)
            do
                local ___temp = addonList
                for ___i = 0, ___temp.length - 1 do
                    local addon = ___temp[___i]

                    addon.api = api
                end
            end

            return api
        end

        --[[
		 * 设置默认插件
		--]]
        function GDKManager.prototype:setDefaultGdk(name)
            local api = self._pluginMap[name]
            slib:assert(not (not api), [==[invalid api instance []==] .. tostring(name) .. [==[]]==])
            if __JS_InstanceOf(gdk, UserAPI) then
                slib:assert(not gdk, "-[GDK] default gdk instance shall not be set twice")
            end
            gdk = api
            window["gdk"] = api
        end

        function GDKManager.prototype:getPlugin(name)
            return slib:assert(self._pluginMap[name], [==[plugin []==] .. tostring(name) .. [==[] not exist]==])
        end

        --[[
		 * 传入配置并初始化
		--]]
        function GDKManager.prototype:initWithGDKConfig(info)
            for k, _ in pairs(self._pluginMap) do
                local plugin = self:getPlugin(k)
                -- 初始化插件内各个模块
                plugin["_initWithConfig"](plugin, info)
             -- 初始化插件内各个模块
            end
        end

        --[[
		 * 创建插件对象
		--]]
        function GDKManager.prototype:initializeGDKInstance()
            for k, _ in pairs(self._configMap) do
                local plugin = self:genGdk(self._configMap[k].register())
                self._pluginMap[k] = plugin
            end
        end
        function GDKManager.prototype:constructor()
            --member properties
            self._configMap = {}
            self._pluginMap = {}
        end

        return GDKManager
    end)()
    GDK.GDKManager = GDKManager

    GDK.GDKManager = GDKManager

    local gdkManager = GDKManager()
    GDK.gdkManager = gdkManager
    GDK.gdkManager = gdkManager

    --[[
	 * 初始入口
	--]]
    FakeUserApi = (function(super)
        local FakeUserApi = declareClass("FakeUserApi", super)
        function FakeUserApi.prototype:__getter__pluginName()
            return defaultGDKName
        end

        function FakeUserApi.prototype:initConfig(config)
            gdkManager:initializeGDKInstance()
            gdkManager:setDefaultGdk(defaultGDKName)
            gdkManager:initWithGDKConfig(config)
        end
        function FakeUserApi.prototype:constructor()
        end

        return FakeUserApi
    end)()

    window["gdk"] = FakeUserApi()
end)(GDK)

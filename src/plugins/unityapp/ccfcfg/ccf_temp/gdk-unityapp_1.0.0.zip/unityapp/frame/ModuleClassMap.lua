local ModuleClassMap
local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    ModuleClassMap = (function(super)
        local ModuleClassMap = declareClass("ModuleClassMap", super)
        function ModuleClassMap.prototype:constructor()
            --member properties
            self.Advert = nil
            self.GameInfo = nil
            self.User = nil
            self.Pay = nil
            self.Share = nil
            self.SystemInfo = nil
            self.APISystem = APISystemBase
            self.UserData = nil
            self.Customer = nil
            self.Widgets = nil
            self.SubContext = nil
            self.Support = nil
            self.Except = nil
            self.Auth = nil
            self.Hardware = HardwareBase
            self.Log = LogBase
            self.LocalPush = nil
        end

        return ModuleClassMap
    end)()
    GDK.ModuleClassMap = ModuleClassMap

    GDK.ModuleClassMap = ModuleClassMap
end)(GDK)

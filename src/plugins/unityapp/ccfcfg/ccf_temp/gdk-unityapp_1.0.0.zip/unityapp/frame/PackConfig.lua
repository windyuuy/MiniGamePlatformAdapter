local PackConfig
local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    PackConfig = (function(super)
        local PackConfig = declareClass("PackConfig", super)
        function PackConfig.prototype:constructor()
            --member properties
            self.platform = nil
            self.version = nil
            self.register = nil
        end

        return PackConfig
    end)()
    GDK.PackConfig = PackConfig

    GDK.PackConfig = PackConfig
end)(GDK)

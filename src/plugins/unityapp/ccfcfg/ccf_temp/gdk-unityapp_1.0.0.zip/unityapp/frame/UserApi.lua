local UserAPI
local GDK = GDK or {}
_G.GDK = GDK
local _ =
    (function(GDK)
    extendsNSList({GDK, _G})

    local devlog = slib.Log({tags = Array({"DEVELOP"})})
    -- 自动生成，成员使用register函数注册
    UserAPI =
        (function(super)
        local UserAPI = declareClass("UserAPI", super)

        function UserAPI.prototype:constructor(moduleMap)
            --member properties
            self._m = nil
            self.runtimePlatform = nil

            --constructor parameters

            --constructor logic

            self._m = moduleMap
        end

        function UserAPI.prototype:initConfig(config)
            devlog:warn("redundant init for gdk, ignored")
        end

        --[[
		 * 初始化插件内各个模块
		 * @param info 外部传入的配置
		--]]
        function UserAPI.prototype:_initWithConfig(info)
            for key, _ in pairs(self._m) do
                -- 初始化广告等具体模块
                local addon = self._m[key]
                if addon.init then
                    addon:init()
                end
                if addon.initWithConfig then
                    addon:initWithConfig(info)
                end
            end
        end

        function UserAPI.prototype:checkModuleAttr(moduleName, attrName, attrType)
            if attrType == nil then
                attrType = nil
            end
            slib:assert(self._m, "api not init")
            if __JS_TypeOf(self._m[moduleName]) ~= "object" then
                devlog:warn([==[module unsupport: [gdk::]==] .. tostring(moduleName) .. [==[]]==])
                return false
            end
            if attrType then
                local attr = self._m[moduleName][attrName]
                if not attr then
                    devlog:warn(
                        [==[func unsupport: [gdk::]==] ..
                            tostring(moduleName) .. [==[.]==] .. tostring(attrName) .. [==[]]==]
                    )
                    return false
                end
                if __JS_TypeOf(attr) ~= attrType then
                    devlog:warn(
                        [==[invalid type<]==] ..
                            tostring(attrType) ..
                                [==[>: [gdk::]==] ..
                                    tostring(moduleName) .. [==[.]==] .. tostring(attrName) .. [==[]]==]
                    )
                    return false
                end
            end
            return true
        end

        function UserAPI.prototype:createNonePromise(tip)
            if tip == nil then
                tip = ""
            end
            return Promise(
                function(resolve, reject)
                    setTimeout(
                        function()
                            reject("something unsupport " .. tip .. " to call")
                        end
                    )
                end
            )
        end

        function UserAPI.prototype:support(moduleName, attrName, attrType)
            if attrType == nil then
                attrType = nil
            end
            return self:checkModuleAttr(moduleName, attrName, attrType)
        end
        function UserAPI.prototype:__getter__userData()
            return self._m.userData
        end
        function UserAPI.prototype:__getter__gameInfo()
            return self._m.gameInfo
        end
        function UserAPI.prototype:__getter__systemInfo()
            return self._m.systemInfo
        end
        function UserAPI.prototype:__getter__openId()
            if not self:checkModuleAttr("userData", "openId") then
                return nil
            end
            return self._m.userData.openId
        end
        function UserAPI.prototype:__getter__openKey()
            if not self:checkModuleAttr("userData", "openKey") then
                return nil
            end
            return self._m.userData.openKey
        end
        function UserAPI.prototype:__getter__password()
            if not self:checkModuleAttr("userData", "password") then
                return nil
            end
            return self._m.userData.password
        end
        function UserAPI.prototype:__getter__nickName()
            if not self:checkModuleAttr("userData", "nickName") then
                return nil
            end
            return self._m.userData.nickName
        end
        function UserAPI.prototype:__getter__userId()
            if not self:checkModuleAttr("userData", "userId") then
                return nil
            end
            return self._m.userData.userId
        end
        function UserAPI.prototype:__getter__isNewUser()
            if not self:checkModuleAttr("userData", "isNewUser") then
                return nil
            end
            return self._m.userData.isNewUser
        end
        function UserAPI.prototype:__getter__avatarUrl()
            if not self:checkModuleAttr("userData", "avatarUrl") then
                return nil
            end
            return self._m.userData.avatarUrl
        end
        function UserAPI.prototype:__getter__backupTime()
            if not self:checkModuleAttr("userData", "backupTime") then
                return nil
            end
            return self._m.userData.backupTime
        end
        function UserAPI.prototype:__getter__followGzh()
            if not self:checkModuleAttr("userData", "followGzh") then
                return nil
            end
            return self._m.userData.followGzh
        end
        function UserAPI.prototype:__getter__channelId()
            if not self:checkModuleAttr("userData", "channelId") then
                return nil
            end
            return self._m.userData.channelId
        end
        function UserAPI.prototype:__getter__createTime()
            if not self:checkModuleAttr("userData", "createTime") then
                return nil
            end
            return self._m.userData.createTime
        end
        function UserAPI.prototype:__getter__sex()
            if not self:checkModuleAttr("userData", "sex") then
                return nil
            end
            return self._m.userData.sex
        end
        function UserAPI.prototype:__getter__isWhiteUser()
            if not self:checkModuleAttr("userData", "isWhiteUser") then
                return nil
            end
            return self._m.userData.isWhiteUser
        end
        function UserAPI.prototype:__getter__isMaster()
            if not self:checkModuleAttr("userData", "isMaster") then
                return nil
            end
            return self._m.userData.isMaster
        end
        function UserAPI.prototype:__getter__roomId()
            if not self:checkModuleAttr("userData", "roomId") then
                return nil
            end
            return self._m.userData.roomId
        end

        --[[ 登录--]]
        function UserAPI.prototype:login(params)
            if not self:checkModuleAttr("user", "login", "function") then
                return self:createNonePromise("[user.login]")
            end
            return self._m.user:login(params)
        end

        --[[ 绑定回调--]]
        function UserAPI.prototype:setBindCallback(callback)
            if not self:checkModuleAttr("user", "setBindCallback", "function") then
                return nil
            end
            return self._m.user:setBindCallback(callback)
        end

        --[[ 绑定回调--]]
        function UserAPI.prototype:setRebootCallback(callback)
            if not self:checkModuleAttr("user", "setRebootCallback", "function") then
                return nil
            end
            return self._m.user:setRebootCallback(callback)
        end

        --[[
		 * 显示用户中心
		 * * APP平台支持
		--]]
        function UserAPI.prototype:showUserCenter()
            if not self:checkModuleAttr("user", "showUserCenter", "function") then
                return self:createNonePromise("[user.showUserCenter]")
            end
            return self._m.user:showUserCenter()
        end

        --[[
		 * 判断是否为本地实名制系统
		--]]
        function UserAPI.prototype:isNativeRealNameSystem()
            if not self:checkModuleAttr("user", "isNativeRealNameSystem", "function") then
                return nil
            end
            return self._m.user:isNativeRealNameSystem()
        end

        --[[
		 * 显示未成年人游戏描述信息
		 * * APP平台支持
		--]]
        function UserAPI.prototype:showMinorInfo(info)
            if not self:checkModuleAttr("user", "showMinorInfo", "function") then
                return self:createNonePromise("[user.showMinorInfo]")
            end
            return self._m.user:showMinorInfo(info)
        end

        --[[
		 * 显示实名制弹框，进入实名制流程
		 * * APP平台支持
		 * @param force 是否强制
		--]]
        function UserAPI.prototype:showRealNameDialog(userID, force)
            if not self:checkModuleAttr("user", "showRealNameDialog", "function") then
                return self:createNonePromise("[user.showRealNameDialog]")
            end
            return self._m.user:showRealNameDialog(userID, force)
        end

        --[[
		 * 显示账号绑定
		 * * APP平台支持
		--]]
        function UserAPI.prototype:showBindDialog()
            if not self:checkModuleAttr("user", "showBindDialog", "function") then
                return self:createNonePromise("[user.showBindDialog]")
            end
            return self._m.user:showBindDialog()
        end

        --[[ 检查登录态是否过期--]]
        function UserAPI.prototype:checkSession(params)
            if not self:checkModuleAttr("user", "checkSession", "function") then
                return self:createNonePromise("[user.checkSession]")
            end
            return self._m.user:checkSession(params)
        end

        --[[ 更新用户数据--]]
        function UserAPI.prototype:updateUser()
            if not self:checkModuleAttr("user", "update", "function") then
                return self:createNonePromise("[user.update]")
            end
            return self._m.user:update()
        end

        --[[
		 * 获取用户云端数据
		 * - oppo未处理
		--]]
        function UserAPI.prototype:getFriendCloudStorage(obj)
            if not self:checkModuleAttr("user", "getFriendCloudStorage", "function") then
                return self:createNonePromise("[user.getFriendCloudStorage]")
            end
            return self._m.user:getFriendCloudStorage(obj)
        end

        --[[
		 * 提交用户云端数据
		 * - oppo未处理
		--]]
        function UserAPI.prototype:setUserCloudStorage(obj)
            if not self:checkModuleAttr("user", "setUserCloudStorage", "function") then
                return self:createNonePromise("[user.setUserCloudStorage]")
            end
            return self._m.user:setUserCloudStorage(obj)
        end

        --[[
		 * 判断userId对应的用户是否绑定过社交账号
		 * @param userId 登录时服务器返回的userId
		--]]
        function UserAPI.prototype:checkIsUserBind(userId)
            if not self:checkModuleAttr("user", "checkIsUserBind", "function") then
                return nil
            end
            return self._m.user:checkIsUserBind(userId)
        end

        -- }
        function UserAPI.prototype:setLoginSupport(loginSupport)
            if not self:checkModuleAttr("user", "setLoginSupport", "function") then
                return nil
            end
            return self._m.user:setLoginSupport(loginSupport)
        end

        function UserAPI.prototype:setAccountChangeListener(f)
            if not self:checkModuleAttr("user", "setAccountChangeListener", "function") then
                return nil
            end
            return self._m.user:setAccountChangeListener(f)
        end
        function UserAPI.prototype:__getter__mode()
            if not self:checkModuleAttr("gameInfo", "mode") then
                return nil
            end
            return self._m.gameInfo.mode
        end
        function UserAPI.prototype:__getter__appId()
            if not self:checkModuleAttr("gameInfo", "appId") then
                return nil
            end
            return self._m.gameInfo.appId
        end
        function UserAPI.prototype:__getter__gameChannelId()
            if not self:checkModuleAttr("gameInfo", "gameChannelId") then
                return nil
            end
            return self._m.gameInfo.gameChannelId
        end
        function UserAPI.prototype:__getter__isPayInSandbox()
            if not self:checkModuleAttr("gameInfo", "isPayInSandbox") then
                return nil
            end
            return self._m.gameInfo.isPayInSandbox
        end
        function UserAPI.prototype:__getter__payAppEnvVersion()
            if not self:checkModuleAttr("gameInfo", "payAppEnvVersion") then
                return nil
            end
            return self._m.gameInfo.payAppEnvVersion
        end
        function UserAPI.prototype:__getter__offerId()
            if not self:checkModuleAttr("gameInfo", "offerId") then
                return nil
            end
            return self._m.gameInfo.offerId
        end
        function UserAPI.prototype:__getter__miniAppOfferId()
            if not self:checkModuleAttr("gameInfo", "miniAppOfferId") then
                return nil
            end
            return self._m.gameInfo.miniAppOfferId
        end
        function UserAPI.prototype:__getter__shareProxyUrl()
            if not self:checkModuleAttr("gameInfo", "shareProxyUrl") then
                return nil
            end
            return self._m.gameInfo.shareProxyUrl
        end
        function UserAPI.prototype:__getter__launchOptions()
            if not self:checkModuleAttr("gameInfo", "launchOptions") then
                return nil
            end
            return self._m.gameInfo.launchOptions
        end
        function UserAPI.prototype:__getter__gameVersion()
            if not self:checkModuleAttr("gameInfo", "gameVersion") then
                return nil
            end
            return self._m.gameInfo.gameVersion
        end
        function UserAPI.prototype:__getter__gameId()
            if not self:checkModuleAttr("gameInfo", "gameId") then
                return nil
            end
            return self._m.gameInfo.gameId
        end
        function UserAPI.prototype:__getter__gameType()
            if not self:checkModuleAttr("gameInfo", "gameType") then
                return nil
            end
            return self._m.gameInfo.gameType
        end
        function UserAPI.prototype:__getter__requireCustomServicePay()
            if not self:checkModuleAttr("gameInfo", "requireCustomServicePay") then
                return nil
            end
            return self._m.gameInfo.requireCustomServicePay
        end
        function UserAPI.prototype:__getter__requireMiniAppPay()
            if not self:checkModuleAttr("gameInfo", "requireMiniAppPay") then
                return nil
            end
            return self._m.gameInfo.requireMiniAppPay
        end
        function UserAPI.prototype:__getter__requireIndiaSPSPay()
            if not self:checkModuleAttr("gameInfo", "requireIndiaSPSPay") then
                return nil
            end
            return self._m.gameInfo.requireIndiaSPSPay
        end
        function UserAPI.prototype:__getter__brand()
            if not self:checkModuleAttr("systemInfo", "brand") then
                return nil
            end
            return self._m.systemInfo.brand
        end
        function UserAPI.prototype:__getter__model()
            if not self:checkModuleAttr("systemInfo", "model") then
                return nil
            end
            return self._m.systemInfo.model
        end
        function UserAPI.prototype:__getter__pixelRatio()
            if not self:checkModuleAttr("systemInfo", "pixelRatio") then
                return nil
            end
            return self._m.systemInfo.pixelRatio
        end
        function UserAPI.prototype:__getter__screenWidth()
            if not self:checkModuleAttr("systemInfo", "screenWidth") then
                return nil
            end
            return self._m.systemInfo.screenWidth
        end
        function UserAPI.prototype:__getter__screenHeight()
            if not self:checkModuleAttr("systemInfo", "screenHeight") then
                return nil
            end
            return self._m.systemInfo.screenHeight
        end
        function UserAPI.prototype:__getter__windowWidth()
            if not self:checkModuleAttr("systemInfo", "windowWidth") then
                return nil
            end
            return self._m.systemInfo.windowWidth
        end
        function UserAPI.prototype:__getter__windowHeight()
            if not self:checkModuleAttr("systemInfo", "windowHeight") then
                return nil
            end
            return self._m.systemInfo.windowHeight
        end
        function UserAPI.prototype:__getter__statusBarHeight()
            if not self:checkModuleAttr("systemInfo", "statusBarHeight") then
                return nil
            end
            return self._m.systemInfo.statusBarHeight
        end
        function UserAPI.prototype:__getter__language()
            if not self:checkModuleAttr("systemInfo", "language") then
                return nil
            end
            return self._m.systemInfo.language
        end
        function UserAPI.prototype:__getter__version()
            if not self:checkModuleAttr("systemInfo", "version") then
                return nil
            end
            return self._m.systemInfo.version
        end
        function UserAPI.prototype:__getter__system()
            if not self:checkModuleAttr("systemInfo", "system") then
                return nil
            end
            return self._m.systemInfo.system
        end
        function UserAPI.prototype:__getter__platform()
            if not self:checkModuleAttr("systemInfo", "platform") then
                return nil
            end
            return self._m.systemInfo.platform
        end
        function UserAPI.prototype:__getter__fontSizeSetting()
            if not self:checkModuleAttr("systemInfo", "fontSizeSetting") then
                return nil
            end
            return self._m.systemInfo.fontSizeSetting
        end
        function UserAPI.prototype:__getter__SDKVersion()
            if not self:checkModuleAttr("systemInfo", "SDKVersion") then
                return nil
            end
            return self._m.systemInfo.SDKVersion
        end
        function UserAPI.prototype:__getter__benchmarkLevel()
            if not self:checkModuleAttr("systemInfo", "benchmarkLevel") then
                return nil
            end
            return self._m.systemInfo.benchmarkLevel
        end
        function UserAPI.prototype:__getter__networkType()
            if not self:checkModuleAttr("systemInfo", "networkType") then
                return nil
            end
            return self._m.systemInfo.networkType
        end
        function UserAPI.prototype:__getter__networkClass()
            if not self:checkModuleAttr("systemInfo", "networkClass") then
                return nil
            end
            return self._m.systemInfo.networkClass
        end
        function UserAPI.prototype:__getter__isFirstInstall()
            if not self:checkModuleAttr("systemInfo", "isFirstInstall") then
                return nil
            end
            return self._m.systemInfo.isFirstInstall
        end
        function UserAPI.prototype:__getter__devPlatform()
            if not self:checkModuleAttr("systemInfo", "devPlatform") then
                return nil
            end
            return self._m.systemInfo.devPlatform
        end
        function UserAPI.prototype:__getter__deviceId()
            if not self:checkModuleAttr("systemInfo", "deviceId") then
                return nil
            end
            return self._m.systemInfo.deviceId
        end
        function UserAPI.prototype:__getter__uuid()
            if not self:checkModuleAttr("systemInfo", "uuid") then
                return nil
            end
            return self._m.systemInfo.uuid
        end
        function UserAPI.prototype:__getter__gameDeviceId()
            if not self:checkModuleAttr("systemInfo", "gameDeviceId") then
                return nil
            end
            return self._m.systemInfo.gameDeviceId
        end
        function UserAPI.prototype:__getter__versionCode()
            if not self:checkModuleAttr("systemInfo", "versionCode") then
                return nil
            end
            return self._m.systemInfo.versionCode
        end
        function UserAPI.prototype:__getter__versionName()
            if not self:checkModuleAttr("systemInfo", "versionName") then
                return nil
            end
            return self._m.systemInfo.versionName
        end
        function UserAPI.prototype:__getter__channel()
            if not self:checkModuleAttr("systemInfo", "channel") then
                return nil
            end
            return self._m.systemInfo.channel
        end
        function UserAPI.prototype:__getter__quickChannelId()
            if not self:checkModuleAttr("systemInfo", "quickChannelId") then
                return nil
            end
            return self._m.systemInfo.quickChannelId
        end
        function UserAPI.prototype:__getter__country()
            if not self:checkModuleAttr("systemInfo", "country") then
                return nil
            end
            return self._m.systemInfo.country
        end
        function UserAPI.prototype:__getter__installTime()
            if not self:checkModuleAttr("systemInfo", "installTime") then
                return nil
            end
            return self._m.systemInfo.installTime
        end
        function UserAPI.prototype:__getter__imei()
            if not self:checkModuleAttr("systemInfo", "imei") then
                return nil
            end
            return self._m.systemInfo.imei
        end
        function UserAPI.prototype:__getter__packageName()
            if not self:checkModuleAttr("systemInfo", "packageName") then
                return nil
            end
            return self._m.systemInfo.packageName
        end
        function UserAPI.prototype:__getter__packageTag()
            if not self:checkModuleAttr("systemInfo", "packageTag") then
                return nil
            end
            return self._m.systemInfo.packageTag
        end
        function UserAPI.prototype:__getter__debugAccountServer()
            if not self:checkModuleAttr("systemInfo", "debugAccountServer") then
                return nil
            end
            return self._m.systemInfo.debugAccountServer
        end
        function UserAPI.prototype:__getter__isCustomBackendCfg()
            if not self:checkModuleAttr("systemInfo", "isCustomBackendCfg") then
                return nil
            end
            return self._m.systemInfo.isCustomBackendCfg
        end
        function UserAPI.prototype:__getter__androidId()
            if not self:checkModuleAttr("systemInfo", "androidId") then
                return nil
            end
            return self._m.systemInfo.androidId
        end
        function UserAPI.prototype:__getter__mac()
            if not self:checkModuleAttr("systemInfo", "mac") then
                return nil
            end
            return self._m.systemInfo.mac
        end
        function UserAPI.prototype:__getter__userAgent()
            if not self:checkModuleAttr("systemInfo", "userAgent") then
                return nil
            end
            return self._m.systemInfo.userAgent
        end
        function UserAPI.prototype:__getter__tableConf()
            if not self:checkModuleAttr("systemInfo", "tableConf") then
                return nil
            end
            return self._m.systemInfo.tableConf
        end

        --[[
		 * 刷新网络状况信息
		--]]
        function UserAPI.prototype:fetchNetworkInfo()
            if not self:checkModuleAttr("systemInfo", "fetchNetworkInfo", "function") then
                return self:createNonePromise("[systemInfo.fetchNetworkInfo]")
            end
            return self._m.systemInfo:fetchNetworkInfo()
        end

        function UserAPI.prototype:clone()
            if not self:checkModuleAttr("systemInfo", "clone", "function") then
                return nil
            end
            return self._m.systemInfo:clone()
        end

        --[[
		 * 跳转游戏
		--]]
        function UserAPI.prototype:navigateToApp(params)
            if not self:checkModuleAttr("apiSystem", "navigateToApp", "function") then
                return self:createNonePromise("[apiSystem.navigateToApp]")
            end
            return self._m.apiSystem:navigateToApp(params)
        end

        --[[
		 * 退出当前游戏
		--]]
        function UserAPI.prototype:exitProgram()
            if not self:checkModuleAttr("apiSystem", "exitProgram", "function") then
                return self:createNonePromise("[apiSystem.exitProgram]")
            end
            return self._m.apiSystem:exitProgram()
        end

        --[[
		 * 用法示例：
		 * ```typescript
		 * onShow((data)=>{
		 * 	...
		 * })
		 * ```
		--]]
        function UserAPI.prototype:onShow(callback)
            if not self:checkModuleAttr("apiSystem", "onShow", "function") then
                return nil
            end
            return self._m.apiSystem:onShow(callback)
        end

        function UserAPI.prototype:offShow(callback)
            if not self:checkModuleAttr("apiSystem", "offShow", "function") then
                return nil
            end
            return self._m.apiSystem:offShow(callback)
        end

        --[[
		 * 用法示例：
		 * ```typescript
		 * onHide(()=>{
		 * 	...
		 * })
		 * ```
		--]]
        function UserAPI.prototype:onHide(callback)
            if not self:checkModuleAttr("apiSystem", "onHide", "function") then
                return nil
            end
            return self._m.apiSystem:onHide(callback)
        end

        function UserAPI.prototype:offHide(callback)
            if not self:checkModuleAttr("apiSystem", "offHide", "function") then
                return nil
            end
            return self._m.apiSystem:offHide(callback)
        end

        --[[
		 * 强制更新
		--]]
        function UserAPI.prototype:updateProgramForce()
            if not self:checkModuleAttr("apiSystem", "updateProgramForce", "function") then
                return self:createNonePromise("[apiSystem.updateProgramForce]")
            end
            return self._m.apiSystem:updateProgramForce()
        end

        --[[
		 * 设置是否打开调试开关。此开关对正式版也能生效。
		--]]
        function UserAPI.prototype:setEnableDebug(res)
            if not self:checkModuleAttr("apiSystem", "setEnableDebug", "function") then
                return self:createNonePromise("[apiSystem.setEnableDebug]")
            end
            return self._m.apiSystem:setEnableDebug(res)
        end

        --[[
		 * - 设置帧率
		 * 	- 可能和cocos的会冲突
		--]]
        function UserAPI.prototype:setFPS(fps)
            if not self:checkModuleAttr("apiSystem", "setFPS", "function") then
                return nil
            end
            return self._m.apiSystem:setFPS(fps)
        end
        function UserAPI.prototype:__getter__clipboard()
            if not self:checkModuleAttr("apiSystem", "clipboard") then
                return nil
            end
            return self._m.apiSystem.clipboard
        end

        --[[
		 * 获取屏幕的安全区域，单位像素
		 * @param callback
		--]]
        function UserAPI.prototype:getSafeArea(callback)
            if not self:checkModuleAttr("apiSystem", "getSafeArea", "function") then
                return nil
            end
            return self._m.apiSystem:getSafeArea(callback)
        end

        -- 设置加载进度
        function UserAPI.prototype:setLoadingProgress(params)
            if not self:checkModuleAttr("apiSystem", "setLoadingProgress", "function") then
                return nil
            end
            return self._m.apiSystem:setLoadingProgress(params)
        end

        --[[
		 * 网页跳转
		 * @param url
		--]]
        function UserAPI.prototype:openURL(url)
            if not self:checkModuleAttr("apiSystem", "openURL", "function") then
                return nil
            end
            return self._m.apiSystem:openURL(url)
        end

        --[[
		 * 开启云客服
		--]]
        function UserAPI.prototype:startYunkefu(accessId, name, id, customField, native)
            if not self:checkModuleAttr("apiSystem", "startYunkefu", "function") then
                return nil
            end
            return self._m.apiSystem:startYunkefu(accessId, name, id, customField, native)
        end

        --[[
		 *
		 * 是否存在原生客服中心
		--]]
        function UserAPI.prototype:hasNativeAssistantCenter()
            if not self:checkModuleAttr("apiSystem", "hasNativeAssistantCenter", "function") then
                return nil
            end
            return self._m.apiSystem:hasNativeAssistantCenter()
        end

        --[[
		 * hack web
		 * @param url
		--]]
        function UserAPI.prototype:showHackWeb(url, duration)
            if not self:checkModuleAttr("apiSystem", "showHackWeb", "function") then
                return nil
            end
            return self._m.apiSystem:showHackWeb(url, duration)
        end

        --[[
		 * set native sdk language
		 * @param lang
		--]]
        function UserAPI.prototype:setSDKLanguage(lang)
            if not self:checkModuleAttr("apiSystem", "setSDKLanguage", "function") then
                return nil
            end
            return self._m.apiSystem:setSDKLanguage(lang)
        end
        function UserAPI.prototype:__getter__nativeVersion()
            if not self:checkModuleAttr("apiSystem", "nativeVersion") then
                return nil
            end
            return self._m.apiSystem.nativeVersion
        end

        --[[
		 * 跳转app设置界面
		 * - 目前只支持 android
		--]]
        function UserAPI.prototype:gotoAppSystemSettings(params)
            if not self:checkModuleAttr("apiSystem", "gotoAppSystemSettings", "function") then
                return self:createNonePromise("[apiSystem.gotoAppSystemSettings]")
            end
            return self._m.apiSystem:gotoAppSystemSettings(params)
        end

        --[[
		 * 检查是否已授予权限
		 * - 目前只支持 android
		--]]
        function UserAPI.prototype:checkAppSystemPermissions(params)
            if not self:checkModuleAttr("apiSystem", "checkAppSystemPermissions", "function") then
                return self:createNonePromise("[apiSystem.checkAppSystemPermissions]")
            end
            return self._m.apiSystem:checkAppSystemPermissions(params)
        end

        --[[
		 * 分享到聊天窗口
		 * * 如果目标平台没有明确的聊天窗口，则进行社会化分享。
		 * * 如果当前环境无法分享，则分享失败
		--]]
        function UserAPI.prototype:share(data)
            if not self:checkModuleAttr("share", "share", "function") then
                return self:createNonePromise("[share.share]")
            end
            return self._m.share:share(data)
        end

        --[[
		 * 社会化分享
		 * * 如果目标平台无法进行社会化分享，则选用聊天窗口分享。
		 * * 如果当前环境无法分享，则分享失败
		--]]
        function UserAPI.prototype:socialShare(data)
            if not self:checkModuleAttr("share", "socialShare", "function") then
                return self:createNonePromise("[share.socialShare]")
            end
            return self._m.share:socialShare(data)
        end

        --[[
		 * 分享网址
		 * * 如果当前环境无法进行URL分享，则分享失败
		 * * 当前仅 QQPlay 环境支持
		--]]
        function UserAPI.prototype:shareUrl(data)
            if not self:checkModuleAttr("share", "shareUrl", "function") then
                return self:createNonePromise("[share.shareUrl]")
            end
            return self._m.share:shareUrl(data)
        end

        --[[
		 * 显示分享菜单
		 * * 微信平台必须调用该函数才会显示转发按钮
		 * * QQ平台默认就有转发按钮
		--]]
        function UserAPI.prototype:showShareMenu()
            if not self:checkModuleAttr("share", "showShareMenu", "function") then
                return self:createNonePromise("[share.showShareMenu]")
            end
            return self._m.share:showShareMenu()
        end

        --[[
		 * 隐藏分享菜单
		--]]
        function UserAPI.prototype:hideShareMenu()
            if not self:checkModuleAttr("share", "hideShareMenu", "function") then
                return self:createNonePromise("[share.hideShareMenu]")
            end
            return self._m.share:hideShareMenu()
        end

        --[[
		 * 在某些平台可以设置分享按钮所分享的内容
		 * * 微信支持
		 * * QQplay 无效
		--]]
        function UserAPI.prototype:setShareMenuData(data)
            if not self:checkModuleAttr("share", "setShareMenuData", "function") then
                return self:createNonePromise("[share.setShareMenuData]")
            end
            return self._m.share:setShareMenuData(data)
        end

        --[[
		 * 获取通过点击分享链接时或传递的参数
		--]]
        function UserAPI.prototype:getShareParam()
            if not self:checkModuleAttr("share", "getShareParam", "function") then
                return self:createNonePromise("[share.getShareParam]")
            end
            return self._m.share:getShareParam()
        end

        --[[
		 * 获取通过点击分享链接时或传递的参数
		--]]
        function UserAPI.prototype:getShareTicket()
            if not self:checkModuleAttr("share", "getShareTicket", "function") then
                return self:createNonePromise("[share.getShareTicket]")
            end
            return self._m.share:getShareTicket()
        end

        --[[
		 * 获取分享的信息
		 * * 当前仅微信环境有效
		--]]
        function UserAPI.prototype:getShareInfo(shareTicket)
            if not self:checkModuleAttr("share", "getShareInfo", "function") then
                return self:createNonePromise("[share.getShareInfo]")
            end
            return self._m.share:getShareInfo(shareTicket)
        end

        --[[
		 * 调起支付
		--]]
        function UserAPI.prototype:payPurchase(item, options)
            if not self:checkModuleAttr("pay", "payPurchase", "function") then
                return self:createNonePromise("[pay.payPurchase]")
            end
            return self._m.pay:payPurchase(item, options)
        end

        --[[
		 * 消耗商品
		--]]
        function UserAPI.prototype:consumePurchase(params)
            if not self:checkModuleAttr("pay", "consumePurchase", "function") then
                return self:createNonePromise("[pay.consumePurchase]")
            end
            return self._m.pay:consumePurchase(params)
        end

        --[[
		 * 查询未消耗商品信息
		--]]
        function UserAPI.prototype:queryItemInfo(params)
            if not self:checkModuleAttr("pay", "queryItemInfo", "function") then
                return self:createNonePromise("[pay.queryItemInfo]")
            end
            return self._m.pay:queryItemInfo(params)
        end
        function UserAPI.prototype:__getter__needInitAdServiceFirst()
            if not self:checkModuleAttr("advert", "needInitAdServiceFirst") then
                return nil
            end
            return self._m.advert.needInitAdServiceFirst
        end

        --[[
		 * 初始化广告服务
		--]]
        function UserAPI.prototype:initAdService(params)
            if not self:checkModuleAttr("advert", "initAdService", "function") then
                return self:createNonePromise("[advert.initAdService]")
            end
            return self._m.advert:initAdService(params)
        end

        --[[
		 * 是个单例
		 * 创建激励视频广告对象
		--]]
        function UserAPI.prototype:createRewardedVideoAd(params)
            if not self:checkModuleAttr("advert", "createRewardedVideoAd", "function") then
                return nil
            end
            return self._m.advert:createRewardedVideoAd(params)
        end

        --[[ 创建条幅广告对象--]]
        function UserAPI.prototype:createBannerAd(params)
            if not self:checkModuleAttr("advert", "createBannerAd", "function") then
                return nil
            end
            return self._m.advert:createBannerAd(params)
        end
        function UserAPI.prototype:__getter__supportInterstitialAd()
            if not self:checkModuleAttr("advert", "supportInterstitialAd") then
                return nil
            end
            return self._m.advert.supportInterstitialAd
        end

        function UserAPI.prototype:createInterstitialAd(params)
            if not self:checkModuleAttr("advert", "createInterstitialAd", "function") then
                return nil
            end
            return self._m.advert:createInterstitialAd(params)
        end
        function UserAPI.prototype:__getter__supportFullscreenAd()
            if not self:checkModuleAttr("advert", "supportFullscreenAd") then
                return nil
            end
            return self._m.advert.supportFullscreenAd
        end
        function UserAPI.prototype:__getter__supportFullscreenVideoAd()
            if not self:checkModuleAttr("advert", "supportFullscreenVideoAd") then
                return nil
            end
            return self._m.advert.supportFullscreenVideoAd
        end

        --[[
		 * 创建全屏广告
		--]]
        function UserAPI.prototype:createFullscreenVideoAd(params)
            if not self:checkModuleAttr("advert", "createFullscreenVideoAd", "function") then
                return nil
            end
            return self._m.advert:createFullscreenVideoAd(params)
        end
        function UserAPI.prototype:__getter__supportFeedAd()
            if not self:checkModuleAttr("advert", "supportFeedAd") then
                return nil
            end
            return self._m.advert.supportFeedAd
        end

        --[[
		 * 创建信息流广告
		--]]
        function UserAPI.prototype:createFeedAd(params)
            if not self:checkModuleAttr("advert", "createFeedAd", "function") then
                return nil
            end
            return self._m.advert:createFeedAd(params)
        end

        --[[
		 * 切换广告平台
		--]]
        function UserAPI.prototype:selectAdvertPlatform(params)
            if not self:checkModuleAttr("advert", "selectAdvertPlatform", "function") then
                return self:createNonePromise("[advert.selectAdvertPlatform]")
            end
            return self._m.advert:selectAdvertPlatform(params)
        end

        --[[
		 * 切换广告平台
		--]]
        function UserAPI.prototype:initMultAdSlot(params)
            if not self:checkModuleAttr("advert", "initMultAdSlot", "function") then
                return self:createNonePromise("[advert.initMultAdSlot]")
            end
            return self._m.advert:initMultAdSlot(params)
        end

        --[[
		 * - 进入客服会话。
		 * 	- 微信小游戏要求在用户发生过至少一次 touch 事件后才能调用。后台接入方式与小程序一致
		--]]
        function UserAPI.prototype:openCustomerServiceConversation(params)
            if not self:checkModuleAttr("customer", "openCustomerServiceConversation", "function") then
                return nil
            end
            return self._m.customer:openCustomerServiceConversation(params)
        end
        function UserAPI.prototype:__getter__keyboard()
            if not self:checkModuleAttr("widgets", "keyboard") then
                return nil
            end
            return self._m.widgets.keyboard
        end

        --[[ 显示 loading 提示框。需主动调用 wx.hideLoading 才能关闭提示框--]]
        function UserAPI.prototype:showLoading(object)
            if not self:checkModuleAttr("widgets", "showLoading", "function") then
                return self:createNonePromise("[widgets.showLoading]")
            end
            return self._m.widgets:showLoading(object)
        end

        --[[ 隐藏 loading 提示框--]]
        function UserAPI.prototype:hideLoading()
            if not self:checkModuleAttr("widgets", "hideLoading", "function") then
                return self:createNonePromise("[widgets.hideLoading]")
            end
            return self._m.widgets:hideLoading()
        end

        --[[ 显示消息提示框--]]
        function UserAPI.prototype:showToast(object)
            if not self:checkModuleAttr("widgets", "showToast", "function") then
                return self:createNonePromise("[widgets.showToast]")
            end
            return self._m.widgets:showToast(object)
        end

        --[[ 隐藏消息提示框--]]
        function UserAPI.prototype:hideToast()
            if not self:checkModuleAttr("widgets", "hideToast", "function") then
                return self:createNonePromise("[widgets.hideToast]")
            end
            return self._m.widgets:hideToast()
        end

        --[[
		 * 显示模态对话框
		 * - 有`确定`和`取消`两个按钮
		--]]
        function UserAPI.prototype:showConfirm(object)
            if not self:checkModuleAttr("widgets", "showConfirm", "function") then
                return self:createNonePromise("[widgets.showConfirm]")
            end
            return self._m.widgets:showConfirm(object)
        end

        --[[
		 * 显示模态对话框
		 * - 有`确定`和`取消`两个按钮
		--]]
        function UserAPI.prototype:showPrompt(object)
            if not self:checkModuleAttr("widgets", "showPrompt", "function") then
                return self:createNonePromise("[widgets.showPrompt]")
            end
            return self._m.widgets:showPrompt(object)
        end

        --[[
		 * 显示模态对话框
		 * - 只有`确定`一个按钮
		--]]
        function UserAPI.prototype:showAlert(object)
            if not self:checkModuleAttr("widgets", "showAlert", "function") then
                return self:createNonePromise("[widgets.showAlert]")
            end
            return self._m.widgets:showAlert(object)
        end

        --[[
		 * 隐藏启动画面
		--]]
        function UserAPI.prototype:hideLaunchingView()
            if not self:checkModuleAttr("widgets", "hideLaunchingView", "function") then
                return self:createNonePromise("[widgets.hideLaunchingView]")
            end
            return self._m.widgets:hideLaunchingView()
        end

        --[[
		 * 监听主域发送的消息
		--]]
        function UserAPI.prototype:onMessage(callback)
            if not self:checkModuleAttr("subContext", "onMessage", "function") then
                return nil
            end
            return self._m.subContext:onMessage(callback)
        end

        --[[
		 * 获取开放数据域
		--]]
        function UserAPI.prototype:getOpenDataContext()
            if not self:checkModuleAttr("subContext", "getOpenDataContext", "function") then
                return nil
            end
            return self._m.subContext:getOpenDataContext()
        end
        function UserAPI.prototype:__getter__apiPlatform()
            if not self:checkModuleAttr("support", "apiPlatform") then
                return nil
            end
            return self._m.support.apiPlatform
        end
        function UserAPI.prototype:__getter__pluginName()
            if not self:checkModuleAttr("support", "pluginName") then
                return nil
            end
            return self._m.support.pluginName
        end
        function UserAPI.prototype:__getter__supportShare()
            if not self:checkModuleAttr("support", "supportShare") then
                return nil
            end
            return self._m.support.supportShare
        end
        function UserAPI.prototype:__getter__supportShareTickets()
            if not self:checkModuleAttr("support", "supportShareTickets") then
                return nil
            end
            return self._m.support.supportShareTickets
        end
        function UserAPI.prototype:__getter__requireSubDomainRank()
            if not self:checkModuleAttr("support", "requireSubDomainRank") then
                return nil
            end
            return self._m.support.requireSubDomainRank
        end
        function UserAPI.prototype:__getter__requireAuthorize()
            if not self:checkModuleAttr("support", "requireAuthorize") then
                return nil
            end
            return self._m.support.requireAuthorize
        end
        function UserAPI.prototype:__getter__apiNameLocale()
            if not self:checkModuleAttr("support", "apiNameLocale") then
                return nil
            end
            return self._m.support.apiNameLocale
        end

        --[[
		 * 注册全局的错误回调函数
		--]]
        function UserAPI.prototype:setErrorCallback(callback)
            if not self:checkModuleAttr("except", "setErrorCallback", "function") then
                return nil
            end
            return self._m.except:setErrorCallback(callback)
        end

        --[[
		 * 创建用户信息授权按钮
		 * * 当前仅微信有效
		--]]
        function UserAPI.prototype:createUserInfoButton(obj)
            if not self:checkModuleAttr("auth", "createUserInfoButton", "function") then
                return nil
            end
            return self._m.auth:createUserInfoButton(obj)
        end

        --[[
		 * 判断是否拥有获取用户信息的权限
		--]]
        function UserAPI.prototype:isUserInfoAuthAlready()
            if not self:checkModuleAttr("auth", "isUserInfoAuthAlready", "function") then
                return self:createNonePromise("[auth.isUserInfoAuthAlready]")
            end
            return self._m.auth:isUserInfoAuthAlready()
        end
        function UserAPI.prototype:__getter__vibration()
            if not self:checkModuleAttr("hardware", "vibration") then
                return nil
            end
            return self._m.hardware.vibration
        end
        function UserAPI.prototype:__getter__performance()
            if not self:checkModuleAttr("hardware", "performance") then
                return nil
            end
            return self._m.hardware.performance
        end
        function UserAPI.prototype:__getter__screen()
            if not self:checkModuleAttr("hardware", "screen") then
                return nil
            end
            return self._m.hardware.screen
        end
        function UserAPI.prototype:__getter__gyroscope()
            if not self:checkModuleAttr("hardware", "gyroscope") then
                return nil
            end
            return self._m.hardware.gyroscope
        end
        function UserAPI.prototype:__getter__compass()
            if not self:checkModuleAttr("hardware", "compass") then
                return nil
            end
            return self._m.hardware.compass
        end
        function UserAPI.prototype:__getter__battery()
            if not self:checkModuleAttr("hardware", "battery") then
                return nil
            end
            return self._m.hardware.battery
        end
        function UserAPI.prototype:__getter__accelerometer()
            if not self:checkModuleAttr("hardware", "accelerometer") then
                return nil
            end
            return self._m.hardware.accelerometer
        end
        function UserAPI.prototype:__getter__gravity()
            if not self:checkModuleAttr("hardware", "gravity") then
                return nil
            end
            return self._m.hardware.gravity
        end
        function UserAPI.prototype:__getter__screenTouch()
            if not self:checkModuleAttr("hardware", "screenTouch") then
                return nil
            end
            return self._m.hardware.screenTouch
        end

        --[[
		 * 提交日志
		--]]
        function UserAPI.prototype:commitLog(key, params)
            if not self:checkModuleAttr("log", "commitLog", "function") then
                return self:createNonePromise("[log.commitLog]")
            end
            return self._m.log:commitLog(key, params)
        end

        function UserAPI.prototype:commitChannelsLog(logType, params)
            if not self:checkModuleAttr("log", "commitChannelsLog", "function") then
                return self:createNonePromise("[log.commitChannelsLog]")
            end
            return self._m.log:commitChannelsLog(logType, params)
        end

        --[[
		 * 付费打点
		 * @param index 1-6  代表6种不同金额
		--]]
        function UserAPI.prototype:commitPayLog(index)
            if not self:checkModuleAttr("log", "commitPayLog", "function") then
                return nil
            end
            return self._m.log:commitPayLog(index)
        end

        --[[
		 * 添加本地推送
		--]]
        function UserAPI.prototype:addLocalNotices(notices)
            if not self:checkModuleAttr("localPush", "addLocalNotices", "function") then
                return self:createNonePromise("[localPush.addLocalNotices]")
            end
            return self._m.localPush:addLocalNotices(notices)
        end

        --[[
		 * 移除对应的推送
		--]]
        function UserAPI.prototype:removeLocalNoticeWithID(params)
            if not self:checkModuleAttr("localPush", "removeLocalNoticeWithID", "function") then
                return self:createNonePromise("[localPush.removeLocalNoticeWithID]")
            end
            return self._m.localPush:removeLocalNoticeWithID(params)
        end

        --[[
		 * 移除所有推送
		--]]
        function UserAPI.prototype:removeAllLocalNotices()
            if not self:checkModuleAttr("localPush", "removeAllLocalNotices", "function") then
                return self:createNonePromise("[localPush.removeAllLocalNotices]")
            end
            return self._m.localPush:removeAllLocalNotices()
        end

        --[[
		 * 检查推送设置，如果没有权限则提示用户跳转开启
		--]]
        function UserAPI.prototype:requireLocalNoticePermission()
            if not self:checkModuleAttr("localPush", "requireLocalNoticePermission", "function") then
                return self:createNonePromise("[localPush.requireLocalNoticePermission]")
            end
            return self._m.localPush:requireLocalNoticePermission()
        end

        --[[
		 * 用户是否开启通知权限
		--]]
        function UserAPI.prototype:isLocalNoticeEnabled()
            if not self:checkModuleAttr("localPush", "isLocalNoticeEnabled", "function") then
                return self:createNonePromise("[localPush.isLocalNoticeEnabled]")
            end
            return self._m.localPush:isLocalNoticeEnabled()
        end

        return UserAPI
    end)()
    GDK.UserAPI = UserAPI

    GDK.UserAPI = UserAPI
end)(GDK)

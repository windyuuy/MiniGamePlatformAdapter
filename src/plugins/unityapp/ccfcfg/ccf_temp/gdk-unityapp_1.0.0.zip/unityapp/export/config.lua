local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    local defaultGDKName = ""
    GDK.defaultGDKName = defaultGDKName
    GDK.defaultGDKName = defaultGDKName
end)(GDK)
window["GDK"] = GDK

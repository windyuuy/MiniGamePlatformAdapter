local KeyBoard
local Widgets

local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local devlog = Common.devlog

    KeyBoard =
        (function(super)
        local KeyBoard = declareClass("KeyBoard", super)

        KeyBoard.prototype.hideKeyboard =
            __JS_Async(
            function(self)
                devlog:info("hideKeyboard")
            end
        )
        function KeyBoard.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return KeyBoard
    end)(GDK.IKeyBoard)

    Widgets =
        (function(super)
        local Widgets = declareClass("Widgets", super)

        function Widgets.prototype:init(data)
            setTimeout(
                function()
                    self.api:hideLaunchingView()
                end
            )
        end

        Widgets.prototype.showLoading =
            __JS_Async(
            function(self, object)
                devlog:info("showLoading")
            end
        )

        Widgets.prototype.hideLoading =
            __JS_Async(
            function(self)
                devlog:info("hideLoading")
            end
        )

        Widgets.prototype.showToast =
            __JS_Async(
            function(self, object)
                devlog:info("showToast")
            end
        )

        Widgets.prototype.hideToast =
            __JS_Async(
            function(self)
                devlog:info("hideToast")
            end
        )

        function Widgets.prototype:showConfirm(object)
            return Promise(
                function(resolve, reject)
                    gdkjsb:showConfirm(
                        object.content,
                        object.title or slib.i18n:locSDKString("remind_tip"),
                        object.okLabel or slib.i18n:locSDKString("ok"),
                        object.cancelLabel or slib.i18n:locSDKString("cancel"),
                        function(isOk)
                            local r = GDK.ShowConfirmResult()
                            r.confirm = isOk == true
                            r.cancel = isOk == false
                            resolve(r)
                        end
                    )
                end
            )
        end

        function Widgets.prototype:showAlert(object)
            return Promise(
                function(resolve, reject)
                    gdkjsb:showAlert(
                        object.content,
                        object.title or slib.i18n:locSDKString("remind_tip"),
                        object.okLabel or slib.i18n:locSDKString("ok"),
                        function()
                            local r = GDK.ShowAlertResult()
                            resolve(r)
                        end
                    )
                end
            )
        end

        function Widgets.prototype:showPrompt(object)
            return Promise(
                function(resolve, reject)
                    if gdkjsb.showPrompt == nil then
                        local r = GDK.ShowPromptResult()
                        r.cancel = true
                        r.confirm = false
                        r.result = nil
                        resolve(r)
                        return
                    end
                    gdkjsb:showPrompt(
                        object.content,
                        object.title or slib.i18n:locSDKString("remind_tip"),
                        object.okLabel or slib.i18n:locSDKString("ok"),
                        object.cancelLabel or slib.i18n:locSDKString("cancel"),
                        function(isOk, result)
                            local r = GDK.ShowPromptResult()
                            r.confirm = isOk == true
                            r.cancel = isOk == false
                            r.result = result
                            resolve(r)
                        end,
                        object.defaultValue or ""
                    )
                end
            )
        end

        Widgets.prototype.hideLaunchingView =
            __JS_Async(
            function(self)
                SDKProxy:hideLaunchingView()
            end
        )
        function Widgets.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.api = nil
            self.keyboard = KeyBoard()

            --constructor logic
        end

        return Widgets
    end)(GDK.IWidgets)
    UnityAppGDK.Widgets = Widgets

    UnityAppGDK.Widgets = Widgets
end)(UnityAppGDK)

local MServer
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    MServer =
        (function(super)
        local MServer = declareClass("MServer", super)
        function MServer.prototype:__getter__gameClient()
            return Common.httpClient
        end

        --[[
			 * 用户登录接口(用户首次进入游戏调用)
			--]]
        function MServer.prototype:loginTest(data, callback, errorCallback)
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginTest",
                data,
                function(data)
                    callback(data)
                end,
                {modal = false, errorCallback = errorCallback}
            )
        end

        function MServer.prototype:userLogin(data, callback, errorCallback)
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/login",
                data,
                function(data)
                    callback(data)
                end,
                {errorCallback = errorCallback}
            )
        end

        --[[
         * 游客登陆
         * * openId 传入空则产生新的账号
         * * 传入历史openId则表示游客再次登陆
        --]]
        function MServer.prototype:loginOpenId(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginOpenId",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
         * FB登陆
         * * userId 
         * * token
        --]]
        function MServer.prototype:loginFB(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginFB",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
         * quick登陆
         * * userId 
         * * token
		 * * channleId
        --]]
        function MServer.prototype:loginQuick(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginQuick",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
         * huawei登陆
         * * userId 
         * * token
		 * * channleId
        --]]
        function MServer.prototype:loginHuawei(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginHwApp",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
         * 虫虫登陆
        --]]
        function MServer.prototype:loginChongchong(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginCcApp",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
         * 路非凡登陆
        --]]
        function MServer.prototype:loginLufeifan(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginLffApp",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
         * 京游登陆
        --]]
        function MServer.prototype:loginJingyou(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginJinYouApp",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
         * xiao7登陆
         * * token
        --]]
        function MServer.prototype:loginXiao7(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginX7App",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
         * WX app登陆
         * * userId 
         * * token
        --]]
        function MServer.prototype:loginAppWX(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginAppWx",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
         * WX app android 登陆
         * * userId 
         * * token
        --]]
        function MServer.prototype:loginAppWXAndroid(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginAppWxAndroid",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
         * WX app android 登陆
         * * userId 
         * * token
        --]]
        function MServer.prototype:loginVivo(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginVivoApp",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
         * WX app android 登陆
         * * userId 
         * * token
        --]]
        function MServer.prototype:loginOppoApp(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginOppoApp",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
         * WX app android 登陆
         * * userId 
         * * token
        --]]
        function MServer.prototype:loginYYBApp(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginYybApp",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        function MServer.prototype:loginMeituApp(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginMtApp",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
		 * WX app android 登陆
		 * * userId 
		 * * token
		--]]
        function MServer.prototype:loginBaidu(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginOpenId",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
		 * 阿里九游 登陆
		 * * userId 
		 * * token
		--]]
        function MServer.prototype:loginAligame(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginJyApp",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
         * FB登陆
         * * userId 
         * * token
        --]]
        function MServer.prototype:loginGC(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginGC",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        --[[
         * FB登陆
         * * userId 
         * * token
        --]]
        function MServer.prototype:loginGoogle(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginGoogle",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        function MServer.prototype:loginAccount(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/loginAccount",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end

        function MServer.prototype:bindingAccount(data, callback, modal, errorCallback)
            if modal == nil then
                modal = false
            end
            if errorCallback == nil then
                errorCallback = nil
            end
            self.gameClient:request(
                "user/bindingAccount",
                data,
                function(data)
                    callback(data)
                end,
                {modal = modal, errorCallback = errorCallback}
            )
        end
        function MServer.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return MServer
    end)(GDK.APIServer)
    MServer.inst = MServer()

    UnityAppGDK.MServer = MServer

    UnityAppGDK.MServer = MServer
end)(UnityAppGDK)

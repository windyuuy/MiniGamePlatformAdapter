local Share
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local devlog = Common.devlog

    Share =
        (function(super)
        local Share = declareClass("Share", super)

        Share.prototype.share =
            __JS_Async(
            function(self, data)
                local d = ""
                if data.data then
                    d = JSON:stringify(data.data)
                end
                local result = __JS_Await(self.api:showConfirm({content = "请点击一下按钮决定是否分享成功。" .. d, title = "分享测试"}))
                local r = GDK.ShareResult()
                r.isGroup = false
                r.result = (result) and (0) or (2)
                return r
            end
        )

        Share.prototype.socialShare =
            __JS_Async(
            function(self, data)
                return self:share(data)
            end
        )

        Share.prototype.shareUrl =
            __JS_Async(
            function(self, data)
                __JS_Await(self.api:showAlert({content = "分享了一个url：" .. data.url, title = "分享测试"}))
                local d = GDK.ShareResult()
                d.result = 0
                return d
            end
        )

        Share.prototype.showShareMenu =
            __JS_Async(
            function(self)
                devlog:info("showShareMenu")
            end
        )

        Share.prototype.hideShareMenu =
            __JS_Async(
            function(self)
                devlog:info("showShareMenu")
            end
        )

        Share.prototype.setShareMenuData =
            __JS_Async(
            function(self, data)
                devlog:info("showShareMenu", data)
            end
        )

        Share.prototype.getShareParam =
            __JS_Async(
            function(self)
                devlog:info("getShareParam")
                return nil
            end
        )

        Share.prototype.getShareInfo =
            __JS_Async(
            function(self, shareTicket)
                return nil
            end
        )

        Share.prototype.getShareTicket =
            __JS_Async(
            function(self)
                return ""
            end
        )
        function Share.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.api = nil

            --constructor logic
        end

        return Share
    end)(GDK.IShare)
    UnityAppGDK.Share = Share

    UnityAppGDK.Share = Share
end)(UnityAppGDK)

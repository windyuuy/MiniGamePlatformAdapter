local FullscreenVedioAd
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local devlog = Common.devlog

    FullscreenVedioAd =
        (function(super)
        local FullscreenVedioAd = declareClass("FullscreenVedioAd", super)

        function FullscreenVedioAd.prototype:constructor(params, api)
            --member properties
            self.api = nil
            self._loadFuncList = Array({})
            self._errorFuncList = Array({})
            self._closeFuncList = Array({})
            self._isLoad = false
            self._isShowing = false
            self.adUnitId = nil
            self._isEnded = false
            self._onLoadedCallbacks = Array({})
            self._available = false

            --constructor parameters

            --constructor logic

            self.adUnitId = params.adUnitId
            self.api = api

            SDKProxy.nativeAdvert:onFullScreenVideoAvailabilityChanged(
                function(data)
                    self:onFullScreenVideoAvailabilityChanged(data.available)
                end
            )

            SDKProxy.nativeAdvert:onFullScreenVideoAdComplete(
                function(data)
                    self:onFullScreenVideoAdComplete()
                end
            )
            SDKProxy.nativeAdvert:onFullScreenVideoAdClosed(
                function(data)
                    -- 避免可能的黑屏
                    setTimeout(
                        function()
                            self:onFullScreenVideoAdClosed(data)
                        end,
                        0
                    )
                end
            )

            SDKProxy.nativeAdvert:onFullScreenVideoAdShowFailed(
                function(error)
                    self:onFullScreenVideoAdShowFailed(error)
                end
            )
        end

        function FullscreenVedioAd.prototype:onFullScreenVideoAdShowFailed(error)
            self._isShowing = false

            local err = GDK.FullscreenAdOnErrorParam()
            err.errCode = error.errorCode or error["code"]
            err.errMsg = error.errorMsg or error["message"] --有的平台没有按正确的格式上传信息
            do
                local ___temp = self._errorFuncList:concat()
                for ___i = 0, ___temp.length - 1 do
                    local f = ___temp[___i]

                    f(err)
                end
            end
        end

        function FullscreenVedioAd.prototype:onFullScreenVideoAdComplete()
            self._isEnded = true
        end

        function FullscreenVedioAd.prototype:onFullScreenVideoAdClosed(data)
            data = data or {}

            self._isShowing = false

            local isEnded = self._isEnded
            self._isEnded = false

            -- 如果有直接的参数，优先使用参数
            if data.couldReward ~= nil then
                isEnded = not (not data.couldReward)
            end

            do
                local ___temp = self._closeFuncList:concat()
                for ___i = 0, ___temp.length - 1 do
                    local f = ___temp[___i]

                    __JS_Try(
                        function()
                            f({isEnded = isEnded})
                        end,
                        function(e)
                            devlog:error("视频广告发放奖励回调异常：", e)
                        end
                    )
                end
            end

            setTimeout(
                __JS_Async(
                    function()
                        -- ironsource广告只要第一次加载到，后面如果没有加载
                        local available = __JS_Await(SDKProxy.nativeAdvert:isFullScreenVideoAvailable()).available
                        self:onFullScreenVideoAvailabilityChanged(available)
                    end
                ),
                0
            )
        end
        function FullscreenVedioAd.prototype:__getter__isAvailable()
            return self._available
        end

        FullscreenVedioAd.prototype.checkAvailable =
            __JS_Async(
            function(self)
                local available = __JS_Await(SDKProxy.nativeAdvert:isFullScreenVideoAvailable()).available
                self._available = available
                return available
            end
        )

        function FullscreenVedioAd.prototype:onFullScreenVideoAvailabilityChanged(available)
            self._available = available
            if available then
                -- load() promise 回调
                local onLoadedCallbacks = self._onLoadedCallbacks
                -- 清空避免重复 promise
                self._onLoadedCallbacks = Array({})
                do
                    local ___temp = onLoadedCallbacks:concat()
                    for ___i = 0, ___temp.length - 1 do
                        local f = ___temp[___i]

                        __JS_Try(
                            function()
                                f()
                            end,
                            function(e)
                                devlog:error("广告已加载 promise 回调异常：", e)
                            end
                        )
                    end
                end

                __JS_Try(
                    function()
                        -- onLoaded 回调
                        do
                            local ___temp = self._loadFuncList:concat()
                            for ___i = 0, ___temp.length - 1 do
                                local f = ___temp[___i]

                                f()
                            end
                        end
                    end,
                    function(e)
                        devlog:error("广告 onLoad 回调中发生异常:", e)
                    end
                )
            end
        end

        FullscreenVedioAd.prototype.load =
            __JS_Async(
            function(self)
                local ret = GDK.RPromise()
                local available = __JS_Await(SDKProxy.nativeAdvert:isFullScreenVideoAvailable()).available
                self._available = available
                if self._available then
                    ret:success(nil)

                    -- 和微信一致，每次 load 都调用 onLoad
                    self:onFullScreenVideoAvailabilityChanged(self._available)
                else
                    self._onLoadedCallbacks:push(
                        function()
                            ret:success(nil)
                        end
                    )
                    __JS_Await(SDKProxy.nativeAdvert:loadFullScreenVideoAd())
                end
                return ret.promise
            end
        )

        FullscreenVedioAd.prototype.show =
            __JS_Async(
            function(self)
                devlog:info("ironsrc:show video advert")
                self._isShowing = true

                local waitting = true
                local ret = GDK.RPromise()
                -- 5秒没有播出来，那么就报超时错误
                setTimeout(
                    function()
                        if not waitting then
                            return
                        end
                        waitting = false
                        ret:fail(GDK.GDKResultTemplates:make(GDK.GDKErrorCode.API_SHOW_ADVERT_TIMEOUT))
                    end,
                    5000
                )
                SDKProxy.nativeAdvert:showFullScreenVideo({placementName = "DefaultFullScreenVideo"}):_then_(
                    function()
                        if not waitting then
                            return
                        end
                        waitting = false
                        ret:success()
                    end
                ):catch(
                    function(e)
                        if not waitting then
                            return
                        end
                        waitting = false
                        ret:fail(e)
                    end
                )
                return ret.promise
            end
        )

        function FullscreenVedioAd.prototype:onLoad(callback)
            self._loadFuncList:push(callback)
        end

        function FullscreenVedioAd.prototype:offLoad(callback)
            self._loadFuncList:splice(self._loadFuncList:indexOf(callback), 1)
        end

        function FullscreenVedioAd.prototype:onError(callback)
            self._errorFuncList:push(callback)
        end

        function FullscreenVedioAd.prototype:offError(callback)
            self._errorFuncList:splice(self._errorFuncList:indexOf(callback), 1)
        end

        function FullscreenVedioAd.prototype:onClose(callback)
            self._closeFuncList:push(callback)
        end

        function FullscreenVedioAd.prototype:offClose(callback)
            self._closeFuncList:splice(self._closeFuncList:indexOf(callback), 1)
        end

        return FullscreenVedioAd
    end)(GDK.IFullscreedVideoAd)
    UnityAppGDK.FullscreenVedioAd = FullscreenVedioAd

    UnityAppGDK.FullscreenVedioAd = FullscreenVedioAd
end)(UnityAppGDK)

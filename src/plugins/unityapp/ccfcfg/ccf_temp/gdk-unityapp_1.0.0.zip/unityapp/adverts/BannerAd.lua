local BannerAd
--/ <reference path="../Common.ts" />
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local devlog = Common.devlog

    BannerAd =
        (function(super)
        local BannerAd = declareClass("BannerAd", super)
        function BannerAd.prototype:__getter__style()
            return self._style
        end
        function BannerAd.prototype:__setter__style(value)
            self._style = value
            SDKProxy.nativeAdvert:setBannerStyle(value)
        end

        function BannerAd.prototype:constructor(params)
            --member properties
            self.adUnitId = nil
            self.viewId = nil
            self.placementName = nil
            self._style = GDK.BannerStyleAccessor()
            self._loadFuncList = Array({})
            self._errorFuncList = Array({})
            self._resizeFuncList = Array({})

            --constructor parameters

            --constructor logic

            SDKProxy.nativeAdvert:createBanner(params)
            SDKProxy.nativeAdvert:setBannerListener()
            SDKProxy.nativeAdvert:loadBanner(params)

            self.style.x = params.style.x
            self.style.y = params.style.y
            self.style.left = params.style.left
            self.style.top = params.style.top

            SDKProxy.nativeAdvert:onBannerAdLoaded(
                function()
                    self:onBannerAdLoaded()
                end
            )
            SDKProxy.nativeAdvert:onBannerAdLoadFailed(
                function(error)
                    self:onBannerAdLoadFailed(error)
                end
            )
            SDKProxy.nativeAdvert:onBannerAdLoadFailed(
                function(error)
                    self:onBannerAdLoadFailed(error)
                end
            )
        end

        function BannerAd.prototype:reset(params)
            self:destroy()
            SDKProxy.nativeAdvert:createBanner(params)
            SDKProxy.nativeAdvert:loadBanner(params)
            self.style.x = params.style.x
            self.style.y = params.style.y
            self.style.left = params.style.left
            self.style.top = params.style.top
        end

        function BannerAd.prototype:onBannerAdLoaded()
            do
                local ___temp = self._loadFuncList:concat()
                for ___i = 0, ___temp.length - 1 do
                    local f = ___temp[___i]

                    __JS_Try(
                        function()
                            f()
                        end,
                        function(e)
                            devlog:error("条幅广告加载成功回调异常", e)
                        end
                    )
                end
            end
        end

        function BannerAd.prototype:onBannerAdLoadFailed(error)
            local err = GDK.RewardedVideoAdOnErrorParam()
            err.errCode = error.errorCode
            err.errMsg = error.errorMsg
            do
                local ___temp = self._errorFuncList:concat()
                for ___i = 0, ___temp.length - 1 do
                    local f = ___temp[___i]

                    f(err)
                end
            end
        end

        BannerAd.prototype.show =
            __JS_Async(
            function(self)
                __JS_Await(SDKProxy.nativeAdvert:setBannerAdvertVisibility({visible = true}))
            end
        )

        BannerAd.prototype.hide =
            __JS_Async(
            function(self)
                __JS_Await(SDKProxy.nativeAdvert:setBannerAdvertVisibility({visible = false}))
            end
        )

        BannerAd.prototype.destroy =
            __JS_Async(
            function(self)
                __JS_Await(SDKProxy.nativeAdvert:destroyBanner())
            end
        )

        function BannerAd.prototype:onResize(callback)
            self._resizeFuncList:push(callback)
        end

        function BannerAd.prototype:offResize(callback)
            self._resizeFuncList:splice(self._resizeFuncList:indexOf(callback), 1)
        end

        function BannerAd.prototype:onLoad(callback)
            self._loadFuncList:push(callback)
        end

        function BannerAd.prototype:offLoad(callback)
            self._loadFuncList:splice(self._loadFuncList:indexOf(callback), 1)
        end

        function BannerAd.prototype:onError(callback)
            self._errorFuncList:push(callback)
        end

        function BannerAd.prototype:offError(callback)
            self._errorFuncList:splice(self._errorFuncList:indexOf(callback), 1)
        end

        return BannerAd
    end)(GDK.IBannerAd)
    UnityAppGDK.BannerAd = BannerAd

    UnityAppGDK.BannerAd = BannerAd
end)(UnityAppGDK)

local FeedAd
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local devlog = Common.devlog

    FeedAd =
        (function(super)
        local FeedAd = declareClass("FeedAd", super)

        function FeedAd:_initListeners()
            if self._inited then
                return
            end
            self._inited = true

            SDKProxy.nativeAdvert:onFeedAdLoaded(
                function(params)
                    self._onFeedAdLoadedCallbacks:concat():forEach(
                        function(f)
                            __JS_Try(
                                function()
                                    f(params)
                                end,
                                function(e)
                                    console:error(e)
                                end
                            )
                        end
                    )
                end
            )

            SDKProxy.nativeAdvert:onFeedAdLoadFailed(
                function(params)
                    self._onFeedAdLoadFailedCallbacks:concat():forEach(
                        function(f)
                            __JS_Try(
                                function()
                                    f(params)
                                end,
                                function(e)
                                    console:error(e)
                                end
                            )
                        end
                    )
                end
            )
        end

        function FeedAd.prototype:onFeedAdLoaded(f)
            local callbacks = FeedAd._onFeedAdLoadedCallbacks
            local index = callbacks:indexOf(f)
            if f and index <= 0 then
                callbacks:push(f)
            end
        end

        function FeedAd.prototype:offFeedAdLoaded(f)
            local callbacks = FeedAd._onFeedAdLoadedCallbacks
            local index = callbacks:indexOf(f)
            if index >= 0 then
                callbacks:splice(index, 1)
            end
        end

        function FeedAd.prototype:onFeedAdLoadFailed(f)
            local callbacks = FeedAd._onFeedAdLoadFailedCallbacks
            local index = callbacks:indexOf(f)
            if f and index <= 0 then
                callbacks:push(f)
            end
        end

        function FeedAd.prototype:offFeedAdLoadFailed(f)
            local callbacks = FeedAd._onFeedAdLoadFailedCallbacks
            local index = callbacks:indexOf(f)
            if index >= 0 then
                callbacks:splice(index, 1)
            end
        end
        function FeedAd.prototype:__getter__style()
            return self._style
        end
        function FeedAd.prototype:__setter__style(value)
            self._style = value
            SDKProxy.nativeAdvert:setFeedAdStyle({adObjectId = self.adObjectId, style = self._style})
        end

        FeedAd.prototype.setStyle =
            __JS_Async(
            function(self, style)
                for key, _ in pairs(style) do
                    local value = style[key]
                    if value ~= nil then
                        self._style[key] = value
                    end
                end

                __JS_Await(SDKProxy.nativeAdvert:setFeedAdStyle({adObjectId = self.adObjectId, style = self._style}))

                local datas = __JS_Await(SDKProxy.nativeAdvert:getFeedAdDatas({adObjectId = self.adObjectId}))
                self._style.realHeight = datas.style.realHeight
                self._style.realWidth = datas.style.realWidth
            end
        )

        FeedAd.prototype.setDefaultClickZoneStyle =
            __JS_Async(
            function(self, style)
                __JS_Await(SDKProxy.nativeAdvert:setFeedAdClickZoneStyle({adObjectId = self.adObjectId, style = style}))
            end
        )

        function FeedAd.prototype:constructor(params)
            --member properties
            self._style = GDK.FeedAdStyleAccessor()
            self.adObjectId = -1
            self.isDebugMode = false

            --constructor parameters

            --constructor logic

            self.isDebugMode = params.isDebugMode

            local style = params.style
            if style ~= nil then
                self.style.x = style.x
                self.style.y = style.y
                self.style.left = style.left
                self.style.top = style.top
            end

            FeedAd:_initListeners()
        end

        FeedAd.prototype.load =
            __JS_Async(
            function(self)
                local adObjectId =
                    __JS_Await(SDKProxy.nativeAdvert:createFeedAd({style = self.style, isDebugMode = self.isDebugMode})).adObjectId
                self.adObjectId = adObjectId

                local onLoadPromise =
                    Promise(
                    function(resolve, reject)
                        local _onFeedAdLoadedCallback = function(params)
                            self:offFeedAdLoaded(_onFeedAdLoadedCallback)

                            if self.adObjectId == params.adObjectId then
                                resolve()
                            end
                        end

                        local _onFeedAdLoadFailedCallback = function(params)
                            self:offFeedAdLoadFailed(_onFeedAdLoadFailedCallback)

                            if self.adObjectId == params.adObjectId then
                                reject(Error(params.error.errorMsg))
                            end
                        end
                        self:onFeedAdLoaded(_onFeedAdLoadedCallback)
                        self:onFeedAdLoadFailed(_onFeedAdLoadFailedCallback)
                    end
                )

                __JS_Await(SDKProxy.nativeAdvert:loadFeedAd({adObjectId = adObjectId}))
                __JS_Await(SDKProxy.nativeAdvert:setFeedAdStyle({adObjectId = adObjectId, style = self._style}))
                __JS_Await(onLoadPromise)

                local datas = __JS_Await(SDKProxy.nativeAdvert:getFeedAdDatas({adObjectId = self.adObjectId}))
                self._style.realHeight = datas.style.realHeight
                self._style.realWidth = datas.style.realWidth
            end
        )

        FeedAd.prototype.show =
            __JS_Async(
            function(self)
                __JS_Await(SDKProxy.nativeAdvert:setFeedAdVisibility({adObjectId = self.adObjectId, visible = true}))
            end
        )

        FeedAd.prototype.hide =
            __JS_Async(
            function(self)
                __JS_Await(SDKProxy.nativeAdvert:setFeedAdVisibility({adObjectId = self.adObjectId, visible = false}))
            end
        )

        FeedAd.prototype.destroy =
            __JS_Async(
            function(self)
                return __JS_Await(SDKProxy.nativeAdvert:destroyFeedAd({adObjectId = self.adObjectId}))
            end
        )

        FeedAd.prototype.getDatas =
            __JS_Async(
            function(self)
                return __JS_Await(SDKProxy.nativeAdvert:getFeedAdDatas({adObjectId = self.adObjectId}))
            end
        )

        --[[
		 * 模拟点击广告
		--]]
        FeedAd.prototype.performClick =
            __JS_Async(
            function(self)
                return __JS_Await(SDKProxy.nativeAdvert:performClick({adObjectId = self.adObjectId}))
            end
        )

        --[[
		 * 模拟点击广告
		--]]
        FeedAd.prototype.performCreativeClick =
            __JS_Async(
            function(self)
                return __JS_Await(SDKProxy.nativeAdvert:performCreativeClick({adObjectId = self.adObjectId}))
            end
        )

        return FeedAd
    end)(GDK.IFeedAd)

    FeedAd._onFeedAdLoadedCallbacks = Array({})

    FeedAd._onFeedAdLoadFailedCallbacks = Array({})

    FeedAd._inited = false

    UnityAppGDK.FeedAd = FeedAd

    UnityAppGDK.FeedAd = FeedAd
end)(UnityAppGDK)

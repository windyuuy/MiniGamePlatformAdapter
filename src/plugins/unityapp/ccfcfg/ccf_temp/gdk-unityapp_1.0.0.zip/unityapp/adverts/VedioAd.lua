local VideoAd
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local devlog = Common.devlog

    VideoAd =
        (function(super)
        local VideoAd = declareClass("VideoAd", super)

        function VideoAd.prototype:constructor(params, api)
            --member properties
            self.api = nil
            self._loadFuncList = Array({})
            self._errorFuncList = Array({})
            self._closeFuncList = Array({})
            self._isLoad = false
            self._isShowing = false
            self.adUnitId = nil
            self._isEnded = false
            self._onLoadedCallbacks = Array({})
            self._available = false
            self.placementId = nil

            --constructor parameters

            --constructor logic

            self.adUnitId = params.adUnitId
            self.api = api

            SDKProxy.nativeAdvert:onRewardedVideoAvailabilityChanged(
                function(data)
                    self:onRewardedVideoAvailabilityChanged(data.available)
                end
            )

            SDKProxy.nativeAdvert:onRewardedVideoAdRewarded(
                function(data)
                    self:onRewardedVideoAdRewarded()
                end
            )
            SDKProxy.nativeAdvert:onRewardedVideoAdClosed(
                function(data)
                    -- 避免可能的黑屏
                    setTimeout(
                        function()
                            self:onRewardedVideoAdClosed(data)
                        end,
                        0
                    )
                end
            )

            SDKProxy.nativeAdvert:onRewardedVideoAdOpened(
                function()
                    self:onRewardedVideoAdOpened()
                end
            )
            SDKProxy.nativeAdvert:onRewardedVideoAdShowFailed(
                function(error)
                    self:onRewardedVideoAdShowFailed(error)
                end
            )
        end

        function VideoAd.prototype:onRewardedVideoAdOpened()
        end

        function VideoAd.prototype:onRewardedVideoAdShowFailed(error)
            self._isShowing = false

            local err = GDK.RewardedVideoAdOnErrorParam()
            err.errCode = error.errorCode
            err.errMsg = error.errorMsg
            do
                local ___temp = self._errorFuncList:concat()
                for ___i = 0, ___temp.length - 1 do
                    local f = ___temp[___i]

                    f(err)
                end
            end

            self:onApplyLoadedCallbacks(false)
        end

        function VideoAd.prototype:onApplyLoadedCallbacks(isOk)
            -- load() promise 回调
            local onLoadedCallbacks = self._onLoadedCallbacks
            -- 清空避免重复 promise
            self._onLoadedCallbacks = Array({})
            do
                local ___temp = onLoadedCallbacks:concat()
                for ___i = 0, ___temp.length - 1 do
                    local f = ___temp[___i]

                    __JS_Try(
                        function()
                            f(isOk)
                        end,
                        function(e)
                            if isOk then
                                devlog:error("广告已加载 promise 回调异常：", e)
                            else
                                devlog:error("广告加载失败 promise 回调异常：", e)
                            end
                        end
                    )
                end
            end
        end

        function VideoAd.prototype:onRewardedVideoAdRewarded()
            self._isEnded = true
        end

        function VideoAd.prototype:onRewardedVideoAdClosed(data)
            data = data or {}
            self._isShowing = false

            local isEnded = self._isEnded
            self._isEnded = false

            -- 如果有直接的参数，优先使用参数
            if data.couldReward ~= nil then
                isEnded = not (not data.couldReward)
            end

            do
                local ___temp = self._closeFuncList:concat()
                for ___i = 0, ___temp.length - 1 do
                    local f = ___temp[___i]

                    __JS_Try(
                        function()
                            f({isEnded = isEnded})
                        end,
                        function(e)
                            devlog:error("视频广告发放奖励回调异常：", e)
                        end
                    )
                end
            end

            setTimeout(
                __JS_Async(
                    function()
                        -- ironsource广告只要第一次加载到，后面如果没有加载
                        local available = __JS_Await(SDKProxy.nativeAdvert:isRewardedVideoAvailable()).available
                        self:onRewardedVideoAvailabilityChanged(available)
                    end
                ),
                0
            )
        end
        function VideoAd.prototype:__getter__isAvailable()
            return self._available
        end

        --[[
		 * 调用异步原生接口获取`原生`视频广告是否加载成功
		--]]
        VideoAd.prototype.checkAvailable =
            __JS_Async(
            function(self, loadParams)
                local available = __JS_Await(SDKProxy.nativeAdvert:isRewardedVideoAvailable(loadParams)).available
                self._available = available
                return available
            end
        )

        function VideoAd.prototype:onRewardedVideoAvailabilityChanged(available)
            self._available = available
            if available then
                -- -- load() promise 回调
                -- let onLoadedCallbacks = this._onLoadedCallbacks
                -- -- 清空避免重复 promise
                -- this._onLoadedCallbacks = []
                -- for (let f of onLoadedCallbacks.concat()) {
                -- 	try {
                -- 		f(true)
                -- 	} catch (e) {
                -- 		devlog.error('广告已加载 promise 回调异常：', e)
                -- 	}
                -- }
                self:onApplyLoadedCallbacks(true)

                __JS_Try(
                    function()
                        -- onLoaded 回调
                        do
                            local ___temp = self._loadFuncList:concat()
                            for ___i = 0, ___temp.length - 1 do
                                local f = ___temp[___i]

                                f()
                            end
                        end
                    end,
                    function(e)
                        devlog:error("广告 onLoad 回调中发生异常:", e)
                    end
                )
            end
        end

        VideoAd.prototype.load =
            __JS_Async(
            function(self, loadParams)
                loadParams = loadParams or {}
                loadParams.placementId = loadParams.placementId or self.adUnitId
                local ret = GDK.RPromise()
                --[[ 避免重复调用load--]]
                local isLoading = false
                if self.placementId ~= loadParams.placementId then
                    self.placementId = loadParams.placementId
                    isLoading = true
                    __JS_Await(SDKProxy.nativeAdvert:loadRewardVideoAd(loadParams))
                end
                local available = __JS_Await(SDKProxy.nativeAdvert:isRewardedVideoAvailable()).available
                self._available = available
                if self._available then
                    ret:success(nil)

                    -- 和微信一致，每次 load 都调用 onLoad
                    self:onRewardedVideoAvailabilityChanged(self._available)
                else
                    self._onLoadedCallbacks:push(
                        function(isOk)
                            if isOk then
                                ret:success(nil)
                            else
                                ret:fail(nil)
                            end
                        end
                    )
                    if not isLoading then
                        __JS_Await(SDKProxy.nativeAdvert:loadRewardVideoAd(loadParams))
                    end
                end
                return ret.promise
            end
        )

        VideoAd.prototype.show =
            __JS_Async(
            function(self, loadParams)
                devlog:info("ironsrc:show video advert")
                self._isShowing = true

                local waitting = true
                local ret = GDK.RPromise()
                -- 5秒没有播出来，那么就报超时错误
                setTimeout(
                    function()
                        if not waitting then
                            return
                        end
                        waitting = false
                        ret:fail(GDK.GDKResultTemplates:make(GDK.GDKErrorCode.API_SHOW_ADVERT_TIMEOUT))
                    end,
                    5000
                )
                SDKProxy.nativeAdvert:showRewardedVideo(
                    {placementName = (loadParams) and (loadParams.placementId) or ("DefaultRewardedVideo")}
                ):_then_(
                    function()
                        if not waitting then
                            return
                        end
                        waitting = false
                        ret:success()
                    end
                ):catch(
                    function(e)
                        if not waitting then
                            return
                        end
                        waitting = false
                        ret:fail(e)
                    end
                )
                return ret.promise
            end
        )

        function VideoAd.prototype:onLoad(callback)
            if self._loadFuncList:indexOf(callback) >= 0 then
                return
            end

            self._loadFuncList:push(callback)
        end

        function VideoAd.prototype:offLoad(callback)
            local index = self._loadFuncList:indexOf(callback)
            if index < 0 then
                return
            end
            self._loadFuncList:splice(index, 1)
        end

        function VideoAd.prototype:onError(callback)
            if self._errorFuncList:indexOf(callback) >= 0 then
                return
            end

            self._errorFuncList:push(callback)
        end

        function VideoAd.prototype:offError(callback)
            local index = self._errorFuncList:indexOf(callback)
            if index < 0 then
                return
            end
            self._errorFuncList:splice(index, 1)
        end

        function VideoAd.prototype:onClose(callback)
            if self._closeFuncList:indexOf(callback) >= 0 then
                return
            end

            self._closeFuncList:push(callback)
        end

        function VideoAd.prototype:offClose(callback)
            local index = self._closeFuncList:indexOf(callback)
            if index < 0 then
                return
            end

            self._closeFuncList:splice(index, 1)
        end

        return VideoAd
    end)(GDK.IRewardedVideoAd)
    UnityAppGDK.VideoAd = VideoAd

    UnityAppGDK.VideoAd = VideoAd
end)(UnityAppGDK)

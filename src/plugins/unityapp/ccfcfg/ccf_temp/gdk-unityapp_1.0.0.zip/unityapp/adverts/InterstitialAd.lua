local InterstitialAd
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local devlog = Common.devlog

    InterstitialAd =
        (function(super)
        local InterstitialAd = declareClass("InterstitialAd", super)

        function InterstitialAd.prototype:constructor(params, api)
            --member properties
            self.api = nil
            self._loadFuncList = Array({})
            self._errorFuncList = Array({})
            self._closeFuncList = Array({})
            self._isLoad = false
            self._isShowing = false
            self.adUnitId = nil
            self._isEnded = false
            self._onLoadedCallbacks = Array({})
            self._available = false
            self._onShownCallbacks = Array({})

            --constructor parameters

            --constructor logic

            self.adUnitId = params.adUnitId
            self.api = api

            SDKProxy.nativeAdvert:onInterstitialAdReady(
                function()
                    self:onInterstitialAvailabilityChanged(true)
                end
            )
            SDKProxy.nativeAdvert:onInterstitialAdLoadFailed(
                function(error)
                    self:onInterstitialAdLoadFailed(error)
                end
            )

            SDKProxy.nativeAdvert:onInterstitialAdRewarded(
                function(data)
                    self:onInterstitialAdRewarded()
                end
            )
            SDKProxy.nativeAdvert:onInterstitialAdClosed(
                function()
                    -- 避免可能的黑屏
                    setTimeout(
                        function()
                            self:onInterstitialAdClosed()
                        end,
                        0
                    )
                end
            )

            SDKProxy.nativeAdvert:onInterstitialAdOpened(
                function()
                    self:onInterstitialAdOpened()
                end
            )
            SDKProxy.nativeAdvert:onInterstitialAdShowFailed(
                function(error)
                    self:onInterstitialAdShowFailed(error)
                end
            )
            SDKProxy.nativeAdvert:onInterstitialAdShowSucceeded(
                function()
                    self:onInterstitialAdShowSucceeded()
                end
            )
        end

        function InterstitialAd.prototype:onReceivedError(error)
            local err = GDK.InterstitialAdOnErrorParam()
            err.errCode = error.errorCode
            err.errMsg = error.errorMsg
            do
                local ___temp = self._errorFuncList:concat()
                for ___i = 0, ___temp.length - 1 do
                    local f = ___temp[___i]

                    __JS_Try(
                        function()
                            f(err)
                        end,
                        function(e)
                            devlog:error("广告错误处理回调异常：", e)
                        end
                    )
                end
            end
        end

        function InterstitialAd.prototype:onInterstitialAdRewarded()
            self._isEnded = true
        end

        function InterstitialAd.prototype:onInterstitialAdClosed()
            self._isShowing = false

            local isEnded = self._isEnded
            self._isEnded = false
            do
                local ___temp = self._closeFuncList:concat()
                for ___i = 0, ___temp.length - 1 do
                    local f = ___temp[___i]

                    __JS_Try(
                        function()
                            f({isEnded = isEnded})
                        end,
                        function(e)
                            devlog:error("视频广告发放奖励回调异常：", e)
                        end
                    )
                end
            end

            setTimeout(
                __JS_Async(
                    function()
                        -- ironsource广告只要第一次加载到，后面如果没有加载
                        local available = __JS_Await(SDKProxy.nativeAdvert:isInterstitialReady()).available
                        self:onInterstitialAvailabilityChanged(available)
                    end
                ),
                0
            )
        end

        function InterstitialAd.prototype:onInterstitialAvailabilityChanged(available)
            self._available = available
            if available then
                -- load() promise 回调
                local onLoadedCallbacks = self._onLoadedCallbacks
                self._onLoadedCallbacks = Array({})
                do
                    local ___temp = onLoadedCallbacks:concat()
                    for ___i = 0, ___temp.length - 1 do
                        local f = ___temp[___i]

                        __JS_Try(
                            function()
                                f()
                            end,
                            function(e)
                                devlog:error("广告已加载回调异常：", e)
                            end
                        )
                    end
                end

                -- onLoaded 回调
                do
                    local ___temp = self._loadFuncList:concat()
                    for ___i = 0, ___temp.length - 1 do
                        local f = ___temp[___i]

                        f()
                    end
                end
            end
        end

        function InterstitialAd.prototype:onInterstitialAdLoadFailed(error)
            self:onInterstitialAvailabilityChanged(false)
            self:onReceivedError(error)
        end

        InterstitialAd.prototype.load =
            __JS_Async(
            function(self)
                devlog:info("ironsrc:load Interstitial video advert")
                local ret = GDK.RPromise()
                local available = __JS_Await(SDKProxy.nativeAdvert:isInterstitialReady()).available
                self._available = available
                if self._available then
                    ret:success(nil)
                else
                    __JS_Await(SDKProxy.nativeAdvert:loadInterstitial())
                    self._onLoadedCallbacks:push(
                        function()
                            ret:success(nil)
                        end
                    )
                end
                return ret.promise
            end
        )

        function InterstitialAd.prototype:onInterstitialAdOpened()
        end

        function InterstitialAd.prototype:onInterstitialAdShowSucceeded()
            local onShownCallbacks = self._onShownCallbacks
            self._onShownCallbacks = Array({})
            do
                local ___temp = onShownCallbacks:concat()
                for ___i = 0, ___temp.length - 1 do
                    local ret = ___temp[___i]

                    __JS_Try(
                        function()
                            ret:success()
                        end,
                        function(e)
                            devlog:error("广告播放成功回调异常：", e)
                        end
                    )
                end
            end
        end

        function InterstitialAd.prototype:onInterstitialAdShowFailed(error)
            self._isShowing = false

            local onShownCallbacks = self._onShownCallbacks
            self._onShownCallbacks = Array({})
            do
                local ___temp = onShownCallbacks:concat()
                for ___i = 0, ___temp.length - 1 do
                    local ret = ___temp[___i]

                    __JS_Try(
                        function()
                            ret:fail(error)
                        end,
                        function(e)
                            devlog:error("广告播放失败回调异常：", e)
                        end
                    )
                end
            end

            self:onReceivedError(error)
        end

        InterstitialAd.prototype.show =
            __JS_Async(
            function(self)
                devlog:info("ironsrc:show Interstitial video advert")
                self._isShowing = true

                local ret = GDK.RPromise()
                __JS_Await(SDKProxy.nativeAdvert:showInterstitial({placementName = "DefaultInterstitial"}))
                self._onShownCallbacks:push(ret)
                return ret.promise
            end
        )

        function InterstitialAd.prototype:onLoad(callback)
            self._loadFuncList:push(callback)
        end

        function InterstitialAd.prototype:offLoad(callback)
            self._loadFuncList:splice(self._loadFuncList:indexOf(callback), 1)
        end

        function InterstitialAd.prototype:onError(callback)
            self._errorFuncList:push(callback)
        end

        function InterstitialAd.prototype:offError(callback)
            self._errorFuncList:splice(self._errorFuncList:indexOf(callback), 1)
        end

        function InterstitialAd.prototype:onClose(callback)
            self._closeFuncList:push(callback)
        end

        function InterstitialAd.prototype:offClose(callback)
            self._closeFuncList:splice(self._closeFuncList:indexOf(callback), 1)
        end

        return InterstitialAd
    end)(GDK.IInterstitialAd)
    UnityAppGDK.InterstitialAd = InterstitialAd

    UnityAppGDK.InterstitialAd = InterstitialAd
end)(UnityAppGDK)

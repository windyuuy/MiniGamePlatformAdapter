local ServedLoginInfo
local LoginServerResult
local ServerData
local GameCurrency
local TableConf
local VerifiedInfo
local RecordData
local ServedBindInfo
local AdvertPreloadInfo
local AdvertType
local AdPlatformConfigs
local AdCreateInfo
local CreateAdUnitResult
local AdUnitQueryInfo
local AdUnitOpInfo
local ShowAdUnitOpInfo
local ShowAdUnityResult
local SetAdUnitStyleInfo
local AdUnitStyle
local AdUnitStatus
local AdUnitInfo
local AdvertEvent

local AppGDK = AppGDK or {}
_G.AppGDK = AppGDK
local _ = (function(AppGDK)
    extendsNSList({AppGDK, _G})

    ServedLoginInfo = (function(super)
        local ServedLoginInfo = declareClass("ServedLoginInfo", super)
        function ServedLoginInfo.prototype:constructor()
            --member properties
            self.loginNode = nil
        end

        return ServedLoginInfo
    end)()
    AppGDK.ServedLoginInfo = ServedLoginInfo

    AppGDK.ServedLoginInfo = ServedLoginInfo

    LoginServerResult = (function(super)
        local LoginServerResult = declareClass("LoginServerResult", super)
        function LoginServerResult.prototype:constructor()
            --member properties
            self.rawData = nil
            self.serverData = nil
            self.recordData = nil
        end

        return LoginServerResult
    end)()
    AppGDK.LoginServerResult = LoginServerResult

    AppGDK.LoginServerResult = LoginServerResult

    ServerData = (function(super)
        local ServerData = declareClass("ServerData", super)
        function ServerData.prototype:constructor()
            --member properties
            self.gameCurrency = nil
            self.serviceTimestamp = nil
            self.nickname = nil
            self.bindingInfo = nil
            self.gender = nil
            self.encryptKey = nil
            self.custom = nil
            self.token = nil
            self.createTime = nil
            self.backupTime = nil
            self.followGzh = nil
            self.holidays = nil
            self.heart = nil
            self.dataTimestamp = nil
            self.tableConf = nil
            self.ad = nil
            self.verified = nil
            self.noticeSign = nil
            self.profileImg = nil
            self.service24Timestamp = nil
            self.verifiedInfo = nil
            self.userNew = nil
            self.shareSwitch = nil
            self.channelId = nil
            self.gametoken = nil
            self.qa = nil
            self.openId = nil
            self.userId = nil
        end

        return ServerData
    end)()
    AppGDK.ServerData = ServerData

    AppGDK.ServerData = ServerData

    GameCurrency = (function(super)
        local GameCurrency = declareClass("GameCurrency", super)
        function GameCurrency.prototype:constructor()
            --member properties
            self.diamond = nil
            self.seed = nil
            self.gold = nil
        end

        return GameCurrency
    end)()
    AppGDK.GameCurrency = GameCurrency

    AppGDK.GameCurrency = GameCurrency

    TableConf = (function(super)
        local TableConf = declareClass("TableConf", super)
        function TableConf.prototype:constructor()
            --member properties
            self.tableSign = nil
        end

        return TableConf
    end)()
    AppGDK.TableConf = TableConf

    AppGDK.TableConf = TableConf

    VerifiedInfo = (function(super)
        local VerifiedInfo = declareClass("VerifiedInfo", super)
        function VerifiedInfo.prototype:constructor()
            --member properties
            self.age = nil
            self.name = nil
            self.birthday = nil
            self.idCard = nil
        end

        return VerifiedInfo
    end)()
    AppGDK.VerifiedInfo = VerifiedInfo

    AppGDK.VerifiedInfo = VerifiedInfo

    RecordData = (function(super)
        local RecordData = declareClass("RecordData", super)
        function RecordData.prototype:constructor()
            --member properties
            self.type = nil
            self.gameUserId = nil
            self.token = nil
            self.openId = nil
            self.head = nil
            self.bindingInfo = nil
            self.gameRegDate = nil
            self.nickName = nil
            self.accountName = nil
        end

        return RecordData
    end)()
    AppGDK.RecordData = RecordData

    AppGDK.RecordData = RecordData

    ServedBindInfo = (function(super)
        local ServedBindInfo = declareClass("ServedBindInfo", super)
        function ServedBindInfo.prototype:constructor()
            --member properties
            self.serverData = nil
            self.visitorOpenId = nil
            self.loginNode = nil
        end

        return ServedBindInfo
    end)()
    AppGDK.ServedBindInfo = ServedBindInfo

    AppGDK.ServedBindInfo = ServedBindInfo

    AdvertPreloadInfo = (function(super)
        local AdvertPreloadInfo = declareClass("AdvertPreloadInfo", super)
        function AdvertPreloadInfo.prototype:constructor()
            --member properties
            self.advertType = nil
        end

        return AdvertPreloadInfo
    end)()
    AppGDK.AdvertPreloadInfo = AdvertPreloadInfo

    AppGDK.AdvertPreloadInfo = AdvertPreloadInfo

    AdvertType = (function(super)
        local AdvertType = declareClass("AdvertType", super)
        function AdvertType.prototype:constructor()
            --member properties
            self.FeedAdvert = nil
            self.BannerAdvert = nil
            self.FullscreenVideoAdvert = nil
            self.RewardedVideoAdvert = nil
            self.InterstitialAdvert = nil
        end

        return AdvertType
    end)()
    AppGDK.AdvertType = AdvertType

    AppGDK.AdvertType = AdvertType

    AdPlatformConfigs = (function(super)
        local AdPlatformConfigs = declareClass("AdPlatformConfigs", super)
        function AdPlatformConfigs.prototype:constructor()
            --member properties
            self.defaultRewardedVideoAdvertPlacementId = nil
            self.defaultBannerAdvertPlacementId = nil
            self.appId = nil
            self.defaultFeedAdvertPlacementId = nil
            self.defaultFullscreenVideoAdvertPlacementId = nil
        end

        return AdPlatformConfigs
    end)()
    AppGDK.AdPlatformConfigs = AdPlatformConfigs

    AppGDK.AdPlatformConfigs = AdPlatformConfigs

    AdCreateInfo = (function(super)
        local AdCreateInfo = declareClass("AdCreateInfo", super)
        function AdCreateInfo.prototype:constructor()
            --member properties
            self.advertType = nil
            self.appId = nil
            self.placementId = nil
            self.isDebug = nil
        end

        return AdCreateInfo
    end)()
    AppGDK.AdCreateInfo = AdCreateInfo

    AppGDK.AdCreateInfo = AdCreateInfo

    CreateAdUnitResult = (function(super)
        local CreateAdUnitResult = declareClass("CreateAdUnitResult", super)
        function CreateAdUnitResult.prototype:constructor()
            --member properties
            self.info = nil
        end

        return CreateAdUnitResult
    end)()
    AppGDK.CreateAdUnitResult = CreateAdUnitResult

    AppGDK.CreateAdUnitResult = CreateAdUnitResult

    AdUnitQueryInfo = (function(super)
        local AdUnitQueryInfo = declareClass("AdUnitQueryInfo", super)
        function AdUnitQueryInfo.prototype:constructor()
            --member properties
            self.unitId = nil
            self.sdkName = nil
            self.placementId = nil
            self.advertType = nil
        end

        return AdUnitQueryInfo
    end)()
    AppGDK.AdUnitQueryInfo = AdUnitQueryInfo

    AppGDK.AdUnitQueryInfo = AdUnitQueryInfo

    AdUnitOpInfo = (function(super)
        local AdUnitOpInfo = declareClass("AdUnitOpInfo", super)

        function AdUnitOpInfo.prototype:constructor(queryInfo, opInfo)
            --member properties
            self.opInfo = nil
            self.queryInfo = nil

            --constructor parameters

            --constructor logic

            self.queryInfo = queryInfo
            self.opInfo = opInfo
        end

        return AdUnitOpInfo
    end)()
    AppGDK.AdUnitOpInfo = AdUnitOpInfo

    AppGDK.AdUnitOpInfo = AdUnitOpInfo

    ShowAdUnitOpInfo = (function(super)
        local ShowAdUnitOpInfo = declareClass("ShowAdUnitOpInfo", super)
        function ShowAdUnitOpInfo.prototype:constructor()
            --member properties
            self.scene = nil
        end

        return ShowAdUnitOpInfo
    end)()
    AppGDK.ShowAdUnitOpInfo = ShowAdUnitOpInfo

    AppGDK.ShowAdUnitOpInfo = ShowAdUnitOpInfo

    ShowAdUnityResult = (function(super)
        local ShowAdUnityResult = declareClass("ShowAdUnityResult", super)
        function ShowAdUnityResult.prototype:constructor()
            --member properties
            self.couldReward = nil
        end

        return ShowAdUnityResult
    end)()
    AppGDK.ShowAdUnityResult = ShowAdUnityResult

    AppGDK.ShowAdUnityResult = ShowAdUnityResult

    SetAdUnitStyleInfo = (function(super)
        local SetAdUnitStyleInfo = declareClass("SetAdUnitStyleInfo", super)
        function SetAdUnitStyleInfo.prototype:constructor()
            --member properties
            self.styleInfo = nil
            self.queryInfo = nil
        end

        return SetAdUnitStyleInfo
    end)()
    AppGDK.SetAdUnitStyleInfo = SetAdUnitStyleInfo

    AppGDK.SetAdUnitStyleInfo = SetAdUnitStyleInfo

    AdUnitStyle = (function(super)
        local AdUnitStyle = declareClass("AdUnitStyle", super)
        function AdUnitStyle.prototype:constructor()
            --member properties
            self.width = nil
            self.top = nil
            self.x = nil
            self.y = nil
            self.height = nil
            self.bottom = nil
        end

        return AdUnitStyle
    end)()
    AppGDK.AdUnitStyle = AdUnitStyle

    AppGDK.AdUnitStyle = AdUnitStyle

    AdUnitStatus = (function(super)
        local AdUnitStatus = declareClass("AdUnitStatus", super)
        function AdUnitStatus.prototype:constructor()
        end

        return AdUnitStatus
    end)()
    AppGDK.AdUnitStatus = AdUnitStatus

    AppGDK.AdUnitStatus = AdUnitStatus

    AdUnitInfo = (function(super)
        local AdUnitInfo = declareClass("AdUnitInfo", super)
        function AdUnitInfo.prototype:constructor()
            --member properties
            self.advertType = nil
            self.sdkName = nil
            self.appId = nil
            self.placementId = nil
        end

        return AdUnitInfo
    end)()
    AppGDK.AdUnitInfo = AdUnitInfo

    AppGDK.AdUnitInfo = AdUnitInfo

    AdvertEvent = (function(super)
        local AdvertEvent = declareClass("AdvertEvent", super)
        function AdvertEvent.prototype:constructor()
            --member properties
            self.key = nil
            self.data = nil
        end

        return AdvertEvent
    end)()
    AppGDK.AdvertEvent = AdvertEvent

    AppGDK.AdvertEvent = AdvertEvent
end)(AppGDK)

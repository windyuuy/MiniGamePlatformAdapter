local AnyParams
local AnyResult
local ErrorInfo
local TaskCallback
local FTaskCallback
local EmptyTaskCallback

local AppGDK = AppGDK or {}
_G.AppGDK = AppGDK
local _ =
    (function(AppGDK)
    extendsNSList({AppGDK, _G})

    AnyParams = (function(super)
        local AnyParams = declareClass("AnyParams", super)
        function AnyParams.prototype:constructor()
        end

        return AnyParams
    end)()
    AnyParams.defaultValue = AnyParams()

    AppGDK.AnyParams = AnyParams

    AppGDK.AnyParams = AnyParams

    AnyResult = (function(super)
        local AnyResult = declareClass("AnyResult", super)
        function AnyResult.prototype:constructor()
        end

        return AnyResult
    end)()
    AnyResult.defaultValue = AnyResult()

    AppGDK.AnyResult = AnyResult

    AppGDK.AnyResult = AnyResult

    ErrorInfo = (function(super)
        local ErrorInfo = declareClass("ErrorInfo", super)

        function ErrorInfo.prototype:constructor(err)
            --member properties
            self.message = ""
            self.reason = "ERROR_UNKNOWN"
            self.code = -1

            --constructor parameters

            --constructor logic

            self.message = err.message
            self.reason = err.reason
            self.code = err.code
        end

        return ErrorInfo
    end)()
    AppGDK.ErrorInfo = ErrorInfo

    AppGDK.ErrorInfo = ErrorInfo

    TaskCallback = (function(super)
        local TaskCallback = declareClass("TaskCallback", super)

        function TaskCallback.prototype:constructor(cs)
            --member properties
            self.onSuccess = nil
            self.onFailed = nil
            self.onCancel = nil

            --constructor parameters

            --constructor logic

            self.onSuccess = cs.onSuccess
            self.onFailed = cs.onFailed
            self.onCancel = cs.onCancel
        end

        return TaskCallback
    end)()
    AppGDK.TaskCallback = TaskCallback

    AppGDK.TaskCallback = TaskCallback

    FTaskCallback = (function(super)
        local FTaskCallback = declareClass("FTaskCallback", super)

        function FTaskCallback.prototype:constructor(cs)
            --member properties
            self.onSuccess = nil
            self.onFailed = nil
            self.onCancel = nil

            --constructor parameters

            --constructor logic

            self.onSuccess = cs.onSuccess
            self.onFailed = cs.onFailed
            self.onCancel = cs.onCancel
        end

        return FTaskCallback
    end)()
    AppGDK.FTaskCallback = FTaskCallback

    AppGDK.FTaskCallback = FTaskCallback

    EmptyTaskCallback =
        (function(super)
        local EmptyTaskCallback = declareClass("EmptyTaskCallback", super)

        function EmptyTaskCallback.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(
                    self,
                    TaskCallback(
                        {
                            onSuccess = function()
                            end,
                            onFailed = function()
                            end
                        }
                    )
                )
            end

            --constructor logic
        end

        return EmptyTaskCallback
    end)(TaskCallback)
    AppGDK.EmptyTaskCallback = EmptyTaskCallback

    AppGDK.EmptyTaskCallback = EmptyTaskCallback
end)(AppGDK)

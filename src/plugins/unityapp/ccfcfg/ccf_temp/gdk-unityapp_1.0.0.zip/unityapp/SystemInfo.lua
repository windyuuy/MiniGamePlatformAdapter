local SystemInfo

local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    SystemInfo =
        (function(super)
        local SystemInfo = declareClass("SystemInfo", super)

        SystemInfo.prototype.fetchNetworkInfo =
            __JS_Async(
            function(self)
            end
        )

        function SystemInfo.prototype:init()
            if window["gdkjsb"] == nil or CS.UnityEngine.SystemInfo.deviceType == CS.UnityEngine.DeviceType.Desktop then
                return
            end
            self.deviceId = gdkjsb.deviceId
            self.uuid = gdkjsb.uuid
            self.gameDeviceId = gdkjsb.gameDeviceId
            self.system = gdkjsb.platform .. gdkjsb.systemVersion
            self.platform = gdkjsb.platform
            self.brand = gdkjsb.brand
            self.model = gdkjsb.model
            self.version = gdkjsb.systemVersion
            self.SDKVersion = __JS_toString(self.api.nativeVersion)
            self.language = gdkjsb.language
            self.versionCode = gdkjsb.versionCode
            self.versionName = gdkjsb.versionName

            self.channel = gdkjsb.channel
            self.quickChannelId = gdkjsb.quickChannelId
            self.country = gdkjsb.country
            self.installTime = gdkjsb.installTime
            self.imei = gdkjsb.imei
            self.packageName = gdkjsb.packageName
            self.packageTag = gdkjsb.packageTag
            self.debugAccountServer = gdkjsb.debugAccountServer
            self.isCustomBackendCfg = gdkjsb.isCustomBackendCfg

            self.screenWidth = 768
             --window.screen.width
            self.screenHeight = 1334
             --window.screen.height
            self.androidId = gdkjsb.androidId
            self.mac = gdkjsb.mac
            self.userAgent = gdkjsb.userAgent
        end
        function SystemInfo.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.api = nil
            self.platform = "unknown"
            self.brand = "unknown"
            self.model = "unknown"
            self.pixelRatio = -1
            self.screenWidth = -1
            self.screenHeight = -1
            self.windowWidth = -1
            self.windowHeight = -1
            self.statusBarHeight = -1
            self.language = "zh_CN"
            self.version = "1.0.0"
            self.system = "browser"
            self.fontSizeSetting = -1
            self.SDKVersion = "1.0.0"
            self.benchmarkLevel = -1
            self.networkClass = -1
            self.networkType = "unknown"
            self.isFirstInstall = nil
            self.devPlatform = "browser"
            self.deviceId = nil
            self.uuid = nil
            self.gameDeviceId = nil
            self.versionCode = nil
            self.versionName = nil
            self.channel = nil
            self.quickChannelId = nil
            self.country = nil
            self.installTime = nil
            self.imei = nil
            self.packageName = nil
            self.packageTag = nil
            self.debugAccountServer = nil
            self.isCustomBackendCfg = nil
            self.androidId = nil
            self.mac = nil
            self.userAgent = nil

            --constructor logic
        end

        return SystemInfo
    end)(GDK.SystemInfoBase)
    UnityAppGDK.SystemInfo = SystemInfo

    UnityAppGDK.SystemInfo = SystemInfo
end)(UnityAppGDK)

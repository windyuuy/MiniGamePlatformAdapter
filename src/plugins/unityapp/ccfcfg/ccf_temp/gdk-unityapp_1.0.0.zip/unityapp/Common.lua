local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ = (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})
    local Common = UnityAppGDK.Common or {}
    UnityAppGDK.Common = Common
    local _ = (function(Common)
        extendsNSList({UnityAppGDK.Common, UnityAppGDK, _G})

        --[[
	 * 服务器对象
	--]]
        local httpClient
        Common.httpClient = httpClient
        Common.httpClient = httpClient

        --[[
	 * 获取当前服务器时间
	--]]
        local getServerTime
        Common.getServerTime = getServerTime
        Common.getServerTime = getServerTime

        local devlog = slib.Log({tags = Array({"[gdk]", "[wechat]"})})
        Common.devlog = devlog
        Common.devlog = devlog

        local paylog = slib.Log({tags = Array({"[gdk]", "[wepay]"})})
        Common.paylog = paylog
        Common.paylog = paylog
    end)(Common)
end)(UnityAppGDK)

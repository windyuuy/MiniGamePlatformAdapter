local User
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local unitNum =
        Array(
        {
            nil,
            "K",
            "M",
            "B",
            "T",
            "aa",
            "bb",
            "cc",
            "dd",
            "ee",
            "ff",
            "gg",
            "hh",
            "ii",
            "jj",
            "kk",
            "ll",
            "mm",
            "nn",
            "oo",
            "pp",
            "qq",
            "rr",
            "ss",
            "tt",
            "uu",
            "vv",
            "ww",
            "xx",
            "yy",
            "zz",
            "Aa",
            "Bb",
            "Cc",
            "Dd",
            "Ee",
            "Ff",
            "Gg",
            "Hh",
            "Ii",
            "Jj",
            "Kk",
            "Ll",
            "Mm",
            "Nn",
            "Oo",
            "Pp",
            "Qq",
            "Rr",
            "Ss",
            "Tt",
            "Uu",
            "Vv",
            "Ww",
            "Xx",
            "Yy",
            "Zz",
            "AA",
            "BB",
            "CC",
            "DD",
            "EE",
            "FF",
            "GG",
            "HH",
            "II",
            "JJ",
            "KK",
            "LL",
            "MM",
            "NN",
            "OO",
            "PP",
            "QQ",
            "RR",
            "SS",
            "TT",
            "UU",
            "VV",
            "WW",
            "XX",
            "YY",
            "ZZ"
        }
    )
    -- const typeIndex = [null, 'goldRank', 'seedRank', 'unlockRank', 'sceneRank',]
    -- const expNum = 7
    local devlog = Common.devlog

    local isCancelLogin = false
    local isLoginEnd = false

    local self

    local isDelayLogin = false
    local loginStartTime = 0
    local loginRecord = nil
    local fOnAccountChange = nil

    User =
        (function(super)
        local User = declareClass("User", super)
        function User.prototype:__getter__server()
            return MServer.inst
        end

        function User.prototype:init(data)
        end

        function User.prototype:login(params)
            if gdkjsb.bridge:checkActionExist("loginWithBus") then
                return self:loginWithBus(params)
            else
                return self:loginTest(params)
            end
        end

        -- 登录服务器
        function User.prototype:loginTest(params)
            local ret = GDK.RPromise()

            local userId = localStorage:getItem("sdk_glee_userId")
            console:log("sdk_glee_userId:" .. userId)
            local nUserId = parseInt(userId)
            console:log("sdk_glee_userId3:", nUserId)
            if isNaN(nUserId) then
                nUserId = nil
            end
            console:log("sdk_glee_userId4:", nUserId)

            self.server:loginTest(
                {loginCode = nUserId, node = params.node},
                function(resp)
                    --玩家数据
                    if resp.succeed then
                        local data = resp.data
                        local userdata = self.api.userData
                        userdata.channelId = data.channelId
                        userdata.createTime = data.createTime
                        userdata.userId = data.userId
                        localStorage:setItem("sdk_glee_userId", [==[]==] .. tostring(data.userId) .. [==[]==])
                        console:log("sdk_glee_userId2:" .. localStorage:getItem("sdk_glee_userId"))
                        userdata.followGzh = data.followGzh
                        userdata.nickName = data.nickname
                        userdata.isNewUser = data.userNew

                        self.api.systemInfo.tableConf = resp.data.tableConf
                         --记录登录时传入的表格信息

                        ret:success(
                            {
                                extra = data
                            }
                        )
                    else
                        ret:fail(
                            GDK.GDKResultTemplates:make(
                                GDK.GDKErrorCode.UNKNOWN,
                                {
                                    data = {
                                        extra = resp
                                    }
                                }
                            )
                        )
                    end
                end,
                function()
                    ret:fail(GDK.GDKResultTemplates:make(GDK.GDKErrorCode.NETWORK_ERROR))
                end
            )

            return ret.promise
        end

        function User.prototype:loginWithBus(params)
            params = params or {}

            local ret = GDK.RPromise()
            local loginInfo = ServedLoginInfo()
            loginInfo.loginNode = params.node
            local callbacks =
                TaskCallback(
                {
                    onSuccess = function(data)
                        local loginResult = GDK.LoginResult()
                        loginResult.extra = data.serverData
                        console:log("loginResult: " .. JSON:stringify(loginResult))
                        ret:success(loginResult)
                    end,
                    onFailed = function(err)
                        ret:fail(
                            GDK.GDKResultTemplates:make(
                                GDK.GDKErrorCode.UNKNOWN,
                                {
                                    data = {
                                        extra = err
                                    }
                                }
                            )
                        )
                    end
                }
            )

            SDKProxy:loginWithBus(loginInfo, callbacks)

            return ret.promise
        end

        User.prototype.showUserCenter =
            __JS_Async(
            function(self)
                local user = SDKProxy:loadUserRecord()[0]
                SDKProxy:showUserCenter(user)
            end
        )

        User.prototype.showBindDialog =
            __JS_Async(
            function(self)
                local user = SDKProxy:loadUserRecord()[0]
                SDKProxy:showBindDialog(user)
            end
        )

        function User.prototype:update()
            local ret = GDK.RPromise()
            ret:success({})
            return ret.promise
        end

        function User.prototype:_getFriendCloudStorage(__objectBinding0__)
            local keyList = __objectBinding0__.keyList
            local success = __objectBinding0__.success
            local complete = __objectBinding0__.complete
            local fail = __objectBinding0__.fail
            -- let typeIndex = [null, 'goldRank', 'seedRank', 'unlockRank', 'sceneRank',]
            local info = {
                avatarUrl = "http://thirdqq.qlogo.cn/g?b=sdk&k=hX0olvhiaztn1FNkd2IibY4g&s=100&t=1483308056",
                KVDataList = Array(
                    {
                        {
                            key = "goldRank",
                            value = "100AA"
                        },
                        {
                            key = "seedRank",
                            value = "1000"
                        },
                        {
                            key = "unlockRank",
                            value = "199"
                        },
                        {
                            key = "sceneRank",
                            value = "324"
                        }
                    }
                ),
                nickname = "hello",
                openid = "lkjlkwjlk"
            }
            local res = {
                data = Array({})
            }
            local i = 0
            while i < 10 do
                local newinfo = {
                    avatarUrl = "http://thirdqq.qlogo.cn/g?b=sdk&k=hX0olvhiaztn1FNkd2IibY4g&s=100&t=1483308056",
                    KVDataList = Array(
                        {
                            {
                                key = "goldRank",
                                value = "100AA"
                            },
                            {
                                key = "seedRank",
                                value = "1000"
                            },
                            {
                                key = "unlockRank",
                                value = "199"
                            },
                            {
                                key = "sceneRank",
                                value = "324"
                            }
                        }
                    ),
                    nickname = "hello",
                    openid = "lkjlkwjlk"
                }
                newinfo.openid = newinfo.openid .. i
                res.data:push(newinfo)
                i = i + 1
            end

            local ___unused = success and success(res)
            ___unused = complete and complete()
        end

        function User.prototype:_setUserCloudStorage(obj)
            devlog:info("-[UserCloudStorage] 提交用户成绩", obj.KVDataList)
            local typeIndex = obj.typeIndex
            local commitTime = 0
             --this.getTime()
            local data = {
                userData = Array(
                    {
                        {
                            openId = "",
                             --GameStatusInfo.openId,
                            startMs = "" .. 0,
                             --this.loginTime,
                            endMs = "" .. commitTime,
                            scoreInfo = {
                                score = 0
                            }
                        }
                    }
                ),
                attr = {
                    score = {
                        type = "rank",
                        order = 1
                    }
                }
            }

            local selfScoreInfo = data.userData[0].scoreInfo
            local attr = data.attr
            do
                local ___temp = obj.KVDataList
                for ___i = 0, ___temp.length - 1 do
                    local item = ___temp[___i]

                    local ss = item.value
                    local unitA = ss:match(RegExp("[a-zA-Z]+", ""))
                    if unitA then
                        unitA = unitA[0]
                    end
                    local numA = parseFloat(ss)
                    local expA = unitNum:indexOf(unitA)
                    local intA = Math:floor(numA * 1000)
                    local intS = Math:pow(10, 9) * expA + intA
                    local keyIndex = typeIndex:indexOf(item.key)

                    if keyIndex <= 0 then
                        devlog:info(
                            [==[-[UserCloudStorage] 不正确的keyIndex: ]==] ..
                                tostring(keyIndex) .. [==[ ]==] .. tostring(item.key) .. [==[]==]
                        )
                    else
                        local orderKey = "a" .. keyIndex
                        selfScoreInfo[orderKey] = intS

                        attr[orderKey] = {
                            type = item.key,
                            order = 1
                        }
                    end
                end
            end

            devlog:info("-[UserCloudStorage] 提交用户成绩数据: " .. JSON:stringify(data))
        end

        function User.prototype:getFriendCloudStorage(obj)
            local ret = GDK.RPromise()
            self:_getFriendCloudStorage(
                {
                    keyList = obj.keyList,
                    typeIndex = obj.typeIndex,
                    success = function(res)
                        ret:success(res)
                    end,
                    fail = function()
                        ret:fail(GDK.GDKResultTemplates:make(GDK.GDKErrorCode.API_GET_FRIEND_CLOUD_STORAGE_FAILED))
                    end
                }
            )
            return ret.promise
        end

        function User.prototype:setUserCloudStorage(obj)
            local ret = GDK.RPromise()
            self:_setUserCloudStorage(
                {
                    KVDataList = obj.KVDataList,
                    success = function()
                        ret:success(nil)
                    end,
                    typeIndex = obj.typeIndex,
                    fail = function()
                        ret:fail(GDK.GDKResultTemplates:make(GDK.GDKErrorCode.API_SET_USER_CLOUD_STORAGE_FAILED))
                    end
                }
            )
            return ret.promise
        end

        --[[
		 * 判断userId对应的用户是否绑定过社交账号
		 * @param userId 登录时服务器返回的userId
		--]]
        function User.prototype:checkIsUserBind(userId)
            local users =
                SDKProxy:loadUserRecord():where(
                function(u)
                    return u.userId == userId
                end
            )

            return users.length > 0 and
                not (not users:find(
                    function(user)
                        return user.loginType ~= "silent" and user.loginType ~= "visitor"
                    end
                ))
        end

        function User.prototype:setAccountChangeListener(f)
            fOnAccountChange = f
        end
        function User.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.api = nil
            self.loginNode = nil

            --constructor logic
        end

        return User
    end)(GDK.UserBase)
    UnityAppGDK.User = User

    UnityAppGDK.User = User
end)(UnityAppGDK)

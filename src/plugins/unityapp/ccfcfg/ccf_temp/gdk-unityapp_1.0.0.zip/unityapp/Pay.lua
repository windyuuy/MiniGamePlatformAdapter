local Pay

local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local paylog = Common.paylog

    Pay =
        (function(super)
        local Pay = declareClass("Pay", super)

        function Pay.prototype:payPurchase(config, options)
            local ret = GDK.RPromise()
            local sku = config.productId
            if not sku then
                local msg = "payPurchase: productId 为空， 原生app需要传入productId"
                paylog:error(msg)
                ret:fail(
                    GDK.GDKResultTemplates:make(
                        GDK.GDKErrorCode.API_PAY_FAILED,
                        {
                            message = msg
                        }
                    )
                )
                return ret.promise
            end
            SDKProxy.nativePay:requestPay(
                {
                    productId = sku,
                    sku = sku,
                    price = config.money,
                    count = config.amount,
                    currency = "dollar",
                    channelAppId = config.channelAppId,
                    packageValue = "Sign=WXPay",
                    nonceStr = config.nonceStr,
                    partnerId = config.partnerId,
                    paySign = config.paySign,
                    prepayId = config.prepayId,
                    timestamp = config.timestamp,
                    payWay = options.payWay,
                    extraStr = config.extraStr,
                    title = config.title,
                    orderNo = config.orderNo,
                    payUrl = options.payUrl,
                    gleeOrderNo = config.gleeOrderNo,
                    accountId = config.accountId,
                    notifyUrl = config.notifyUrl,
                    aliamount = config.aliamount,
                    gameSign = config.gameSign
                }
            ):_then_(
                function(payret)
                    if payret.code == 0 then
                        paylog:info("原生充值成功", config)
                        ret:success(
                            {
                                result = {
                                    errCode = 0
                                },
                                extra = payret
                            }
                        )
                    else
                        if payret.code == UnityAppGDK.PayErrorCode.PURCHASE_CANCELLED then
                            paylog:info("原生充值取消", payret, config)
                            ret:fail(GDK.GDKResultTemplates:make(GDK.GDKErrorCode.API_PAY_CANCEL))
                        else
                            paylog:warn("原生充值失败", payret, config)
                            ret:fail(
                                GDK.GDKResultTemplates:make(
                                    GDK.GDKErrorCode.API_PAY_FAILED,
                                    {
                                        data = {
                                            extra = payret
                                        }
                                    }
                                )
                            )
                        end
                    end
                end,
                function(payret)
                    ret:fail(payret)
                end
            )
            --[[
			-- 1. do wechat pay
			if (options.payWay == "WechatPay") {
				SDKProxy.nativePay.requestPay({
					sku: sku,
					price: config.money,
					count: 1,
					currency: "dollar",

					channelAppId: config.channelAppId,
					packageValue: "Sign=WXPay",
					nonceStr: config.nonceStr,
					partnerId: config.partnerId,
					paySign: config.paySign,
					prepayId: config.prepayId,
					timestamp: config.timestamp,
				}).then((payret) => {
					if (payret.code == 0) {
						paylog.info("原生充值成功", config)
						ret.success({
							result: {
								errCode: 0,
							},
							extra: payret,
						})
					} else {
						if (payret.code == UnityAppGDK.PayErrorCode.PURCHASE_CANCELLED) {
							paylog.info("原生充值取消", payret, config)
							ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_PAY_CANCEL))
						} else {
							paylog.warn("原生充值失败", payret, config)
							ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_PAY_FAILED, {
								data: {
									extra: payret
								}
							}))
						}
					}
				}, (payret) => {
					ret.fail(payret)
				})
			}

			-- 2. aliPay
			else if (options.payWay == "AliPay") {
				paylog.info("alipay_requestPay")
				SDKProxy.nativePay.alipay_requestPay({
					sku: sku,
					price: config.price,
					count: 1,
					currency: "dollar",
					channelAppId: config.channelAppId,
					packageValue: "AliPay",
					nonceStr: config.nonceStr,
					partnerId: config.partnerId,
					paySign: config.paySign,
					prepayId: config.prepayId,
					timestamp: config.timestamp,
					aliOrderInfo: config.aliOrderInfo
				}).then((payret) => {
					if (payret.code == 0) {
						paylog.info("原生充值成功", config)
						ret.success({
							result: {
								errCode: 0,
							},
							extra: payret,
						})
					} else {
						if (payret.code == UnityAppGDK.PayErrorCode.PURCHASE_CANCELLED) {
							paylog.info("原生充值取消", payret, config)
							ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_PAY_CANCEL))
						} else {
							paylog.warn("原生充值失败", payret, config)
							ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.API_PAY_FAILED, {
								data: {
									extra: payret
								}
							}))
						}
					}
				}, (payret) => {
					ret.fail(payret)
				})
			}
			--]]
            return ret.promise
        end

        --[[
		 * 消耗商品
		--]]
        Pay.prototype.consumePurchase =
            __JS_Async(
            function(self, params)
                return SDKProxy.nativePay:consumePurchase(params)
            end
        )

        --[[
		 * 获取未消耗商品列表
		--]]
        Pay.prototype.queryItemInfo =
            __JS_Async(
            function(self, params)
                local sku = params.productId
                if not sku then
                    local msg = "queryItemInfo: productId 为空， 原生app需要传入productId"
                    paylog:error(msg)
                    local ret = GDK.RPromise()
                    ret:fail(
                        GDK.GDKResultTemplates:make(
                            GDK.GDKErrorCode.API_PAY_QUERYITEMINFO_FAILED,
                            {
                                message = msg
                            }
                        )
                    )
                    return ret.promise
                end

                return SDKProxy.nativePay:queryItemInfo({sku = params.productId, productId = params.productId})
            end
        )
        function Pay.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.api = nil

            --constructor logic
        end

        return Pay
    end)(GDK.PayBase)
    UnityAppGDK.Pay = Pay

    UnityAppGDK.Pay = Pay
end)(UnityAppGDK)

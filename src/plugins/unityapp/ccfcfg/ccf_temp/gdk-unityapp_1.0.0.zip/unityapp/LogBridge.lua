local LogBridge
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    LogBridge =
        (function(super)
        local LogBridge = declareClass("LogBridge", super)

        --[[
	 * 自定义日志
	--]]
        function LogBridge:logCustomEvent(key, params)
            if gdkjsb.bridge == nil then
                return
            end
            gdkjsb.bridge:callAction(
                "AppsFlyerSDK:logCustomEvent",
                JSON:stringify({key = key, params = params, data = params}),
                function(data)
                end
            )
        end

        --[[
	 * 自定义日志
	--]]
        function LogBridge:logLogin(type, userId)
            if gdkjsb.bridge == nil then
                return
            end
            gdkjsb.bridge:callAction(
                "AppsFlyerSDK:logLogin",
                JSON:stringify({type = type, userId = userId}),
                function(data)
                end
            )
        end

        --[[
	 * 自定义日志
	--]]
        function LogBridge:logRegister(type)
            if gdkjsb.bridge == nil then
                return
            end
            gdkjsb.bridge:callAction(
                "AppsFlyerSDK:logRegister",
                JSON:stringify({type = type}),
                function(data)
                end
            )
        end

        --[[
	 * 自定义日志
	--]]
        function LogBridge:logRequestPay(id, price, count, currency)
            if gdkjsb.bridge == nil then
                return
            end
            gdkjsb.bridge:callAction(
                "AppsFlyerSDK:logRequestPay",
                JSON:stringify({id = id, price = price, count = count, currency = currency}),
                function(data)
                end
            )
        end

        --[[
	 * 自定义日志
	--]]
        function LogBridge:logPurchased(id, revenue, price, count, currency, succ)
            if gdkjsb.bridge == nil then
                return
            end
            gdkjsb.bridge:callAction(
                "AppsFlyerSDK:logPurchased",
                JSON:stringify(
                    {id = id, revenue = revenue, price = price, count = count, currency = currency, succ = succ}
                ),
                function(data)
                end
            )
        end
        function LogBridge.prototype:constructor()
        end

        return LogBridge
    end)()
    UnityAppGDK.LogBridge = LogBridge

    UnityAppGDK.LogBridge = LogBridge
end)(UnityAppGDK)

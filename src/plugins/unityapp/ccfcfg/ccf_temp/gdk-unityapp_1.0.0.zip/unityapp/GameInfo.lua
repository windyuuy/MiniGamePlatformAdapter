local GameInfo

local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ = (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    GameInfo = (function(super)
        local GameInfo = declareClass("GameInfo", super)

        function GameInfo.prototype:initWithConfig(info)
            for k, _ in pairs(info.app) do
                self[k] = info.app[k]
            end

            Common.getServerTime = info.app.getServerTime
            Common.httpClient = info.app.httpClient
        end

        function GameInfo.prototype:init()
        end
        function GameInfo.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.mode = nil
            self.appId = nil
            self.gameChannelId = nil
            self.isPayInSandbox = nil
            self.offerId = nil
            self.shareProxyUrl = nil
            self.launchOptions = nil
            self.gameVersion = nil
            self.gameId = nil
            self.gameType = nil

            --constructor logic
        end

        return GameInfo
    end)(GDK.GameInfoBase)
    UnityAppGDK.GameInfo = GameInfo

    UnityAppGDK.GameInfo = GameInfo
end)(UnityAppGDK)

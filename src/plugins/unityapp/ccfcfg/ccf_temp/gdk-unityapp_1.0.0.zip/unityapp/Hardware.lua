local Vibration
local Hardware

local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local devlog = Common.devlog
    Vibration =
        (function(super)
        local Vibration = declareClass("Vibration", super)

        Vibration.prototype.vibrateLong =
            __JS_Async(
            function(self)
                devlog:info("vibrateLong")
                -- 使手机发生较长时间的振动（400 ms）
                window["jsb"].device:vibrate(0.4)
            end
        )

        Vibration.prototype.vibrateShort =
            __JS_Async(
            function(self)
                devlog:info("vibrateShort")
                -- 使手机发生较短时间的振动（15 ms）。仅在 iPhone 7 / 7 Plus 以上及 Android 机型生效
                window["jsb"].device:vibrate(0.015)
            end
        )

        Vibration.prototype.vibrate =
            __JS_Async(
            function(self, params)
                devlog:info("vibrate", params)
                window["jsb"].device:vibrate(params.duration)
            end
        )
        function Vibration.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return Vibration
    end)(GDK.IVibration)
    Hardware = (function(super)
        local Hardware = declareClass("Hardware", super)
        function Hardware.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.vibration = Vibration()

            --constructor logic
        end

        return Hardware
    end)(GDK.HardwareBase)
    UnityAppGDK.Hardware = Hardware

    UnityAppGDK.Hardware = Hardware
end)(UnityAppGDK)

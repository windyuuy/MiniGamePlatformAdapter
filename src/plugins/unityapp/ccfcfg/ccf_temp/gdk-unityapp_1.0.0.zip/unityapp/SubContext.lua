local SubContext

local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ = (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    SubContext = (function(super)
        local SubContext = declareClass("SubContext", super)
        function SubContext.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return SubContext
    end)(GDK.SubContextBase)
    UnityAppGDK.SubContext = SubContext

    UnityAppGDK.SubContext = SubContext
end)(UnityAppGDK)

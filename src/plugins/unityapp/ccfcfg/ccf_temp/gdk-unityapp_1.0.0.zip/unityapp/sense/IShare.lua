local ShareData
local ShareUrlData
local ShareResult
local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    --[[
	 * 分享时所使用的数据
	--]]
    ShareData = (function(super)
        local ShareData = declareClass("ShareData", super)
        function ShareData.prototype:constructor()
            --member properties
            self.title = nil
            self.summary = nil
            self.imageUrl = nil
            self.socialPicUrl = nil
            self.data = nil
            self.wxShareVersion = nil
        end

        return ShareData
    end)()
    GDK.ShareData = ShareData

    GDK.ShareData = ShareData

    ShareUrlData = (function(super)
        local ShareUrlData = declareClass("ShareUrlData", super)
        function ShareUrlData.prototype:constructor()
            --member properties
            self.title = nil
            self.summary = nil
            self.imageUrl = nil
            self.url = nil
            self.wxShareVersion = nil
        end

        return ShareUrlData
    end)()
    GDK.ShareUrlData = ShareUrlData

    GDK.ShareUrlData = ShareUrlData

    ShareResult = (function(super)
        local ShareResult = declareClass("ShareResult", super)
        function ShareResult.prototype:constructor()
            --member properties
            self.result = nil
            self.message = nil
            self.isGroup = false
            self.extra = nil
        end

        return ShareResult
    end)()
    GDK.ShareResult = ShareResult

    GDK.ShareResult = ShareResult
end)(GDK)

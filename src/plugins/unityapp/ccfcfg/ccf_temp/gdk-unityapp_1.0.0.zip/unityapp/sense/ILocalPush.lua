local LocalPushBundle

local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    local LocalPushAvailableStage = {}
    --[[
		 * 允许后台通知
		--]]
    LocalPushAvailableStage.BACKGROUND = 1
    LocalPushAvailableStage[1] = "BACKGROUND"
    --[[
		 * 允许前台通知
		--]]
    LocalPushAvailableStage.FOREGROUND = 2
    LocalPushAvailableStage[2] = "FOREGROUND"
    GDK.LocalPushAvailableStage = LocalPushAvailableStage

    GDK.LocalPushAvailableStage = LocalPushAvailableStage

    LocalPushBundle = (function(super)
        local LocalPushBundle = declareClass("LocalPushBundle", super)
        function LocalPushBundle.prototype:constructor()
            --member properties
            self.identifier = nil
            self.title = "标题"
            self.subtitle = ""
            self.content = "内容"
            self.ticker = ""
            self.interval = nil
            self._repeat_ = 0
            self.badge = 1
            self.userInfo = "{}"
            self.soundName = nil
            self.enableSoundTip = true
            self.enableVibrateTip = false
            self.enableLightTip = false
            self.availableStage = LocalPushAvailableStage.BACKGROUND
            self.isBigText = false
        end

        return LocalPushBundle
    end)()
    GDK.LocalPushBundle = LocalPushBundle

    GDK.LocalPushBundle = LocalPushBundle
end)(GDK)

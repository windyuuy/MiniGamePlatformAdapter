local PayItemInfo
local PayError
local PayResult
local ConsumePurchaseResult
local PayQueryItemInfoResultData
local PayQueryItemInfoResult
local PayOptions
local ConsumePurchaseParams
local PayQueryItemInfoParams
local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    --[[ 订单状态--]]
    local OrderState = {}
    OrderState.fail = 2
    OrderState[2] = "fail"
    OrderState.ok = 1
    OrderState[1] = "ok"
    OrderState.unknown = 0
    OrderState[0] = "unknown"
    GDK.OrderState = OrderState

    GDK.OrderState = OrderState

    PayItemInfo = (function(super)
        local PayItemInfo = declareClass("PayItemInfo", super)
        function PayItemInfo.prototype:constructor()
            --member properties
            self.goodsId = 0
            self.coinId = 0
            self.productId = nil
            self.money = 0
            self.price = 0
            self.amount = 0
            self.title = ""
            self.currencyUnit = "CNY"
            self.pkgName = nil
            self.token = nil
            self.timestamp = nil
            self.paySign = nil
            self.orderNo = nil
            self.gleeOrderNo = nil
            self.oppoId = nil
            self.channelAppId = nil
            self.merchantId = nil
            self.prepayId = nil
            self.partnerId = nil
            self.nonceStr = nil
            self.vivoOrderInfo = nil
            self.extraStr = nil
            self.accountId = nil
            self.aliamount = nil
            self.notifyUrl = nil
            self.gameSign = nil
        end

        return PayItemInfo
    end)()
    GDK.PayItemInfo = PayItemInfo

    GDK.PayItemInfo = PayItemInfo

    PayError = (function(super)
        local PayError = declareClass("PayError", super)
        function PayError.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.data = nil

            --constructor logic
        end

        return PayError
    end)(GDKError)
    GDK.PayError = PayError

    GDK.PayError = PayError

    PayResult = (function(super)
        local PayResult = declareClass("PayResult", super)
        function PayResult.prototype:constructor()
            --member properties
            self.result = nil
            self.extra = nil
        end

        return PayResult
    end)()
    GDK.PayResult = PayResult

    GDK.PayResult = PayResult

    ConsumePurchaseResult = (function(super)
        local ConsumePurchaseResult = declareClass("ConsumePurchaseResult", super)
        function ConsumePurchaseResult.prototype:constructor()
            --member properties
            self.code = nil
        end

        return ConsumePurchaseResult
    end)()
    GDK.ConsumePurchaseResult = ConsumePurchaseResult

    GDK.ConsumePurchaseResult = ConsumePurchaseResult
    PayQueryItemInfoResultData = (function(super)
        local PayQueryItemInfoResultData = declareClass("PayQueryItemInfoResultData", super)
        function PayQueryItemInfoResultData.prototype:constructor()
            --member properties
            self.productId = nil
            self.purchaseToken = nil
            self.purchaseData = nil
            self.dataSignature = nil
        end

        return PayQueryItemInfoResultData
    end)()
    GDK.PayQueryItemInfoResultData = PayQueryItemInfoResultData

    GDK.PayQueryItemInfoResultData = PayQueryItemInfoResultData
    PayQueryItemInfoResult = (function(super)
        local PayQueryItemInfoResult = declareClass("PayQueryItemInfoResult", super)
        function PayQueryItemInfoResult.prototype:constructor()
            --member properties
            self.code = nil
            self.data = nil
            self.message = nil
        end

        return PayQueryItemInfoResult
    end)()
    GDK.PayQueryItemInfoResult = PayQueryItemInfoResult

    GDK.PayQueryItemInfoResult = PayQueryItemInfoResult

    local WebViewOrientation = {}
    WebViewOrientation.portrait = 1
    WebViewOrientation[1] = "portrait"
    WebViewOrientation.landscapeLeft = 2
    WebViewOrientation[2] = "landscapeLeft"
    WebViewOrientation.landscapeRight = 3
    WebViewOrientation[3] = "landscapeRight"
    GDK.WebViewOrientation = WebViewOrientation

    GDK.WebViewOrientation = WebViewOrientation

    PayOptions = (function(super)
        local PayOptions = declareClass("PayOptions", super)
        function PayOptions.prototype:constructor()
            --member properties
            self.gameOrientation = nil
            self.payWay = nil
            self.channelType = nil
            self.gleeZoneId = nil
            self.payUrl = nil
            self.wxZoneId = nil
            self.subTitle = nil
            self.imagePath = nil
            self.customExtra = nil
        end

        return PayOptions
    end)()
    GDK.PayOptions = PayOptions

    GDK.PayOptions = PayOptions
    ConsumePurchaseParams = (function(super)
        local ConsumePurchaseParams = declareClass("ConsumePurchaseParams", super)
        function ConsumePurchaseParams.prototype:constructor()
            --member properties
            self.payWay = nil
            self.purchaseToken = nil
        end

        return ConsumePurchaseParams
    end)()
    GDK.ConsumePurchaseParams = ConsumePurchaseParams

    GDK.ConsumePurchaseParams = ConsumePurchaseParams
    PayQueryItemInfoParams = (function(super)
        local PayQueryItemInfoParams = declareClass("PayQueryItemInfoParams", super)
        function PayQueryItemInfoParams.prototype:constructor()
            --member properties
            self.payWay = nil
            self.productId = nil
        end

        return PayQueryItemInfoParams
    end)()
    GDK.PayQueryItemInfoParams = PayQueryItemInfoParams

    GDK.PayQueryItemInfoParams = PayQueryItemInfoParams
end)(GDK)

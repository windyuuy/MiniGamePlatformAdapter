local APIServer
local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    APIServer = (function(super)
        local APIServer = declareClass("APIServer", super)
        function APIServer.prototype:constructor()
        end

        return APIServer
    end)()
    GDK.APIServer = APIServer

    GDK.APIServer = APIServer
end)(GDK)

local UserInfoButtonStyle

local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    --[[ 按钮的样式--]]
    UserInfoButtonStyle = (function(super)
        local UserInfoButtonStyle = declareClass("UserInfoButtonStyle", super)
        function UserInfoButtonStyle.prototype:constructor()
            --member properties
            self.left = nil
            self.top = nil
            self.width = nil
            self.height = nil
            self.backgroundColor = nil
            self.borderColor = nil
            self.borderWidth = nil
            self.borderRadius = nil
            self.textAlign = nil
            self.fontSize = nil
            self.lineHeight = nil
        end

        return UserInfoButtonStyle
    end)()
    GDK.UserInfoButtonStyle = UserInfoButtonStyle

    GDK.UserInfoButtonStyle = UserInfoButtonStyle
end)(GDK)

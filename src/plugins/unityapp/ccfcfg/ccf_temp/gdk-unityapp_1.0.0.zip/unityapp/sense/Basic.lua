local YmPromise
local RPromise
local ReqParams
local GDK = GDK or {}
_G.GDK = GDK
local _ =
    (function(GDK)
    extendsNSList({GDK, _G})

    -- --[[ 基本请求错误码--]]
    -- export const ReqErrorCode = {
    -- 	--[[ 请求成功--]]
    -- 	SUCCESS: 0,
    -- 	--[[ 未知错误--]]
    -- 	UNKNOWN: 100,
    -- 	--[[ 请求超时--]]
    -- 	TIMEOUT: 101,
    -- }

    -- --[[ 请求错误扩展参数--]]
    -- export class ExtraReqError {
    -- 	errCode?: number
    -- 	msg?: string
    -- 	reason?: string
    -- 	data?: any
    -- }

    -- --[[ 请求错误结果--]]
    -- export class ReqError extends Error {
    -- 	errCode: number
    -- 	msg: string
    -- 	reason: string
    -- 	data?: any

    -- 	constructor(errCode: number, msg: string, reason: string, data?: any) {
    -- 		super(msg)
    -- 		this.errCode = errCode
    -- 		this.reason = reason;
    -- 		this.data = data;
    -- 	}
    -- }

    -- --[[ 请求结果--]]
    -- export class ReqResult extends ReqError { }

    -- --[[ 请求结果模板生成器--]]
    -- export class ResultTemplatesExtractor<T extends ReqError> {
    -- 	protected _temps: T[] = []
    -- 	get temps() { return this._temps }

    -- 	constructor(temps: T[]) {
    -- 		this._temps = temps
    -- 	}

    -- 	--[[
    -- 	 * 根据错误码和扩展参数构造请求结果
    -- 	--]]
    -- 	make<F extends ExtraReqError>(errCode: number, extra?: F): T {
    -- 		return null
    -- 	}
    -- }

    --[[
	 * 请求结果模板，用于生成请求结果
	 * 用法示例：
	 * - ```typescript
	export const LoginResultTemplates = new ResultTemplatesExtractor<ReqError>([
		...ReqResultTemplates.temps,
		{ errCode: LoginErrorCode.INVALID_OPENID, msg: '登录失败', reason: 'openId验证失败' },
	])
	```
	 *--]]
    -- export const ReqResultTemplates = new ResultTemplatesExtractor<ReqError>([
    -- 	{ errCode: ReqErrorCode.SUCCESS, msg: '请求成功', reason: '请求成功', data: null },
    -- 	{ errCode: ReqErrorCode.UNKNOWN, msg: '请求失败', reason: '未知错误' },
    -- 	{ errCode: ReqErrorCode.TIMEOUT, msg: '请求超时', reason: '请求超时' },
    -- ])

    -- export class ReqCallbacks {
    -- 	success?: (params: ReqResult) => void
    -- 	fail?: (params: ReqError) => void
    -- }

    --[[
	 * 增强类型限定的Promise
	 * @param T - resolve 参数类型
	 * @param F - reject 参数类型
	--]]
    -- export class MyPromise<T, F> extends Promise<T>{
    -- 	constructor(executor: (resolve: (value?: T | PromiseLike<T>) => void, reject: (reason?: F) => void) => void) {
    -- 		super(executor)
    -- 	}
    -- }

    --[[
	 * 反转 MyPromise
	 * - 外部调用 success时相当于调用了 resolve
	 * - 外部调用 fail 时，相当于调用了 reject
	 * @param T - resolve 参数类型
	 * @param F - reject 参数类型
	--]]
    YmPromise =
        (function(super)
        local YmPromise = declareClass("YmPromise", super)

        function YmPromise.prototype:constructor(params)
            --member properties
            self.success = nil
            self.fail = nil
            self.promise = nil

            --constructor parameters

            --constructor logic

            self:init(params)
        end

        function YmPromise.prototype:init(params)
            self.promise =
                Promise(
                function(resolve, reject)
                    self.success = resolve
                    self.fail = reject
                end
            )
        end

        return YmPromise
    end)()
    GDK.YmPromise = YmPromise

    GDK.YmPromise = YmPromise

    RPromise = (function(super)
        local RPromise = declareClass("RPromise", super)
        function RPromise.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.success = nil
            self.fail = nil

            --constructor logic
        end

        return RPromise
    end)(YmPromise)
    GDK.RPromise = RPromise

    GDK.RPromise = RPromise

    --[[ 请求参数--]]
    ReqParams = (function(super)
        local ReqParams = declareClass("ReqParams", super)
        function ReqParams.prototype:constructor()
            --member properties
            self.timeout = nil
            self.platform = nil
        end

        return ReqParams
    end)()
    GDK.ReqParams = ReqParams

    GDK.ReqParams = ReqParams
end)(GDK)

local UserDataUpdateResult
local KVData
local UserGameData
local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    --[[ 登录请求结果--]]
    UserDataUpdateResult = (function(super)
        local UserDataUpdateResult = declareClass("UserDataUpdateResult", super)
        function UserDataUpdateResult.prototype:constructor()
            --member properties
            self.extra = nil
        end

        return UserDataUpdateResult
    end)()
    GDK.UserDataUpdateResult = UserDataUpdateResult

    GDK.UserDataUpdateResult = UserDataUpdateResult

    --https:--developers.weixin.qq.com/minigame/dev/document/open-api/data/KVData.html
    KVData = (function(super)
        local KVData = declareClass("KVData", super)
        function KVData.prototype:constructor()
            --member properties
            self.key = nil
            self.value = nil
        end

        return KVData
    end)()
    GDK.KVData = KVData

    GDK.KVData = KVData

    --https:--developers.weixin.qq.com/minigame/dev/document/open-api/data/UserGameData.html
    UserGameData = (function(super)
        local UserGameData = declareClass("UserGameData", super)
        function UserGameData.prototype:constructor()
            --member properties
            self.avatarUrl = nil
            self.nickname = nil
            self.openid = nil
            self.KVDataList = nil
        end

        return UserGameData
    end)()
    GDK.UserGameData = UserGameData

    GDK.UserGameData = UserGameData
end)(GDK)

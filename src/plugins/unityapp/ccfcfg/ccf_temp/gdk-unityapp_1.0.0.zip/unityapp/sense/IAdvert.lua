local BannerStyle
local BannerStyleAccessor
local RewardedVideoAdOnErrorParam
local InterstitialAdOnErrorParam
local FullscreenAdOnErrorParam
local RewardVideoAdLoadParams
local VideoAdSlot
local FeedAdStyle
local FeedAdStyleAccessor
local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    BannerStyle = (function(super)
        local BannerStyle = declareClass("BannerStyle", super)
        function BannerStyle.prototype:constructor()
            --member properties
            self.x = nil
            self.y = nil
            self.width = nil
            self.height = nil
            self.top = nil
            self.left = nil
        end

        return BannerStyle
    end)()
    GDK.BannerStyle = BannerStyle

    GDK.BannerStyle = BannerStyle

    BannerStyleAccessor = (function(super)
        local BannerStyleAccessor = declareClass("BannerStyleAccessor", super)
        function BannerStyleAccessor.prototype:constructor()
            --member properties
            self.x = nil
            self.y = nil
            self.left = nil
            self.top = nil
            self.width = nil
            self.height = nil
            self.realWidth = nil
            self.realHeight = nil
        end

        return BannerStyleAccessor
    end)()
    GDK.BannerStyleAccessor = BannerStyleAccessor

    GDK.BannerStyleAccessor = BannerStyleAccessor

    RewardedVideoAdOnErrorParam = (function(super)
        local RewardedVideoAdOnErrorParam = declareClass("RewardedVideoAdOnErrorParam", super)
        function RewardedVideoAdOnErrorParam.prototype:constructor()
            --member properties
            self.errMsg = nil
            self.errCode = nil
        end

        return RewardedVideoAdOnErrorParam
    end)()
    GDK.RewardedVideoAdOnErrorParam = RewardedVideoAdOnErrorParam

    GDK.RewardedVideoAdOnErrorParam = RewardedVideoAdOnErrorParam
    InterstitialAdOnErrorParam = (function(super)
        local InterstitialAdOnErrorParam = declareClass("InterstitialAdOnErrorParam", super)
        function InterstitialAdOnErrorParam.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return InterstitialAdOnErrorParam
    end)(RewardedVideoAdOnErrorParam)
    GDK.InterstitialAdOnErrorParam = InterstitialAdOnErrorParam

    GDK.InterstitialAdOnErrorParam = InterstitialAdOnErrorParam
    FullscreenAdOnErrorParam = (function(super)
        local FullscreenAdOnErrorParam = declareClass("FullscreenAdOnErrorParam", super)
        function FullscreenAdOnErrorParam.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return FullscreenAdOnErrorParam
    end)(RewardedVideoAdOnErrorParam)
    GDK.FullscreenAdOnErrorParam = FullscreenAdOnErrorParam

    GDK.FullscreenAdOnErrorParam = FullscreenAdOnErrorParam

    RewardVideoAdLoadParams = (function(super)
        local RewardVideoAdLoadParams = declareClass("RewardVideoAdLoadParams", super)
        function RewardVideoAdLoadParams.prototype:constructor()
            --member properties
            self.placementId = nil
        end

        return RewardVideoAdLoadParams
    end)()
    GDK.RewardVideoAdLoadParams = RewardVideoAdLoadParams

    GDK.RewardVideoAdLoadParams = RewardVideoAdLoadParams

    VideoAdSlot = (function(super)
        local VideoAdSlot = declareClass("VideoAdSlot", super)
        function VideoAdSlot.prototype:constructor()
            --member properties
            self.adPlatform = nil
            self.slotId = nil
            self.adPriority = nil
            self.appId = nil
        end

        return VideoAdSlot
    end)()
    GDK.VideoAdSlot = VideoAdSlot

    GDK.VideoAdSlot = VideoAdSlot

    FeedAdStyle = (function(super)
        local FeedAdStyle = declareClass("FeedAdStyle", super)
        function FeedAdStyle.prototype:constructor()
            --member properties
            self.x = nil
            self.y = nil
            self.width = nil
            self.height = nil
            self.top = nil
            self.left = nil
        end

        return FeedAdStyle
    end)()
    GDK.FeedAdStyle = FeedAdStyle

    GDK.FeedAdStyle = FeedAdStyle

    FeedAdStyleAccessor = (function(super)
        local FeedAdStyleAccessor = declareClass("FeedAdStyleAccessor", super)
        function FeedAdStyleAccessor.prototype:constructor()
            --member properties
            self.x = nil
            self.y = nil
            self.left = nil
            self.top = nil
            self.width = nil
            self.height = nil
            self.realWidth = nil
            self.realHeight = nil
        end

        return FeedAdStyleAccessor
    end)()
    GDK.FeedAdStyleAccessor = FeedAdStyleAccessor

    GDK.FeedAdStyleAccessor = FeedAdStyleAccessor
end)(GDK)

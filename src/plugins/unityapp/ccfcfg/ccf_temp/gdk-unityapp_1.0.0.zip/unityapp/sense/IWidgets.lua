local ShowConfirmResult
local ShowPromptResult
local ShowAlertResult
local ShowLoadingParams

local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    ShowConfirmResult = (function(super)
        local ShowConfirmResult = declareClass("ShowConfirmResult", super)
        function ShowConfirmResult.prototype:constructor()
            --member properties
            self.confirm = nil
            self.cancel = nil
            self.extra = nil
        end

        return ShowConfirmResult
    end)()
    GDK.ShowConfirmResult = ShowConfirmResult

    GDK.ShowConfirmResult = ShowConfirmResult
    ShowPromptResult = (function(super)
        local ShowPromptResult = declareClass("ShowPromptResult", super)
        function ShowPromptResult.prototype:constructor()
            --member properties
            self.confirm = nil
            self.cancel = nil
            self.result = nil
            self.extra = nil
        end

        return ShowPromptResult
    end)()
    GDK.ShowPromptResult = ShowPromptResult

    GDK.ShowPromptResult = ShowPromptResult

    ShowAlertResult = (function(super)
        local ShowAlertResult = declareClass("ShowAlertResult", super)
        function ShowAlertResult.prototype:constructor()
            --member properties
            self.extra = nil
        end

        return ShowAlertResult
    end)()
    GDK.ShowAlertResult = ShowAlertResult

    GDK.ShowAlertResult = ShowAlertResult

    ShowLoadingParams = (function(super)
        local ShowLoadingParams = declareClass("ShowLoadingParams", super)
        function ShowLoadingParams.prototype:constructor()
            --member properties
            self.title = nil
        end

        return ShowLoadingParams
    end)()
    GDK.ShowLoadingParams = ShowLoadingParams

    GDK.ShowLoadingParams = ShowLoadingParams
end)(GDK)

local OpenParam

local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    OpenParam = (function(super)
        local OpenParam = declareClass("OpenParam", super)
        function OpenParam.prototype:constructor()
            --member properties
            self.sessionFrom = ""
            self.showMessageCard = false
            self.sendMessageTitle = ""
            self.sendMessagePath = ""
            self.sendMessageImg = ""
            self.success = nil
            self.fail = nil
            self.complete = nil
        end

        return OpenParam
    end)()
    GDK.OpenParam = OpenParam

    GDK.OpenParam = OpenParam
end)(GDK)

local GDKConfigBase
local GDKDevelopConfig
local GDKWechatConfig
local GDKBytedanceConfig
local GDKQQMINIAPPConfig
local GDKQQPlayConfig
local GDKOPPOConfig
local GDKVIVOConfig
local GDKAPPConfig
local GDKGamepindConfig
local GDKWebConfig
local GDKWEBVIEWConfig
local GDKConfig
local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    GDKConfigBase = (function(super)
        local GDKConfigBase = declareClass("GDKConfigBase", super)
        function GDKConfigBase.prototype:constructor()
            --member properties
            self.mode = "develop"
            self.appId = ""
            self.gameVersion = nil
            self.httpClient = nil
            self.requireCustomServicePay = false
            self.requireMiniAppPay = false
            self.requireIndiaSPSPay = false
            self.getServerTime = nil
        end

        return GDKConfigBase
    end)()
    GDK.GDKConfigBase = GDKConfigBase

    GDK.GDKConfigBase = GDKConfigBase

    GDKDevelopConfig = (function(super)
        local GDKDevelopConfig = declareClass("GDKDevelopConfig", super)
        function GDKDevelopConfig.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return GDKDevelopConfig
    end)(GDKConfigBase)
    GDK.GDKDevelopConfig = GDKDevelopConfig

    GDK.GDKDevelopConfig = GDKDevelopConfig

    GDKWechatConfig = (function(super)
        local GDKWechatConfig = declareClass("GDKWechatConfig", super)
        function GDKWechatConfig.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.offerId = ""
            self.isPayInSandbox = true
            self.payAppEnvVersion = nil
            self.shareProxyUrl = ""
            self.userId = 0
            self.miniAppOfferId = ""

            --constructor logic
        end

        return GDKWechatConfig
    end)(GDKConfigBase)
    GDK.GDKWechatConfig = GDKWechatConfig

    GDK.GDKWechatConfig = GDKWechatConfig

    GDKBytedanceConfig = (function(super)
        local GDKBytedanceConfig = declareClass("GDKBytedanceConfig", super)
        function GDKBytedanceConfig.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return GDKBytedanceConfig
    end)(GDKWechatConfig)
    GDK.GDKBytedanceConfig = GDKBytedanceConfig

    GDK.GDKBytedanceConfig = GDKBytedanceConfig

    GDKQQMINIAPPConfig = (function(super)
        local GDKQQMINIAPPConfig = declareClass("GDKQQMINIAPPConfig", super)
        function GDKQQMINIAPPConfig.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.offerId = ""
            self.isPayInSandbox = true
            self.payAppEnvVersion = nil
            self.shareProxyUrl = ""
            self.userId = 0
            self.miniAppOfferId = ""

            --constructor logic
        end

        return GDKQQMINIAPPConfig
    end)(GDKConfigBase)
    GDK.GDKQQMINIAPPConfig = GDKQQMINIAPPConfig

    GDK.GDKQQMINIAPPConfig = GDKQQMINIAPPConfig

    GDKQQPlayConfig = (function(super)
        local GDKQQPlayConfig = declareClass("GDKQQPlayConfig", super)
        function GDKQQPlayConfig.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.gameType = nil

            --constructor logic
        end

        return GDKQQPlayConfig
    end)(GDKConfigBase)
    GDK.GDKQQPlayConfig = GDKQQPlayConfig

    GDK.GDKQQPlayConfig = GDKQQPlayConfig

    GDKOPPOConfig = (function(super)
        local GDKOPPOConfig = declareClass("GDKOPPOConfig", super)
        function GDKOPPOConfig.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.gameType = nil

            --constructor logic
        end

        return GDKOPPOConfig
    end)(GDKConfigBase)
    GDK.GDKOPPOConfig = GDKOPPOConfig

    GDK.GDKOPPOConfig = GDKOPPOConfig

    GDKVIVOConfig = (function(super)
        local GDKVIVOConfig = declareClass("GDKVIVOConfig", super)
        function GDKVIVOConfig.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.gameType = nil

            --constructor logic
        end

        return GDKVIVOConfig
    end)(GDKConfigBase)
    GDK.GDKVIVOConfig = GDKVIVOConfig

    GDK.GDKVIVOConfig = GDKVIVOConfig
    GDKAPPConfig = (function(super)
        local GDKAPPConfig = declareClass("GDKAPPConfig", super)
        function GDKAPPConfig.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.advertPlatform = "ironsource"
            self.advertPlatforms = Array({})

            --constructor logic
        end

        return GDKAPPConfig
    end)(GDKConfigBase)
    GDK.GDKAPPConfig = GDKAPPConfig

    GDK.GDKAPPConfig = GDKAPPConfig

    GDKGamepindConfig = (function(super)
        local GDKGamepindConfig = declareClass("GDKGamepindConfig", super)
        function GDKGamepindConfig.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return GDKGamepindConfig
    end)(GDKConfigBase)
    GDK.GDKGamepindConfig = GDKGamepindConfig

    GDK.GDKGamepindConfig = GDKGamepindConfig

    GDKWebConfig = (function(super)
        local GDKWebConfig = declareClass("GDKWebConfig", super)
        function GDKWebConfig.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return GDKWebConfig
    end)(GDKConfigBase)
    GDK.GDKWebConfig = GDKWebConfig

    GDK.GDKWebConfig = GDKWebConfig
    GDKWEBVIEWConfig = (function(super)
        local GDKWEBVIEWConfig = declareClass("GDKWEBVIEWConfig", super)
        function GDKWEBVIEWConfig.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.advertPlatform = "ironsource"
            self.advertPlatforms = Array({})

            --constructor logic
        end

        return GDKWEBVIEWConfig
    end)(GDKConfigBase)
    GDK.GDKWEBVIEWConfig = GDKWEBVIEWConfig

    GDK.GDKWEBVIEWConfig = GDKWEBVIEWConfig

    GDKConfig = (function(super)
        local GDKConfig = declareClass("GDKConfig", super)
        function GDKConfig.prototype:constructor()
            --member properties
            self.develop = nil
            self.baidu = nil
            self.wechat = nil
            self.bytedance = nil
            self.qqplay = nil
            self.oppo = nil
            self.app = nil
            self.qqminiapp = nil
            self.vivo = nil
            self.gamepind = nil
            self.web = nil
            self.webview = nil
        end

        return GDKConfig
    end)()
    GDK.GDKConfig = GDKConfig

    GDK.GDKConfig = GDKConfig
end)(GDK)

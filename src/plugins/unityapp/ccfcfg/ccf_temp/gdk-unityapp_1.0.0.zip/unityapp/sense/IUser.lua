local LoginResult
local LoginParams
local LoginPromise

local GDK = GDK or {}
_G.GDK = GDK
local _ = (function(GDK)
    extendsNSList({GDK, _G})

    -- export class LoginError extends ReqError { }

    --[[ 登录请求结果--]]
    LoginResult = (function(super)
        local LoginResult = declareClass("LoginResult", super)
        function LoginResult.prototype:constructor()
            --member properties
            self.extra = nil
        end

        return LoginResult
    end)()
    GDK.LoginResult = LoginResult

    GDK.LoginResult = LoginResult

    --[[ 登录错误码--]]
    -- export const LoginErrorCode = {
    -- 	...ReqErrorCode,
    -- 	INVALID_OPENID: 10001,
    -- }

    --[[ 登录结果模板--]]
    -- export const LoginResultTemplates = new ResultTemplatesExtractor<ReqError>([
    -- 	...ReqResultTemplates.temps,
    -- 	{ errCode: LoginErrorCode.INVALID_OPENID, msg: '登录失败', reason: 'openId验证失败' },
    -- ])

    --[[ 登录请求参数--]]
    LoginParams = (function(super)
        local LoginParams = declareClass("LoginParams", super)
        function LoginParams.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.pkgName = nil
            self.disableVisitor = false
            self.google = false
            self.facebook = false
            self.silent = false
            self.account = nil
            self.realName = nil
            self.autoLogin = true
            self.token = nil
            self.node = nil

            --constructor logic
        end

        return LoginParams
    end)(ReqParams)
    GDK.LoginParams = LoginParams

    GDK.LoginParams = LoginParams

    LoginPromise = (function(super)
        local LoginPromise = declareClass("LoginPromise", super)
        function LoginPromise.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return LoginPromise
    end)(Promise)
    GDK.LoginPromise = LoginPromise

    GDK.LoginPromise = LoginPromise
end)(GDK)

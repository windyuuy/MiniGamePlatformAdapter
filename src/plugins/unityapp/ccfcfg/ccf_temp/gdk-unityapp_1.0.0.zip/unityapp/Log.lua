local Log
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    Log =
        (function(super)
        local Log = declareClass("Log", super)

        --[[
		 * 提交自定义日志到服务器
		 * @param key key
		 * @param params 参数
		--]]
        Log.prototype.commitLog =
            __JS_Async(
            function(self, key, params)
                LogBridge:logCustomEvent(key, params)
            end
        )

        Log.prototype.commitChannelsLog =
            __JS_Async(
            function(self, logType, params)
                if logType == "PayLog" then
                    local p = params
                    LogBridge:logRequestPay(p.id, p.price, p.count, p.currency)
                elseif logType == "Paid" then
                    local p = params
                    LogBridge:logPurchased(p.id, p.price, p.price, p.count, p.currency, p.succ)
                else
                    console:error("unsupport log type")
                end
            end
        )

        Log.prototype.commitPayLog =
            __JS_Async(
            function(self, index)
                local key = ""
                local __SWITCH1__ = index
                if __SWITCH1__ == 1 then
                    key = "fb_mobile_add_to_cart"
                    goto SWITCH1
                end
                if __SWITCH1__ == 2 then
                    key = "fb_mobile_spent_credits"
                    goto SWITCH1
                end
                if __SWITCH1__ == 3 then
                    key = "fb_mobile_content_view"
                    goto SWITCH1
                end
                if __SWITCH1__ == 4 then
                    key = "Subscribe"
                    goto SWITCH1
                end
                if __SWITCH1__ == 5 then
                    key = "fb_mobile_search"
                    goto SWITCH1
                end
                if __SWITCH1__ == 6 then
                    key = "fb_mobile_tutorial_completion"
                    goto SWITCH1
                end

                ::SWITCH1::

                if key.length > 0 then
                    self:commitLog(key, {})
                else
                    console:error("unsupport PayLog index")
                end
            end
        )
        function Log.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return Log
    end)(GDK.ILog)
    UnityAppGDK.Log = Log

    UnityAppGDK.Log = Log
end)(UnityAppGDK)

local NativeHelper
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    NativeHelper =
        (function(super)
        local NativeHelper = declareClass("NativeHelper", super)

        function NativeHelper.prototype:checkActionExist(key)
            if gdkjsb.nativeVersion and gdkjsb.nativeVersion >= 1 then
                return gdkjsb.bridge:checkActionExist(key)
            end
            return false
        end

        NativeHelper.prototype.safeCallAction =
            __JS_Async(
            function(self, key, params)
                if nativeHelper:checkActionExist(key) then
                    return self:callAction(key, params)
                else
                    console:log(
                        [==[skip call <]==] ..
                            tostring(key) ..
                                [==[> function, which not implement for current sdk version ]==] ..
                                    tostring(gdkjsb.nativeVersion) .. [==[]==]
                    )
                end
                return nil
            end
        )

        NativeHelper.prototype.callAction =
            __JS_Async(
            function(self, key, params)
                return Promise(
                    function(resolve, reject)
                        gdkjsb.bridge:callAction(
                            key,
                            JSON:stringify(params),
                            function(data)
                                resolve(JSON:parse(data or nil))
                            end
                        )
                    end
                )
            end
        )

        NativeHelper.prototype.onEvent =
            __JS_Async(
            function(self, key, callback)
                local id =
                    gdkjsb.bridge:on(
                    key,
                    function(data)
                        console:log("ironsrc:onEvent:", key, data)
                        callback(JSON:parse(data)["params"])
                    end
                )
            end
        )

        NativeHelper.prototype.onDoneEvent =
            __JS_Async(
            function(self, key, callback)
                local id =
                    gdkjsb.bridge:on(
                    key,
                    function(data)
                        console:log("ironsrc:onEvent:", key, data)
                        callback()
                    end
                )
            end
        )
        function NativeHelper.prototype:constructor()
        end

        return NativeHelper
    end)()
    UnityAppGDK.NativeHelper = NativeHelper

    UnityAppGDK.NativeHelper = NativeHelper
    local nativeHelper = NativeHelper()
    UnityAppGDK.nativeHelper = nativeHelper
    UnityAppGDK.nativeHelper = nativeHelper
end)(UnityAppGDK)

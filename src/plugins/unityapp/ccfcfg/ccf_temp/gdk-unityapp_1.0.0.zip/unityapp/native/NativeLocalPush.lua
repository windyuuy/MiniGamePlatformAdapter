local NativeLocalPushStyle
local NativeLocalPush
--/ <reference path="./NativeHelper.ts" />
--/ <reference path="../../../framework/sense/ILocalPush.ts" />

local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    NativeLocalPushStyle = (function(super)
        local NativeLocalPushStyle = declareClass("NativeLocalPushStyle", super)
        function NativeLocalPushStyle.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return NativeLocalPushStyle
    end)(GDK.LocalPushBundle)
    UnityAppGDK.NativeLocalPushStyle = NativeLocalPushStyle

    UnityAppGDK.NativeLocalPushStyle = NativeLocalPushStyle

    NativeLocalPush =
        (function(super)
        local NativeLocalPush = declareClass("NativeLocalPush", super)

        --[[
		 * 初始化
		--]]
        NativeLocalPush.prototype.init =
            __JS_Async(
            function(self)
                return nativeHelper:callAction("pushwrapper:initLocalNotice", {})
            end
        )

        --[[
		 * 添加本地推送
		--]]
        NativeLocalPush.prototype.addLocalNotices =
            __JS_Async(
            function(self, notices)
                local params = {
                    notices = notices or Array({})
                }
                return nativeHelper:callAction("pushwrapper:addLocalNotices", params)
            end
        )

        --[[
		 * 移除对应的推送
		--]]
        NativeLocalPush.prototype.removeLocalNoticeWithID =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("pushwrapper:removeLocalNoticeWithID", params)
            end
        )

        --[[
		 * 移除所有推送
		--]]
        NativeLocalPush.prototype.removeAllLocalNotices =
            __JS_Async(
            function(self)
                return nativeHelper:callAction("pushwrapper:removeAllLocalNotices", {})
            end
        )

        --[[
		 * 检查推送设置，如果没有权限则提示用户跳转开启
		--]]
        NativeLocalPush.prototype.requireLocalNoticePermission =
            __JS_Async(
            function(self)
                return nativeHelper:callAction("pushwrapper:requireLocalNoticePermission", {})
            end
        )

        --[[
		 * 用户是否开启通知权限
		--]]
        NativeLocalPush.prototype.isLocalNoticeEnabled =
            __JS_Async(
            function(self)
                return nativeHelper:callAction("pushwrapper:isLocalNoticeEnabled", {})
            end
        )
        function NativeLocalPush.prototype:constructor()
        end

        return NativeLocalPush
    end)()
    UnityAppGDK.NativeLocalPush = NativeLocalPush

    UnityAppGDK.NativeLocalPush = NativeLocalPush
end)(UnityAppGDK)

local Placement
local IronSourceError
local NativeAdvert
--/ <reference path="./NativeHelper.ts" />

local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local IronSrc = UnityAppGDK.IronSrc or {}
    UnityAppGDK.IronSrc = IronSrc
    local _ = (function(IronSrc)
        extendsNSList({UnityAppGDK.IronSrc, UnityAppGDK, _G})

        Placement = (function(super)
            local Placement = declareClass("Placement", super)
            function Placement.prototype:constructor()
                --member properties
                self.rewardName = nil
                self.rewardAmount = nil
                self.placementName = nil
                self.placementId = nil
                self.placementAvailabilitySettings = nil
            end

            return Placement
        end)()
        IronSrc.Placement = Placement

        IronSrc.Placement = Placement

        IronSourceError = (function(super)
            local IronSourceError = declareClass("IronSourceError", super)
            function IronSourceError.prototype:constructor()
                --member properties
                self.errorMsg = nil
                self.errorCode = nil
            end

            return IronSourceError
        end)()
        IronSrc.IronSourceError = IronSourceError

        IronSrc.IronSourceError = IronSourceError
    end)(IronSrc)

    NativeAdvert =
        (function(super)
        local NativeAdvert = declareClass("NativeAdvert", super)

        --[[
		 * @param params.appKey 可选参数，如果安卓项目中已经填写 ironsource_advert_appkey ，那么此处可不传入
		 * @param params.modules 指定支持的广告模块，可选 key 为：`REWARDED_VIDEO`,`BANNER`,`INTERSTITIAL`,`OFFERWALL`
		--]]
        NativeAdvert.prototype.init =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.init", params)
            end
        )

        --[[
		 * 验证广告集成
		--]]
        NativeAdvert.prototype.validateIntegration =
            __JS_Async(
            function(self)
                return nativeHelper:callAction("ironsrc:IntegrationHelper.validateIntegration", {})
            end
        )

        NativeAdvert.prototype.shouldTrackNetworkState =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.shouldTrackNetworkState", params)
            end
        )

        NativeAdvert.prototype.setAdaptersDebug =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:banner.setAdaptersDebug", params)
            end
        )

        --[[
		 * 事件通知流程
		 * # 从播放视频到重新加载
		 * - onRewardedVideoAvailabilityChanged -> true
		 * - onRewardedVideoAdOpened
		 * - onRewardedVideoAdRewarded
		 * - onRewardedVideoAvailabilityChanged -> false
		 * - onRewardedVideoAdClosed
		 * - onRewardedVideoAvailabilityChanged -> true
		--]]
        NativeAdvert.prototype.setRewardedVideoListener =
            __JS_Async(
            function(self)
                return nativeHelper:callAction("ironsrc:IronSource.setRewardedVideoListener", {})
            end
        )

        --[[
		 * 监听广告打开播放
		--]]
        NativeAdvert.prototype.onRewardedVideoAdOpened =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onRewardedVideoAdOpened", callback)
            end
        )

        --[[
		 * 监听广告关闭
		--]]
        NativeAdvert.prototype.onRewardedVideoAdClosed =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onRewardedVideoAdClosed", callback)
            end
        )

        --[[
		 * 通知当前视频是否已加载
		--]]
        NativeAdvert.prototype.onRewardedVideoAvailabilityChanged =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onEvent("ironsrc:onRewardedVideoAvailabilityChanged", callback)
            end
        )

        --[[
		 * 监听广告开始播放
		--]]
        NativeAdvert.prototype.onRewardedVideoAdStarted =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onRewardedVideoAdStarted", callback)
            end
        )

        --[[
		 * 监听广告播放结束
		--]]
        NativeAdvert.prototype.onRewardedVideoAdEnded =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onRewardedVideoAdEnded", callback)
            end
        )

        --[[
		 * 监听广告可发放奖励
		--]]
        NativeAdvert.prototype.onRewardedVideoAdRewarded =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onEvent("ironsrc:onRewardedVideoAdRewarded", callback)
            end
        )

        NativeAdvert.prototype.onRewardedVideoAdShowFailed =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onEvent("ironsrc:onRewardedVideoAdShowFailed", callback)
            end
        )

        NativeAdvert.prototype.onRewardedVideoAdClicked =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onEvent("ironsrc:onRewardedVideoAdClicked", callback)
            end
        )

        NativeAdvert.prototype.loadRewardVideoAd =
            __JS_Async(
            function(self, loadParams)
                if __JS_TypeOf(loadParams) ~= "object" then
                    loadParams = {}
                end

                local key = "ironsrc:IronSource.loadRewardVideoAd"
                -- if (nativeHelper.checkActionExist(key)) {
                -- 	return nativeHelper.callAction<{}>(key, {})
                -- } else {
                -- 	console.log(`skip call <${key}> function, which not implement for current sdk version`)
                -- }
                return nativeHelper:safeCallAction(key, loadParams) or {}
            end
        )

        NativeAdvert.prototype.isRewardedVideoAvailable =
            __JS_Async(
            function(self, loadParams)
                return nativeHelper:callAction("ironsrc:IronSource.isRewardedVideoAvailable", loadParams or {})
            end
        )

        NativeAdvert.prototype.showRewardedVideo =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.showRewardedVideo", params)
            end
        )

        --[[
		 * 事件通知流程
		 * # 从播放视频到重新加载
		 * - onFullScreenVideoAvailabilityChanged -> true
		 * - onFullScreenVideoAdStarted
		 * - onFullScreenVideoAdSkipped
		 * - onFullScreenVideoAdComplete
		 * - onFullScreenVideoAdClosed
		 * - onFullScreenVideoAvailabilityChanged -> false
		 * - load
		 * - onFullScreenVideoAvailabilityChanged -> true
		 * - onFullScreenVideoAdCached
		--]]
        NativeAdvert.prototype.setFullScreenVideoListener =
            __JS_Async(
            function(self)
                return nativeHelper:callAction("ironsrc:IronSource.setFullScreenVideoListener", {})
            end
        )

        NativeAdvert.prototype.loadFullScreenVideoAd =
            __JS_Async(
            function(self)
                local key = "ironsrc:IronSource.loadFullScreenVideoAd"
                -- if (nativeHelper.checkActionExist(key)) {
                -- 	return nativeHelper.callAction<{}>(key, {})
                -- } else {
                -- 	console.log(`skip call <${key}> function, which not implement for current sdk version`)
                -- }
                return nativeHelper:safeCallAction(key, {}) or {}
            end
        )

        NativeAdvert.prototype.isFullScreenVideoAvailable =
            __JS_Async(
            function(self)
                return nativeHelper:callAction("ironsrc:IronSource.isFullScreenVideoAvailable", {})
            end
        )

        NativeAdvert.prototype.showFullScreenVideo =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.showFullScreenVideo", params)
            end
        )

        -- --[[
        --  * 监听广告打开播放
        -- --]]
        -- async onFullScreenVideoAdOpened(callback: Function) {
        -- 	return nativeHelper.onDoneEvent("ironsrc:onFullScreenVideoAdOpened", callback)
        -- }
        --[[
		 * 监听广告关闭
		--]]
        NativeAdvert.prototype.onFullScreenVideoAdClosed =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onFullScreenVideoAdClosed", callback)
            end
        )

        --[[
		 * 通知当前视频是否已加载
		--]]
        NativeAdvert.prototype.onFullScreenVideoAvailabilityChanged =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onEvent("ironsrc:onFullScreenVideoAvailabilityChanged", callback)
            end
        )

        --[[
		 * 监听广告开始播放
		--]]
        NativeAdvert.prototype.onFullScreenVideoAdStarted =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onFullScreenVideoAdStarted", callback)
            end
        )

        -- --[[
        --  * 监听广告播放结束
        -- --]]
        -- async onFullScreenVideoAdEnded(callback: Function) {
        -- 	return nativeHelper.onDoneEvent("ironsrc:onFullScreenVideoAdEnded", callback)
        -- }
        --[[
		 * 全屏广告完全播完会回调
		--]]
        NativeAdvert.prototype.onFullScreenVideoAdComplete =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onEvent("ironsrc:onFullScreenVideoAdComplete", callback)
            end
        )

        NativeAdvert.prototype.onFullScreenVideoAdShowFailed =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onEvent("ironsrc:onFullScreenVideoAdShowFailed", callback)
            end
        )

        -- async onFullScreenVideoAdClicked(callback: (data: IronSrc.Placement) => void) {
        -- 	return nativeHelper.onEvent("ironsrc:onFullScreenVideoAdClicked", callback)
        -- }

        -- banner advert
        NativeAdvert.prototype.createBanner =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.createBanner", params)
            end
        )

        NativeAdvert.prototype.setBannerListener =
            __JS_Async(
            function(self)
                return nativeHelper:callAction("ironsrc:banner.setBannerListener", {})
            end
        )

        NativeAdvert.prototype.setBannerAdvertVisibility =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:banner.setVisibility", params)
            end
        )

        NativeAdvert.prototype.loadBanner =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.loadBanner", params)
            end
        )

        NativeAdvert.prototype.setBannerStyle =
            __JS_Async(
            function(self, style)
                return nativeHelper:callAction("ironsrc:IronSource.setBannerStyle", style)
            end
        )

        NativeAdvert.prototype.destroyBanner =
            __JS_Async(
            function(self)
                return nativeHelper:callAction("ironsrc:IronSource.destroyBanner", {})
            end
        )

        -- banner advert 事件
        NativeAdvert.prototype.onBannerAdLoaded =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onBannerAdLoaded", callback)
            end
        )

        NativeAdvert.prototype.onBannerAdLoadFailed =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onEvent("ironsrc:onBannerAdLoadFailed", callback)
            end
        )

        NativeAdvert.prototype.onBannerAdClicked =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onBannerAdClicked", callback)
            end
        )

        NativeAdvert.prototype.onBannerAdScreenPresented =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onBannerAdScreenPresented", callback)
            end
        )

        NativeAdvert.prototype.onBannerAdScreenDismissed =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onBannerAdScreenDismissed", callback)
            end
        )

        NativeAdvert.prototype.onBannerAdLeftApplication =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onBannerAdLeftApplication", callback)
            end
        )

        -- Interstitial
        --[[
		 * 验证广告集成
		--]]
        NativeAdvert.prototype.setInterstitialListener =
            __JS_Async(
            function(self)
                return nativeHelper:callAction("ironsrc:IronSource.setInterstitialListener", {})
            end
        )

        NativeAdvert.prototype.loadInterstitial =
            __JS_Async(
            function(self)
                return nativeHelper:callAction("ironsrc:IronSource.loadInterstitial", {})
            end
        )

        NativeAdvert.prototype.isInterstitialReady =
            __JS_Async(
            function(self)
                return nativeHelper:callAction("ironsrc:IronSource.isInterstitialReady", {})
            end
        )

        NativeAdvert.prototype.showInterstitial =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.showInterstitial", params)
            end
        )

        -- Interstitial advert 事件
        NativeAdvert.prototype.onInterstitialAdRewarded =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onInterstitialAdRewarded", callback)
            end
        )

        NativeAdvert.prototype.onInterstitialAdClosed =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onInterstitialAdClosed", callback)
            end
        )

        --[[
		 * Invoked when there is no Interstitial Ad available after calling load function.
		--]]
        NativeAdvert.prototype.onInterstitialAdReady =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onInterstitialAdReady", callback)
            end
        )

        NativeAdvert.prototype.onInterstitialAdLoadFailed =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onEvent("ironsrc:onInterstitialAdLoadFailed", callback)
            end
        )

        NativeAdvert.prototype.onInterstitialAdClicked =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onInterstitialAdClicked", callback)
            end
        )

        NativeAdvert.prototype.onInterstitialAdOpened =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onInterstitialAdOpened", callback)
            end
        )

        NativeAdvert.prototype.onInterstitialAdShowSucceeded =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onInterstitialAdShowSucceeded", callback)
            end
        )

        NativeAdvert.prototype.onInterstitialAdShowFailed =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onEvent("ironsrc:onInterstitialAdShowFailed", callback)
            end
        )

        -- feed advert
        NativeAdvert.prototype.createFeedAd =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.createFeedAd", params)
            end
        )

        NativeAdvert.prototype.setFeedAdVisibility =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.setFeedAdVisibility", params)
            end
        )

        NativeAdvert.prototype.loadFeedAd =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.loadFeedAd", params)
            end
        )

        NativeAdvert.prototype.setFeedAdStyle =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.setFeedAdStyle", params)
            end
        )

        NativeAdvert.prototype.setFeedAdClickZoneStyle =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.setFeedAdDefaultClickZoneStyle", params)
            end
        )

        NativeAdvert.prototype.destroyFeedAd =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.destroyFeedAd", params)
            end
        )

        NativeAdvert.prototype.getFeedAdDatas =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.getFeedAdDatas", params)
            end
        )

        NativeAdvert.prototype.performClick =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.performClick", params)
            end
        )

        NativeAdvert.prototype.performCreativeClick =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("ironsrc:IronSource.performCreativeClick", params)
            end
        )

        -- feed advert 事件
        NativeAdvert.prototype.onFeedAdLoaded =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onEvent("ironsrc:onFeedAdLoaded", callback)
            end
        )

        NativeAdvert.prototype.onFeedAdLoadFailed =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onEvent("ironsrc:onFeedAdLoadFailed", callback)
            end
        )

        NativeAdvert.prototype.onFeedAdClicked =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onFeedAdClicked", callback)
            end
        )

        NativeAdvert.prototype.onFeedAdShown =
            __JS_Async(
            function(self, callback)
                return nativeHelper:onDoneEvent("ironsrc:onFeedAdShown", callback)
            end
        )

        --[[
		  * 广告平台选择
		  * - gdtadvert 广点通
		  * - budadadvert 头条广告
		--]]
        NativeAdvert.prototype.advertPlatformSelect =
            __JS_Async(
            function(self, platform)
                if gdkjsb.bridge == nil then
                    return
                end
                return nativeHelper:safeCallAction("advertPlatformSelect", {message = platform})
            end
        )

        NativeAdvert.prototype.initMultAdSlot =
            __JS_Async(
            function(self, params)
                if gdkjsb.bridge == nil then
                    return
                end
                return nativeHelper:safeCallAction("initMultAdSlot", {slotInfo = params})
            end
        )
        function NativeAdvert.prototype:constructor()
        end

        return NativeAdvert
    end)()
    UnityAppGDK.NativeAdvert = NativeAdvert

    UnityAppGDK.NativeAdvert = NativeAdvert
end)(UnityAppGDK)

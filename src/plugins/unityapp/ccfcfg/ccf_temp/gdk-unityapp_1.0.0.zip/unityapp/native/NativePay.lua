local NativePayResult
local NativePay
--/ <reference path="./NativeHelper.ts" />

local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local PayErrorCode = {}
    PayErrorCode.BIND_GOOGLE_SERVICE_FAILED = 0
    PayErrorCode[0] = "BIND_GOOGLE_SERVICE_FAILED"
    PayErrorCode.SEND_PAY_REQUEST_FAILED = 1
    PayErrorCode[1] = "SEND_PAY_REQUEST_FAILED"
    PayErrorCode.CATCH_EXCEPTIONS = 2
    PayErrorCode[2] = "CATCH_EXCEPTIONS"
    PayErrorCode.PURCHASE_CANCELLED = 3
    PayErrorCode[3] = "PURCHASE_CANCELLED"
    PayErrorCode.ON_CODE_REQUEST_GPV3 = 4
    PayErrorCode[4] = "ON_CODE_REQUEST_GPV3"
    PayErrorCode.OWNED_SUCH_ITEM = 5
    PayErrorCode[5] = "OWNED_SUCH_ITEM"
    PayErrorCode.INVALID_PARAMS = 6
    PayErrorCode[6] = "INVALID_PARAMS"
    --[[
		 * 依赖的app未安装
		--]]
    PayErrorCode.DEPENDENCE_APP_NOT_INSTALLED = 7
    PayErrorCode[7] = "DEPENDENCE_APP_NOT_INSTALLED"
    UnityAppGDK.PayErrorCode = PayErrorCode

    UnityAppGDK.PayErrorCode = PayErrorCode
    NativePayResult = (function(super)
        local NativePayResult = declareClass("NativePayResult", super)
        function NativePayResult.prototype:constructor()
            --member properties
            self.code = nil
            self.data = nil
            self.message = nil
        end

        return NativePayResult
    end)()
    UnityAppGDK.NativePayResult = NativePayResult

    UnityAppGDK.NativePayResult = NativePayResult
    NativePay =
        (function(super)
        local NativePay = declareClass("NativePay", super)

        --[[
		 * @param sku: 商品id
		--]]
        NativePay.prototype.initPay =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("paywrapper:initPay", params)
            end
        )

        --[[
		 * @param sku: 商品id
		--]]
        NativePay.prototype.requestPay =
            __JS_Async(
            function(self, params)
                params.coopOrder = "GleeOrderX"
                return nativeHelper:callAction("paywrapper:requestPay", params)
            end
        )

        --[[
		 * 消耗商品
		--]]
        NativePay.prototype.consumePurchase =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("paywrapper:consumePurchase", params)
            end
        )

        --[[
		 * 获取未消耗商品列表
		--]]
        NativePay.prototype.queryItemInfo =
            __JS_Async(
            function(self, params)
                return nativeHelper:callAction("paywrapper:queryItemInfo", params)
            end
        )
        function NativePay.prototype:constructor()
        end

        return NativePay
    end)()
    UnityAppGDK.NativePay = NativePay

    UnityAppGDK.NativePay = NativePay
end)(UnityAppGDK)

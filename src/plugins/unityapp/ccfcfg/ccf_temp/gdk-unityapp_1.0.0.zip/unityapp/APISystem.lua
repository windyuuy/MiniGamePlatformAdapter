local APISystem
--/ <reference path="./SDKProxy.ts" />
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    APISystem =
        (function(super)
        local APISystem = declareClass("APISystem", super)

        function APISystem.prototype:init()
            super.prototype.init(self)

            --侦听show hide
            if gdkjsb.bridge then
                gdkjsb.bridge:on(
                    "app:show",
                    function(data)
                        local jsonData = nil
                        __JS_Try(
                            function()
                                jsonData = JSON:parse(data)
                            end,
                            function(e)
                            end
                        )

                        do
                            local ___temp = self._showList:concat()
                            for ___i = 0, ___temp.length - 1 do
                                local f = ___temp[___i]

                                f(jsonData)
                            end
                        end
                    end
                )
                gdkjsb.bridge:on(
                    "app:hide",
                    function(data)
                        local jsonData = nil
                        __JS_Try(
                            function()
                                jsonData = JSON:parse(data)
                            end,
                            function(e)
                            end
                        )

                        do
                            local ___temp = self._hideList:concat()
                            for ___i = 0, ___temp.length - 1 do
                                local f = ___temp[___i]

                                f(jsonData)
                            end
                        end
                    end
                )
            end
        end

        function APISystem.prototype:getSafeArea(callback)
            if gdkjsb.bridge == nil then
                --兼容无gdkjsb的包
                callback({left = 0, right = 0, top = 0, bottom = 0})
            else
                if
                    gdkjsb.bridge:callAction(
                        "DisplayCutout:getSafeArea",
                        "{}",
                        function(data)
                            callback(JSON:parse(data))
                        end
                    ) ~= true
                 then
                    --兼容 nativeVersion == 0
                    callback({left = 0, right = 0, top = 0, bottom = 0})
                end
            end
        end
        function APISystem.prototype:__getter__nativeVersion()
            return gdkjsb.nativeVersion or 0
        end

        function APISystem.prototype:openURL(url)
            gdkjsb:openURL(url)
        end

        function APISystem.prototype:startYunkefu(accessId, name, id, customField, native)
            if native then
                gdkjsb.bridge:callAction(
                    "showsAssistantCenter",
                    JSON:stringify({name = name, id = id, customField = customField}),
                    function(data)
                    end
                )
                return
            end

            -- if (nativeHelper.checkActionExist("StartYunkefu")) {
            -- 	nativeHelper.callAction("StartYunkefu", { accessId: accessId, name: name, id: id, customField: customField })
            -- } else {
            local otherParams = {
                nickName = name
            }
            gdk:openURL(
                encodeURI(
                    [==[https://ykf-webchat.7moor.com/wapchat.html?accessId=]==] ..
                        tostring(accessId) ..
                            [==[&clientId=]==] ..
                                tostring(id) ..
                                    [==[&otherParams=]==] ..
                                        tostring(JSON:stringify(otherParams)) ..
                                            [==[&fromUrl=]==] ..
                                                tostring(gdk.systemInfo.packageName) ..
                                                    [==[&urlTitle=]==] ..
                                                        tostring(gdk.systemInfo.packageTag) ..
                                                            [==[&customField=]==] ..
                                                                tostring(JSON:stringify(customField)) .. [==[]==]
                )
            )
        end

        function APISystem.prototype:hasNativeAssistantCenter()
            return gdkjsb.bridge:checkActionExist("showsAssistantCenter")
        end

        function APISystem.prototype:showHackWeb(url, duration)
            if gdkjsb.showHackWeb then
                gdkjsb:showHackWeb(url, duration)
            end
        end

        function APISystem.prototype:setSDKLanguage(lang)
            if gdkjsb.setSDKLanguage then
                gdkjsb:setSDKLanguage(lang)
            end
        end

        function APISystem.prototype:onShow(callback)
            self._showList:push(callback)
        end

        function APISystem.prototype:offShow(callback)
            self._showList:remove(callback)
        end

        function APISystem.prototype:onHide(callback)
            self._hideList:push(callback)
        end

        function APISystem.prototype:offHide(callback)
            self._hideList:remove(callback)
        end

        APISystem.prototype.gotoAppSystemSettings =
            __JS_Async(
            function(self, params)
                -- return nativeHelper.safeCallAction("utils:gotoAppSystemSettings", params)
                return Promise(
                    function(resolve, reject)
                        gdkjsb:gotoAppSystemSettings(
                            JSON:stringify(params),
                            function(p)
                                resolve(JSON:parse(p or "null"))
                            end
                        )
                    end
                )
            end
        )

        APISystem.prototype.checkAppSystemPermissions =
            __JS_Async(
            function(self, params)
                -- return nativeHelper.safeCallAction<GDK.ICheckPermissionResult>("utils:checkAppSystemPermissions", params)
                return Promise(
                    function(resolve, reject)
                        gdkjsb:checkAppSystemPermissions(
                            JSON:stringify(params),
                            function(p)
                                resolve(JSON:parse(p or "null"))
                            end
                        )
                    end
                )
            end
        )

        function APISystem.prototype:exitProgram()
            local ret = GDK.RPromise()
            if gdkjsb.exitProgram then
                gdkjsb:exitProgram()
            end
            setTimeout(
                function()
                    ret:success()
                end,
                0
            )
            return ret.promise
        end
        function APISystem.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self._showList = Array({})
            self._hideList = Array({})

            --constructor logic
        end

        return APISystem
    end)(GDK.APISystemBase)
    UnityAppGDK.APISystem = APISystem

    UnityAppGDK.APISystem = APISystem
end)(UnityAppGDK)

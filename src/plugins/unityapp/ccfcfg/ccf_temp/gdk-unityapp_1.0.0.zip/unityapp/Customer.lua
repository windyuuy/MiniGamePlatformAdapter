local Customer

local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    --[[ 客服--]]
    Customer =
        (function(super)
        local Customer = declareClass("Customer", super)

        Customer.prototype.openCustomerServiceConversation =
            __JS_Async(
            function(self, params)
                self.api:showAlert({content = "你成功打开了客服界面", title = "客服界面测试"})
                return nil
            end
        )
        function Customer.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.api = nil

            --constructor logic
        end

        return Customer
    end)(GDK.ICustomer)
    UnityAppGDK.Customer = Customer

    UnityAppGDK.Customer = Customer
end)(UnityAppGDK)

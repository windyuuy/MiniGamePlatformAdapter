local SDKProxy
--/ <reference path="./native/NativeAdvert.ts" />
--/ <reference path="./native/NativePay.ts" />
--/ <reference path="./native/NativeLocalPush.ts" />

local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    --[[
	 * 用户信息本地存储的key
	--]]
    local USER_INFO_KEY = "$OFNIRESU$"
    local USER_INFO_XXTEA_KEY = "key$OFNIRESU$key"

    SDKProxy =
        (function(super)
        local SDKProxy = declareClass("SDKProxy", super)

        --[[
		 * 加载用户登陆信息
		--]]
        function SDKProxy:loadUserRecord(removeNullUser)
            local ___isr, ___rv
            if removeNullUser == nil then
                removeNullUser = false
            end
            local ret
            __JS_Try(
                function()
                    local data = localStorage:getItem(USER_INFO_KEY)
                    if data and data ~= "" then
                        console:log("loadUserRecord:", slib.xxtea:decryptFromBase64(data, USER_INFO_XXTEA_KEY))
                        local d = JSON:parse(slib.xxtea:decryptFromBase64(data, USER_INFO_XXTEA_KEY))
                        local list = (__JS_InstanceOf(d, Array)) and (d) or (Array({d}))
                        if list.length == 0 or list[0].loginType == nil then --简单验证一下
                            ___rv = {Array({})}
                            ___isr = true
                            return table.unpack(___rv)
                        end

                        --删除openId等于空的记录，一般由登陆失败产生
                        if removeNullUser then
                            local i = list.length - 1
                            while i >= 0 do
                                if list[i].openId == nil then
                                    list:splice(i, 1)
                                end
                                i = i - 1
                            end
                        end
                        ___rv = {list}
                        ___isr = true
                        return table.unpack(___rv)
                    else
                        console:log("loadUserRecord: nil")
                    end
                    ___rv = {Array({})}
                    ___isr = true
                    return table.unpack(___rv)
                end,
                function(e)
                    ___rv = {Array({})}
                    ___isr = true
                    return table.unpack(___rv)
                end
            )
            if ___isr then
                return table.unpack(___rv)
            end
        end

        --[[
		 * 保存登陆信息
		 * @param data 
		--]]
        function SDKProxy:saveUserRecord(data)
            local str = JSON:stringify(data)
            local xxt = slib.xxtea:encryptToBase64(str, USER_INFO_XXTEA_KEY)
            console:log("saveUserRecord:", USER_INFO_KEY, str, xxt)
            localStorage:setItem(USER_INFO_KEY, xxt)
        end

        --[[
		 * 显示普通菊花
		--]]
        function SDKProxy:showLoading()
            if gdkjsb.bridge == nil then
                return
            end
            gdkjsb.bridge:callAction(
                "showLoading",
                "{}",
                function(data)
                end
            )
        end

        --[[
		 * 隐藏普通菊花
		--]]
        function SDKProxy:hideLoading()
            if gdkjsb.bridge == nil then
                return
            end
            gdkjsb.bridge:callAction(
                "hideLoading",
                "{}",
                function(data)
                end
            )
        end

        --[[
		 * 隐藏正在登陆提示
		--]]
        function SDKProxy:hideLogining()
            if gdkjsb.bridge == nil then
                return
            end
            gdkjsb.bridge:callAction(
                "hideLogining",
                "{}",
                function(data)
                end
            )
        end

        --[[
		 * 显示正在登陆提示
		 * @param message 提示信息
		--]]
        function SDKProxy:showLogining(message, loginType)
            if gdkjsb.bridge == nil then
                return
            end
            if message == nil or message == "" then
                message = slib.i18n:locSDKString("welcome")
            end
            gdkjsb.bridge:callAction(
                "showLogining",
                JSON:stringify({message = message, loginType = loginType}),
                function(data)
                end
            )
        end

        --[[
		 * 登陆登陆弹框
		 * @param callback 玩家登陆的回掉
		--]]
        function SDKProxy:showLoginDialog()
            if gdkjsb.bridge == nil then
                return
            end

            gdkjsb.bridge:callAction(
                "showLoginDialog",
                JSON:stringify({support = self.support, records = self:loadUserRecord(true)}),
                function(data)
                end
            )
        end

        --[[
		 * 隐藏登陆对话框
		--]]
        function SDKProxy:hideLoginDialog()
            if gdkjsb.bridge == nil then
                return
            end

            gdkjsb.bridge:callAction(
                "hideLoginDialog",
                "{}",
                function(data)
                end
            )
        end

        function SDKProxy:loginWithBus(loginInfo, callbacks)
            if gdkjsb.bridge == nil then
                return
            end

            local aaa = ServedLoginInfo()
            aaa.loginNode = "2342"
            console:log("JSON.stringify(loginInfo):" .. JSON:stringify({}))
            gdkjsb.bridge:callAction(
                "loginWithBus",
                "{}",
                function(sdata)
                    local data = JSON:parse(sdata)
                    if data.succeed then
                        local ret = LoginServerResult()
                        ret.serverData = data.data.rawData.r
                        console:log("loginWithBus ret:" .. JSON:stringify(ret))
                        callbacks:onSuccess(ret)
                    else
                        console:log("loginWithBus failed:" .. JSON:stringify(data.data))
                        callbacks:onFailed(data.data)
                    end
                end
            )
        end

        --[[
		 * 显示用户中心
		 * @param info 玩家的基础信息
		 * @param callback 绑定的回掉函数
		--]]
        function SDKProxy:showUserCenter(userInfo)
            if gdkjsb.bridge == nil then
                return
            end

            userInfo = userInfo or self:loadUserRecord()[0]
            gdkjsb.bridge:callAction(
                "showUserCenter",
                JSON:stringify({info = userInfo, support = self.support, records = self:loadUserRecord(true)}),
                function(data)
                end
            )
        end

        --[[
		 * 隐藏用户中心图标
		--]]
        function SDKProxy:hideUserCenter()
            if gdkjsb.bridge == nil then
                return
            end

            gdkjsb.bridge:callAction(
                "hideUserCenter",
                "{}",
                function(data)
                end
            )
        end

        --[[
		 * 隐藏用户中心图标
		--]]
        function SDKProxy:hideBindDialog()
            if gdkjsb.bridge == nil then
                return
            end

            gdkjsb.bridge:callAction(
                "hideBindDialog",
                "{}",
                function(data)
                end
            )
        end

        function SDKProxy:showBindDialog(userInfo)
            if gdkjsb.bridge == nil then
                return
            end

            userInfo = userInfo or self:loadUserRecord()[0]
            gdkjsb.bridge:callAction(
                "showBindDialog",
                JSON:stringify({info = userInfo, support = self.support, records = self:loadUserRecord(true)}),
                function(data)
                end
            )
        end

        --[[
		 * 显示未成年人游戏描述信息
		--]]
        function SDKProxy:showMinorInfo(info, callback)
            if gdkjsb.bridge == nil then
                return
            end
            gdkjsb.bridge:callAction("showMinorInfo", JSON:stringify({info = info}), callback)
        end

        --[[
		 * 显示实名制弹框，进入实名制流程
		 * @param force 是否强制
		--]]
        function SDKProxy:showRealNameDialog(userId, force, callback)
            if gdkjsb.bridge == nil then
                return
            end
            gdkjsb.bridge:callAction(
                "showRealNameDialog",
                JSON:stringify({userId = userId, force = force}),
                function(d)
                    callback(JSON:parse(d))
                end
            )
        end

        --[[
		 * 侦听取消登陆的回掉接口
		 * @param callback 
		--]]
        function SDKProxy:onCancelLogining(callback)
            if gdkjsb.bridge == nil then
                return
            end

            if self.cancelLoginingId ~= nil then
                gdkjsb.bridge:off(self.cancelLoginingId)
            end
            self.cancelLoginingId = gdkjsb.bridge:on("cancelLogining", callback)
        end

        --[[
		 * 对玩家执行自动登陆
		 * @param user 
		--]]
        function SDKProxy:autoLogin(user)
            if gdkjsb.bridge == nil then
                return
            end

            gdkjsb.bridge:callAction(
                "autoLogin",
                JSON:stringify(user),
                function(data)
                end
            )
        end

        --[[
		 * 对玩家执行自动登陆
		 * @param user 
		--]]
        function SDKProxy:loginNative()
            if gdkjsb.bridge == nil then
                return
            end

            gdkjsb.bridge:callAction(
                "loginNative",
                JSON:stringify({support = self.support, records = self:loadUserRecord(true)}),
                function(data)
                end
            )
        end

        function SDKProxy:onLogin(callback)
            if gdkjsb.bridge == nil then
                return
            end

            if self.loginId ~= nil then
                gdkjsb.bridge:off(self.loginId)
            end
            self.loginId =
                gdkjsb.bridge:on(
                "login",
                function(data)
                    console:log("loginroute-JSBOnLoginData:", data)
                    local json = JSON:parse(data)
                    callback(
                        json.type,
                        json.openId,
                        json.token,
                        json.nickName,
                        json.email,
                        json.head,
                        json.platform,
                        json.exAuthData
                    )
                end
            )
        end

        function SDKProxy:onRebootLogin(callback)
            if gdkjsb.bridge == nil then
                return
            end

            if self.rebootLoginId ~= nil then
                gdkjsb.bridge:off(self.rebootLoginId)
            end
            self.rebootLoginId =
                gdkjsb.bridge:on(
                "rebootLogin",
                function(data)
                    local json = JSON:parse(data)
                    callback(json.type, json.openId, json.token, json.nickName, json.email, json.head)
                end
            )
        end

        function SDKProxy:onBind(callback)
            if gdkjsb.bridge == nil then
                return
            end

            if self.bindId ~= nil then
                gdkjsb.bridge:off(self.bindId)
            end
            self.bindId =
                gdkjsb.bridge:on(
                "bind",
                function(data)
                    local json = JSON:parse(data)
                    callback(json.type, json.visitorOpenId, json.openId, json.token, json.platform)
                end
            )
        end

        function SDKProxy:onLoginFail(callback)
            if gdkjsb.bridge == nil then
                return
            end

            if self.loginFailId ~= nil then
                gdkjsb.bridge:off(self.loginFailId)
            end
            self.loginFailId =
                gdkjsb.bridge:on(
                "loginFail",
                function(data)
                    local json = JSON:parse(data)
                    callback()
                end
            )
        end

        function SDKProxy:onRemoveUser(callback)
            if gdkjsb.bridge == nil then
                return
            end

            if self.removeUserId ~= nil then
                gdkjsb.bridge:off(self.removeUserId)
            end
            self.removeUserId =
                gdkjsb.bridge:on(
                "removeUser",
                function(data)
                    local json = JSON:parse(data)
                    callback(json.openId)
                end
            )
        end

        function SDKProxy:onLogout(callback)
            if gdkjsb.bridge == nil then
                return
            end

            if self.logoutId ~= nil then
                gdkjsb.bridge:off(self.logoutId)
            end
            self.logoutId =
                gdkjsb.bridge:on(
                "logout",
                function(data)
                    callback()
                end
            )
        end

        --[[
		 * 隐藏启动屏
		--]]
        function SDKProxy:hideLaunchingView()
            if gdkjsb.bridge == nil then
                return
            end

            gdkjsb.bridge:callAction(
                "hideLaunchingView",
                "{}",
                function(data)
                end
            )
        end
        function SDKProxy.prototype:constructor()
        end

        return SDKProxy
    end)()

    SDKProxy.support = {google = true, visitor = true, facebook = true, wechat = true, gamecenter = true}

    SDKProxy.cancelLoginingId = nil

    SDKProxy.loginId = nil

    SDKProxy.rebootLoginId = nil

    SDKProxy.bindId = nil

    SDKProxy.loginFailId = nil

    SDKProxy.removeUserId = nil

    SDKProxy.logoutId = nil

    SDKProxy.nativeAdvert = UnityAppGDK.NativeAdvert()

    SDKProxy.nativePay = UnityAppGDK.NativePay()

    SDKProxy.nativeLocalPush = UnityAppGDK.NativeLocalPush()

    UnityAppGDK.SDKProxy = SDKProxy

    UnityAppGDK.SDKProxy = SDKProxy
end)(UnityAppGDK)

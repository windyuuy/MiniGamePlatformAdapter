local UserData

local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ = (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    UserData = (function(super)
        local UserData = declareClass("UserData", super)
        function UserData.prototype:__getter__openId()
            return "0999999"
        end
        function UserData.prototype:__getter__gameId()
            return -1
        end
        function UserData.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.openKey = nil
            self.password = nil
            self.nickName = nil
            self.userId = nil
            self.isNewUser = nil
            self.avatarUrl = nil
            self.backupTime = nil
            self.followGzh = nil
            self.token = nil
            self.gameToken = nil
            self.channelId = nil
            self.createTime = nil
            self.sex = nil

            --constructor logic
        end

        return UserData
    end)(GDK.IUserData)
    UnityAppGDK.UserData = UserData

    UnityAppGDK.UserData = UserData
end)(UnityAppGDK)

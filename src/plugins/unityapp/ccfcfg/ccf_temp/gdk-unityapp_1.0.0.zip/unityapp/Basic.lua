local RReqPromise
local RLoginPromise
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    RReqPromise =
        (function(super)
        local RReqPromise = declareClass("RReqPromise", super)

        function RReqPromise.prototype:constructor(params)
            if super and super.prototype then
                super.prototype.constructor(self, params)
            end

            --member properties
            self.success = nil
            self.fail = nil
            self.promise = nil

            --constructor parameters

            --constructor logic
        end

        function RReqPromise.prototype:init(params)
            self.promise =
                Promise(
                function(resolve, reject)
                    self.success = function(data)
                        local data1 = (data == nil) and ({}) or (data)

                        resolve(
                            GDK.GDKResultTemplates:make(
                                GDK.GDKErrorCode.SUCCESS,
                                {
                                    msg = params.okmsg or nil,
                                    reason = params.okreason or data1["errMsg"] or nil,
                                    data = data1
                                }
                            )
                        )
                    end
                    self.fail = function()
                        reject(
                            GDK.GDKResultTemplates:make(
                                GDK.GDKErrorCode.UNKNOWN,
                                {
                                    msg = params.failmsg or nil,
                                    reason = params.failreason or nil
                                }
                            )
                        )
                    end
                end
            )
        end

        return RReqPromise
    end)(GDK.RPromise)
    UnityAppGDK.RReqPromise = RReqPromise

    UnityAppGDK.RReqPromise = RReqPromise

    local function wrapReq(fun, object, code)
        local ret = GDK.RPromise()
        object.success = ret.success
        object.fail = function()
            ret:fail(GDK.GDKResultTemplates:make(code))
        end
        fun(object)
        return ret.promise
    end
    UnityAppGDK.wrapReq = wrapReq
    UnityAppGDK.wrapReq = wrapReq

    RLoginPromise = (function(super)
        local RLoginPromise = declareClass("RLoginPromise", super)
        function RLoginPromise.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return RLoginPromise
    end)(RReqPromise)
    UnityAppGDK.RLoginPromise = RLoginPromise

    UnityAppGDK.RLoginPromise = RLoginPromise
end)(UnityAppGDK)

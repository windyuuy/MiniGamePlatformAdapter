local Auth
--/ <reference path="./Common.ts" />
local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ =
    (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    local devlog = Common.devlog

    Auth =
        (function(super)
        local Auth = declareClass("Auth", super)

        function Auth.prototype:createUserInfoButton(obj)
            devlog:info("createUserInfoButton")
            return nil
        end

        Auth.prototype.isUserInfoAuthAlready =
            __JS_Async(
            function(self)
                return true
            end
        )
        function Auth.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --constructor logic
        end

        return Auth
    end)(GDK.IAuth)
    UnityAppGDK.Auth = Auth

    UnityAppGDK.Auth = Auth
end)(UnityAppGDK)

local Support

local UnityAppGDK = UnityAppGDK or {}
_G.UnityAppGDK = UnityAppGDK
local _ = (function(UnityAppGDK)
    extendsNSList({UnityAppGDK, _G})

    Support = (function(super)
        local Support = declareClass("Support", super)
        function Support.prototype:constructor()
            if super and super.prototype then
                super.prototype.constructor(self)
            end

            --member properties
            self.pluginName = "app"
            self.supportShare = true
            self.supportShareTickets = false
            self.requireSubDomainRank = false
            self.apiPlatform = "native"
            self.requireAuthorize = false
            self.apiNameLocale = "原生APP"

            --constructor logic
        end

        return Support
    end)(GDK.ISupport)
    UnityAppGDK.Support = Support

    UnityAppGDK.Support = Support
end)(UnityAppGDK)
